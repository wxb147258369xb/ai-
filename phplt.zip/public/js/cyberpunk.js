/*
 * Nexus 赛博朋克风格论坛交互脚本
 */

// 全局命名空间
/**
 * 论坛系统主对象 - Nexus
 * 包含论坛系统的所有核心功能和交互逻辑
 * @type {Object}
 */
const Nexus = {
    // DOM元素缓存
    elements: {},
    
    // 初始化函数
    init: function() {
        this.cacheElements();
        this.setupEventListeners();
        this.initializeComponents();
        this.checkUserLogin();
        
        console.log('Nexus 论坛系统初始化完成');
    },
    
    // 缓存DOM元素
    cacheElements: function() {
        this.elements = {
            header: document.querySelector('header'),
            mobileMenuBtn: document.getElementById('mobile-menu-btn'),
            mobileMenu: document.getElementById('mobile-menu'),
            backToTopBtn: document.getElementById('back-to-top'),
            loginForm: document.getElementById('login-form'),
            registerForm: document.getElementById('register-form'),
            searchForm: document.getElementById('search-form'),
            logoutBtn: document.querySelector('a[href="/logout"]'),
            cards: document.querySelectorAll('.cyberpunk-card'),
            navLinks: document.querySelectorAll('nav a'),
            forms: document.querySelectorAll('form'),
            forumCards: document.querySelectorAll('.cyberpunk-card[data-type="forum"]')
        };
    },
    
    // 设置事件监听器
    setupEventListeners: function() {
        // 窗口滚动事件
        window.addEventListener('scroll', this.handleScroll.bind(this));
        
        // 移动端菜单切换
        if (this.elements.mobileMenuBtn && this.elements.mobileMenu) {
            this.elements.mobileMenuBtn.addEventListener('click', this.toggleMobileMenu.bind(this));
        }
        
        // 返回顶部按钮
        if (this.elements.backToTopBtn) {
            this.elements.backToTopBtn.addEventListener('click', this.scrollToTop.bind(this));
        }
        
        // 表单提交事件
        if (this.elements.forms) {
            this.elements.forms.forEach(form => {
                form.addEventListener('submit', this.handleFormSubmit.bind(this));
            });
        }
        
        // 登录/注册表单验证
        if (this.elements.loginForm) {
            this.elements.loginForm.addEventListener('submit', this.validateLoginForm.bind(this));
        }
        
        if (this.elements.registerForm) {
            this.elements.registerForm.addEventListener('submit', this.validateRegisterForm.bind(this));
        }
        
        // 退出登录确认
        if (this.elements.logoutBtn) {
            this.elements.logoutBtn.addEventListener('click', this.confirmLogout.bind(this));
        }
        
        // 卡片悬停效果
        if (this.elements.cards) {
            this.elements.cards.forEach(card => {
                card.addEventListener('mouseenter', this.cardHoverEffect.bind(this, card));
                card.addEventListener('mouseleave', this.cardLeaveEffect.bind(this, card));
            });
        }
        
        // 导航链接高亮
        if (this.elements.navLinks) {
            this.elements.navLinks.forEach(link => {
                this.updateNavLinkActiveState(link);
            });
        }
        
        // 页面加载完成事件
        document.addEventListener('DOMContentLoaded', this.onDOMContentLoaded.bind(this));
    },
    
    // 初始化组件
    initializeComponents: function() {
        this.initNeonEffects();
        this.initParticleEffects();
        this.initScrollAnimations();
        this.initDarkModeToggle();
    },
    
    // 处理滚动事件
    handleScroll: function() {
        const scrollPosition = window.scrollY;
        
        // 导航栏滚动效果
        if (this.elements.header) {
            if (scrollPosition > 10) {
                this.elements.header.classList.add('py-2', 'shadow-lg', 'shadow-neon-blue/10');
            } else {
                this.elements.header.classList.remove('py-2', 'shadow-lg', 'shadow-neon-blue/10');
            }
        }
        
        // 返回顶部按钮显示/隐藏
        if (this.elements.backToTopBtn) {
            if (scrollPosition > 300) {
                this.elements.backToTopBtn.classList.remove('opacity-0', 'invisible');
                this.elements.backToTopBtn.classList.add('opacity-100', 'visible');
            } else {
                this.elements.backToTopBtn.classList.add('opacity-0', 'invisible');
                this.elements.backToTopBtn.classList.remove('opacity-100', 'visible');
            }
        }
        
        // 滚动动画
        this.checkScrollAnimations(scrollPosition);
    },
    
    // 切换移动端菜单
    toggleMobileMenu: function() {
        if (this.elements.mobileMenu) {
            this.elements.mobileMenu.classList.toggle('hidden');
            
            // 添加动画效果
            if (!this.elements.mobileMenu.classList.contains('hidden')) {
                this.elements.mobileMenu.classList.add('slide-up');
            }
        }
    },
    
    // 滚动到顶部
    scrollToTop: function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    },
    
    // 处理表单提交
    handleFormSubmit: function(event) {
        // 添加表单提交动画
        const submitBtn = event.target.querySelector('button[type="submit"]');
        if (submitBtn) {
            const originalText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="loading"></span> 处理中...';
            
            // 5秒后恢复按钮状态（如果需要）
            setTimeout(() => {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }, 5000);
        }
    },
    
    // 验证登录表单
    validateLoginForm: function(event) {
        const username = event.target.querySelector('input[name="username"]').value;
        const password = event.target.querySelector('input[name="password"]').value;
        const errorContainer = event.target.querySelector('.error-message');
        
        if (!username || !password) {
            event.preventDefault();
            this.showError(errorContainer, '请输入用户名和密码');
            return false;
        }
        
        return true;
    },
    
    // 验证注册表单
    validateRegisterForm: function(event) {
        const username = event.target.querySelector('input[name="username"]').value;
        const email = event.target.querySelector('input[name="email"]').value;
        const password = event.target.querySelector('input[name="password"]').value;
        const confirmPassword = event.target.querySelector('input[name="confirm_password"]').value;
        const errorContainer = event.target.querySelector('.error-message');
        
        // 简单验证
        if (!username || !email || !password || !confirmPassword) {
            event.preventDefault();
            this.showError(errorContainer, '请填写所有必填字段');
            return false;
        }
        
        if (password !== confirmPassword) {
            event.preventDefault();
            this.showError(errorContainer, '两次输入的密码不一致');
            return false;
        }
        
        if (username.length < 3) {
            event.preventDefault();
            this.showError(errorContainer, '用户名至少需要3个字符');
            return false;
        }
        
        if (password.length < 6) {
            event.preventDefault();
            this.showError(errorContainer, '密码至少需要6个字符');
            return false;
        }
        
        return true;
    },
    
    // 显示错误信息
    showError: function(container, message) {
        if (!container) {
            const form = document.querySelector('form');
            if (form) {
                container = document.createElement('div');
                container.className = 'error-message bg-danger/10 border border-danger/30 text-danger p-3 rounded mb-4';
                form.insertBefore(container, form.firstChild);
            } else {
                return;
            }
        }
        
        container.textContent = message;
        container.style.display = 'block';
        
        // 5秒后隐藏错误信息
        setTimeout(() => {
            container.style.display = 'none';
        }, 5000);
    },
    
    // 确认退出登录
    confirmLogout: function(event) {
        if (!confirm('确定要退出登录吗？')) {
            event.preventDefault();
            return false;
        }
        return true;
    },
    
    // 卡片悬停效果
    cardHoverEffect: function(card) {
        card.classList.add('neon-border');
        card.style.transform = 'translateY(-5px)';
        card.style.transition = 'all 0.3s ease';
    },
    
    // 卡片离开效果
    cardLeaveEffect: function(card) {
        card.classList.remove('neon-border');
        card.style.transform = 'translateY(0)';
    },
    
    // 更新导航链接激活状态
    updateNavLinkActiveState: function(link) {
        const currentUrl = window.location.pathname;
        const linkUrl = link.getAttribute('href');
        
        if (linkUrl === '/' && currentUrl === '/') {
            link.classList.add('active');
        } else if (currentUrl.startsWith(linkUrl) && linkUrl !== '/') {
            link.classList.add('active');
        }
    },
    
    // DOM加载完成事件
    onDOMContentLoaded: function() {
        // 检查元素是否可见
        this.checkVisibility();
        
        // 初始化工具提示
        this.initTooltips();
        
        // 初始化模态框
        this.initModals();
    },
    
    // 检查用户登录状态
    checkUserLogin: function() {
        // 这里可以通过AJAX检查用户是否已登录
        // 如果需要实时更新用户状态
    },
    
    // 初始化霓虹效果
    initNeonEffects: function() {
        // 为标题添加随机霓虹效果
        const titles = document.querySelectorAll('h1, h2, h3');
        titles.forEach(title => {
            if (Math.random() > 0.7) {
                title.classList.add('text-glow');
            }
        });
    },
    
    // 初始化粒子效果
    initParticleEffects: function() {
        const heroSection = document.querySelector('section.relative');
        if (heroSection) {
            this.createParticles(heroSection);
        }
    },
    
    // 创建粒子
    createParticles: function(container) {
        const colors = ['#00ff00', '#00bfff', '#ff00ff', '#9900ff'];
        
        const createParticle = () => {
            const particle = document.createElement('div');
            const size = Math.random() * 3 + 1;
            const color = colors[Math.floor(Math.random() * colors.length)];
            
            particle.style.position = 'absolute';
            particle.style.width = `${size}px`;
            particle.style.height = `${size}px`;
            particle.style.backgroundColor = color;
            particle.style.borderRadius = '50%';
            particle.style.top = `${Math.random() * 100}%`;
            particle.style.left = `${Math.random() * 100}%`;
            particle.style.opacity = '0';
            particle.style.transition = `opacity 2s, transform 10s linear`;
            particle.style.pointerEvents = 'none';
            
            container.appendChild(particle);
            
            setTimeout(() => {
                particle.style.opacity = '0.8';
                particle.style.transform = `translateY(-${Math.random() * 300 + 100}px) translateX(${Math.random() * 100 - 50}px)`;
            }, 100);
            
            setTimeout(() => {
                container.removeChild(particle);
            }, 10000);
        };
        
        // 持续创建粒子
        const interval = setInterval(createParticle, 200);
        
        // 5分钟后停止创建粒子以避免性能问题
        setTimeout(() => {
            clearInterval(interval);
        }, 300000);
    },
    
    // 初始化滚动动画
    initScrollAnimations: function() {
        // 为元素添加滚动动画类
        const elements = document.querySelectorAll('.animate-on-scroll');
        elements.forEach(el => {
            el.classList.add('opacity-0', 'translate-y-8');
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });
    },
    
    // 检查滚动动画
    checkScrollAnimations: function(scrollPosition) {
        const elements = document.querySelectorAll('.animate-on-scroll');
        const windowHeight = window.innerHeight;
        
        elements.forEach(el => {
            const elementTop = el.getBoundingClientRect().top;
            
            if (elementTop < windowHeight * 0.85) {
                el.classList.remove('opacity-0', 'translate-y-8');
            }
        });
    },
    
    // 检查元素可见性
    checkVisibility: function() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        document.querySelectorAll('.observe-visibility').forEach(el => {
            observer.observe(el);
        });
    },
    
    // 初始化工具提示
    initTooltips: function() {
        const tooltips = document.querySelectorAll('[data-tooltip]');
        tooltips.forEach(tooltip => {
            tooltip.addEventListener('mouseenter', function() {
                const tooltipText = this.getAttribute('data-tooltip');
                const tooltipEl = document.createElement('div');
                tooltipEl.className = 'tooltip absolute bg-dark border border-neon-blue text-white text-xs p-2 rounded z-50';
                tooltipEl.textContent = tooltipText;
                tooltipEl.style.position = 'fixed';
                tooltipEl.style.pointerEvents = 'none';
                
                document.body.appendChild(tooltipEl);
                
                const rect = this.getBoundingClientRect();
                tooltipEl.style.top = `${rect.bottom + window.scrollY + 5}px`;
                tooltipEl.style.left = `${rect.left + window.scrollX + rect.width / 2 - tooltipEl.offsetWidth / 2}px`;
                
                this.tooltipElement = tooltipEl;
            });
            
            tooltip.addEventListener('mouseleave', function() {
                if (this.tooltipElement) {
                    document.body.removeChild(this.tooltipElement);
                    this.tooltipElement = null;
                }
            });
        });
    },
    
    // 初始化模态框
    initModals: function() {
        const modalTriggers = document.querySelectorAll('[data-modal]');
        modalTriggers.forEach(trigger => {
            trigger.addEventListener('click', function() {
                const modalId = this.getAttribute('data-modal');
                const modal = document.getElementById(modalId);
                if (modal) {
                    modal.classList.remove('hidden');
                    document.body.style.overflow = 'hidden';
                }
            });
        });
        
        const closeButtons = document.querySelectorAll('[data-close-modal]');
        closeButtons.forEach(button => {
            button.addEventListener('click', function() {
                const modalId = this.getAttribute('data-close-modal');
                const modal = document.getElementById(modalId);
                if (modal) {
                    modal.classList.add('hidden');
                    document.body.style.overflow = '';
                }
            });
        });
    },
    
    // 初始化暗黑模式切换
    initDarkModeToggle: function() {
        // 论坛已经是暗黑模式，此功能留作扩展
    },
    
    // 显示通知
    showNotification: function(message, type = 'info') {
        const notification = document.createElement('div');
        const typeClasses = {
            success: 'bg-green-500',
            error: 'bg-red-500',
            warning: 'bg-yellow-500',
            info: 'bg-blue-500'
        };
        
        notification.className = `fixed top-4 right-4 px-6 py-3 rounded-md text-white z-50 transform transition-all duration-500 ${typeClasses[type] || typeClasses.info}`;
        notification.textContent = message;
        notification.style.transform = 'translateX(100%)';
        
        document.body.appendChild(notification);
        
        // 显示通知
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // 3秒后隐藏通知
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 500);
        }, 3000);
    },
    
    // AJAX请求封装
    ajax: function(url, options = {}) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            const method = options.method || 'GET';
            const data = options.data || null;
            const headers = options.headers || {};
            
            xhr.open(method, url, true);
            
            // 设置默认头部
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            
            // 设置自定义头部
            for (const [key, value] of Object.entries(headers)) {
                xhr.setRequestHeader(key, value);
            }
            
            xhr.onload = function() {
                if (xhr.status >= 200 && xhr.status < 300) {
                    try {
                        resolve(JSON.parse(xhr.responseText));
                    } catch (e) {
                        resolve(xhr.responseText);
                    }
                } else {
                    reject(new Error(xhr.statusText));
                }
            };
            
            xhr.onerror = function() {
                reject(new Error('Network error'));
            };
            
            if (data) {
                xhr.send(JSON.stringify(data));
            } else {
                xhr.send();
            }
        });
    }
};

// 页面加载完成后初始化
window.addEventListener('load', () => {
    Nexus.init();
});

// 暴露Nexus到全局窗口对象，方便在控制台调试
window.Nexus = Nexus;