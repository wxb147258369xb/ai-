<?php
/**
 * Nexus论坛系统入口文件
 */

// 定义项目根目录
defined('ROOT_PATH') or define('ROOT_PATH', dirname(__DIR__));

// 加载配置文件
$config = require_once ROOT_PATH . '/app/config/app.php';
$dbConfig = require_once ROOT_PATH . '/app/config/database.php';

// 简单的错误处理
if ($config['debug']) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// 设置时区
date_default_timezone_set($config['timezone']);

// 启动会话
session_name($config['session']['name']);
session_set_cookie_params([
    'lifetime' => $config['session']['timeout'],
    'path' => '/',
    'domain' => '',
    'secure' => $config['session']['secure'],
    'httponly' => $config['session']['httponly'],
    'samesite' => 'Lax'
]);
session_start();

// 简单的自动加载函数
function autoload($class) {
    $class = str_replace('\\', '/', $class);
    $file = ROOT_PATH . '/app/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
}

spl_autoload_register('autoload');

// 路由处理
$controllerName = $config['default_controller'];
$actionName = $config['default_action'];

// 获取请求参数
$requestUri = $_SERVER['REQUEST_URI'];
$pathInfo = parse_url($requestUri, PHP_URL_PATH);

if ($pathInfo !== '/' && $pathInfo !== '/index.php') {
    $parts = explode('/', trim($pathInfo, '/'));
    
    // 提取控制器名
    if (!empty($parts[0])) {
        $controllerName = ucfirst(strtolower($parts[0]));
        array_shift($parts);
    }
    
    // 提取方法名
    if (!empty($parts[0])) {
        $actionName = strtolower($parts[0]);
        array_shift($parts);
    }
    
    // 剩余部分作为参数
    $_GET['params'] = $parts;
}

// 构建控制器类名
$controllerClass = 'controllers\\' . $controllerName . 'Controller';

// 检查控制器是否存在
if (!class_exists($controllerClass)) {
    // 如果控制器不存在，尝试加载Home控制器
    $controllerClass = 'controllers\\HomeController';
    $actionName = 'index';
}

// 实例化控制器并调用方法
try {
    $controller = new $controllerClass();
    
    // 检查方法是否存在
    if (!method_exists($controller, $actionName)) {
        $actionName = 'index';
    }
    
    // 调用控制器方法
    $controller->$actionName();
} catch (Exception $e) {
    // 记录错误
    file_put_contents(ROOT_PATH . '/logs/error.log', date('Y-m-d H:i:s') . ' - Error: ' . $e->getMessage() . PHP_EOL, FILE_APPEND);
    
    // 显示错误页面
    header('HTTP/1.1 500 Internal Server Error');
    echo '<div style="font-family: monospace; padding: 20px; background: #000; color: #ff0000;">';
    echo '<h1 style="color: #ff0000;">系统错误</h1>';
    echo '<pre>';
    if ($config['debug']) {
        echo $e->getMessage() . '<br>';
        echo $e->getTraceAsString();
    } else {
        echo '服务器内部错误，请稍后重试。';
    }
    echo '</pre>';
    echo '</div>';
}