<?php
/**
 * 数据库配置文件
 */

return [
    // 数据库连接信息
    'host' => 'localhost',
    'dbname' => 'php_forum',
    'username' => 'php_forum',
    'password' => '123456789',
    'charset' => 'utf8mb4',
    'driver' => 'mysql',
    
    // 连接池设置
    'pool' => [
        'min' => 5,
        'max' => 20
    ],
    
    // 缓存设置
    'cache' => [
        'enabled' => true,
        'ttl' => 3600
    ],
    
    // 日志设置
    'log' => [
        'enabled' => true,
        'level' => 'error'
    ]
];