<?php
/**
 * 应用程序配置文件
 */

return [
    // 应用基本信息
    'app_name' => '0x08网络分享 论坛',
    'app_version' => '1.0.0',
    'debug' => false,
    'timezone' => 'Asia/Shanghai',
    
    // 路由设置
    'default_controller' => 'Home',
    'default_action' => 'index',
    'url_rewrite' => false,
    
    // 会话设置
    'session' => [
        'name' => 'nexus_session',
        'timeout' => 1800, // 30分钟
        'secure' => false, // 生产环境设为true
        'httponly' => true
    ],
    
    // CSRF保护
    'csrf' => [
        'enabled' => true,
        'token_name' => '_csrf',
        'token_expire' => 3600
    ],
    
    // 上传设置
    'upload' => [
        'max_size' => 5242880, // 5MB
        'allowed_types' => ['jpg', 'jpeg', 'png', 'gif', 'webp'],
        'path' => '../public/uploads/'
    ],
    
    // 安全设置
    'security' => [
        'hash_algorithm' => 'password_hash',
        'salt_rounds' => 12,
        'cors' => [
            'enabled' => true,
            'allowed_origins' => ['*']
        ]
    ],
    
    // 邮件设置
    'mail' => [
        'smtp' => [
            'host' => 'smtp.example.com',
            'port' => 587,
            'username' => '',
            'password' => '',
            'encryption' => 'tls'
        ],
        'from' => [
            'address' => 'noreply@nexus.com',
            'name' => 'Nexus 论坛'
        ]
    ]
];