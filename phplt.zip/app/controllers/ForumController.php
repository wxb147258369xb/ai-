<?php
/**
 * 版块控制器
 */
class ForumController {
    private $forumModel;
    private $threadModel;
    private $userModel;

    /**
     * 构造函数，初始化模型
     */
    public function __construct() {
        $this->forumModel = new Forum();
        $this->threadModel = new Thread();
        $this->userModel = new User();
    }

    /**
     * 版块列表页面
     */
    public function index() {
        // 获取所有版块
        $forums = $this->forumModel->getAllForums();
        
        // 获取热门话题
        $hotThreads = $this->threadModel->getHotThreads(8);
        
        // 获取最新话题
        $latestThreads = $this->threadModel->getLatestThreads(8);
        
        // 渲染视图
        $this->view('forum/index', [
            'title' => '版块列表 - Nexus论坛',
            'forums' => $forums,
            'hotThreads' => $hotThreads,
            'latestThreads' => $latestThreads
        ]);
    }

    /**
     * 版块详情页面
     */
    public function show() {
        // 获取版块ID
        $forumId = isset($_GET['params'][0]) ? intval($_GET['params'][0]) : 0;
        
        // 检查版块是否存在
        if (!$this->forumModel->forumExists($forumId)) {
            $_SESSION['error'] = '版块不存在！';
            header('Location: /forum');
            exit;
        }
        
        // 获取版块详情
        $forum = $this->forumModel->getForumDetails($forumId);
        
        // 获取排序方式
        $sortBy = isset($_GET['sort']) ? $_GET['sort'] : 'latest';
        
        // 获取分页参数
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $page = max(1, $page);
        $limit = 20;
        
        // 获取话题列表
        $threads = $this->forumModel->getThreads($forumId, $page, $limit, $sortBy);
        
        // 获取最新话题
        $latestThreads = $this->forumModel->getLatestThreads($forumId, 5);
        
        // 渲染视图
        $this->view('forum/show', [
            'title' => $forum['name'] . ' - Nexus论坛',
            'forum' => $forum,
            'threads' => $threads,
            'latestThreads' => $latestThreads,
            'sortBy' => $sortBy,
            'page' => $page
        ]);
    }

    /**
     * 创建话题页面
     */
    public function createThread() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['error'] = '请先登录！';
            header('Location: /auth/login');
            exit;
        }
        
        // 获取版块ID
        $forumId = isset($_GET['params'][0]) ? intval($_GET['params'][0]) : 0;
        
        // 检查版块是否存在
        if (!$this->forumModel->forumExists($forumId)) {
            $_SESSION['error'] = '版块不存在！';
            header('Location: /forum');
            exit;
        }
        
        // 获取版块详情
        $forum = $this->forumModel->getForumDetails($forumId);
        
        // 渲染视图
        $this->view('forum/create_thread', [
            'title' => '发布话题 - Nexus论坛',
            'forum' => $forum
        ]);
    }

    /**
     * 处理创建话题请求
     */
    public function doCreateThread() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['error'] = '请先登录！';
            header('Location: /auth/login');
            exit;
        }
        
        // 获取表单数据
        $forumId = isset($_POST['forum_id']) ? intval($_POST['forum_id']) : 0;
        $title = isset($_POST['title']) ? trim($_POST['title']) : '';
        $content = isset($_POST['content']) ? trim($_POST['content']) : '';
        
        // 验证数据
        if (empty($title) || empty($content)) {
            $_SESSION['error'] = '请填写标题和内容！';
            header('Location: /forum/createThread/' . $forumId);
            exit;
        }
        
        // 检查标题长度
        if (strlen($title) < 5 || strlen($title) > 100) {
            $_SESSION['error'] = '标题长度应在5-100个字符之间！';
            header('Location: /forum/createThread/' . $forumId);
            exit;
        }
        
        // 检查内容长度
        if (strlen($content) < 10) {
            $_SESSION['error'] = '内容长度至少为10个字符！';
            header('Location: /forum/createThread/' . $forumId);
            exit;
        }
        
        // 创建话题数据
        $threadData = [
            'title' => $title,
            'content' => $content,
            'forum_id' => $forumId,
            'user_id' => $_SESSION['user_id']
        ];
        
        // 保存话题
        $threadId = $this->threadModel->createThread($threadData);
        
        if ($threadId) {
            // 增加用户积分
            $this->userModel->addPoints($_SESSION['user_id'], 10);
            
            $_SESSION['success'] = '话题发布成功！';
            header('Location: /thread/show/' . $threadId);
            exit;
        } else {
            $_SESSION['error'] = '话题发布失败，请稍后重试！';
            header('Location: /forum/createThread/' . $forumId);
            exit;
        }
    }

    /**
     * 搜索版块
     */
    public function search() {
        // 获取搜索关键词
        $keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
        
        if (empty($keyword)) {
            header('Location: /forum');
            exit;
        }
        
        // 这里可以实现版块搜索逻辑
        // 目前只是简单地返回所有版块
        $forums = $this->forumModel->getAllForums();
        
        // 过滤版块
        $filteredForums = array_filter($forums, function($forum) use ($keyword) {
            return strpos(strtolower($forum['name']), strtolower($keyword)) !== false || 
                   strpos(strtolower($forum['description']), strtolower($keyword)) !== false;
        });
        
        // 渲染视图
        $this->view('forum/search', [
            'title' => '搜索版块 - Nexus论坛',
            'forums' => $filteredForums,
            'keyword' => $keyword
        ]);
    }

    /**
     * 渲染视图
     */
    protected function view($view, $data = []) {
        // 提取数据变量
        extract($data);
        
        // 构建视图路径
        $viewPath = ROOT_PATH . '/app/views/' . $view . '.php';
        
        // 检查视图文件是否存在
        if (!file_exists($viewPath)) {
            die('视图文件不存在：' . $viewPath);
        }
        
        // 包含布局头部
        include ROOT_PATH . '/app/views/layouts/header.php';
        
        // 包含视图内容
        include $viewPath;
        
        // 包含布局尾部
        include ROOT_PATH . '/app/views/layouts/footer.php';
    }
}