<?php
/**
 * 话题控制器
 */
class ThreadController {
    private $threadModel;
    private $replyModel;
    private $userModel;
    private $forumModel;

    /**
     * 构造函数，初始化模型
     */
    public function __construct() {
        $this->threadModel = new Thread();
        $this->replyModel = new Reply();
        $this->userModel = new User();
        $this->forumModel = new Forum();
    }

    /**
     * 话题详情页面
     */
    public function show() {
        // 获取话题ID
        $threadId = isset($_GET['params'][0]) ? intval($_GET['params'][0]) : 0;
        
        // 检查话题是否存在
        if (!$this->threadModel->threadExists($threadId)) {
            $_SESSION['error'] = '话题不存在！';
            header('Location: /');
            exit;
        }
        
        // 增加浏览次数
        $this->threadModel->incrementViewCount($threadId);
        
        // 获取话题详情
        $thread = $this->threadModel->getThreadDetails($threadId);
        
        // 获取分页参数
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $page = max(1, $page);
        $limit = 20;
        
        // 获取回复列表
        $replies = $this->replyModel->getThreadReplies($threadId, $page, $limit);
        
        // 获取版块信息
        $forum = $this->forumModel->getForumDetails($thread['forum_id']);
        
        // 获取热门话题
        $hotThreads = $this->threadModel->getHotThreads(8);
        
        // 渲染视图
        $this->view('thread/show', [
            'title' => $thread['title'] . ' - Nexus论坛',
            'thread' => $thread,
            'replies' => $replies,
            'forum' => $forum,
            'hotThreads' => $hotThreads,
            'page' => $page
        ]);
    }

    /**
     * 编辑话题页面
     */
    public function edit() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['error'] = '请先登录！';
            header('Location: /auth/login');
            exit;
        }
        
        // 获取话题ID
        $threadId = isset($_GET['params'][0]) ? intval($_GET['params'][0]) : 0;
        
        // 检查话题是否存在
        if (!$this->threadModel->threadExists($threadId)) {
            $_SESSION['error'] = '话题不存在！';
            header('Location: /');
            exit;
        }
        
        // 获取话题详情
        $thread = $this->threadModel->getThreadDetails($threadId);
        
        // 检查是否是话题作者或管理员
        if ($thread['user_id'] != $_SESSION['user_id'] && $_SESSION['role'] != 'admin') {
            $_SESSION['error'] = '没有权限编辑此话题！';
            header('Location: /thread/show/' . $threadId);
            exit;
        }
        
        // 获取版块信息
        $forum = $this->forumModel->getForumDetails($thread['forum_id']);
        
        // 渲染视图
        $this->view('thread/edit', [
            'title' => '编辑话题 - Nexus论坛',
            'thread' => $thread,
            'forum' => $forum
        ]);
    }

    /**
     * 处理编辑话题请求
     */
    public function doEdit() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['error'] = '请先登录！';
            header('Location: /auth/login');
            exit;
        }
        
        // 获取表单数据
        $threadId = isset($_POST['thread_id']) ? intval($_POST['thread_id']) : 0;
        $title = isset($_POST['title']) ? trim($_POST['title']) : '';
        $content = isset($_POST['content']) ? trim($_POST['content']) : '';
        
        // 检查话题是否存在
        if (!$this->threadModel->threadExists($threadId)) {
            $_SESSION['error'] = '话题不存在！';
            header('Location: /');
            exit;
        }
        
        // 获取话题详情
        $thread = $this->threadModel->getThreadDetails($threadId);
        
        // 检查是否是话题作者或管理员
        if ($thread['user_id'] != $_SESSION['user_id'] && $_SESSION['role'] != 'admin') {
            $_SESSION['error'] = '没有权限编辑此话题！';
            header('Location: /thread/show/' . $threadId);
            exit;
        }
        
        // 验证数据
        if (empty($title) || empty($content)) {
            $_SESSION['error'] = '请填写标题和内容！';
            header('Location: /thread/edit/' . $threadId);
            exit;
        }
        
        // 检查标题长度
        if (strlen($title) < 5 || strlen($title) > 100) {
            $_SESSION['error'] = '标题长度应在5-100个字符之间！';
            header('Location: /thread/edit/' . $threadId);
            exit;
        }
        
        // 检查内容长度
        if (strlen($content) < 10) {
            $_SESSION['error'] = '内容长度至少为10个字符！';
            header('Location: /thread/edit/' . $threadId);
            exit;
        }
        
        // 更新话题数据
        $threadData = [
            'title' => $title,
            'content' => $content
        ];
        
        // 保存话题
        if ($this->threadModel->updateThread($threadId, $threadData)) {
            $_SESSION['success'] = '话题更新成功！';
            header('Location: /thread/show/' . $threadId);
            exit;
        } else {
            $_SESSION['error'] = '话题更新失败，请稍后重试！';
            header('Location: /thread/edit/' . $threadId);
            exit;
        }
    }

    /**
     * 删除话题
     */
    public function delete() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['error'] = '请先登录！';
            header('Location: /auth/login');
            exit;
        }
        
        // 获取话题ID
        $threadId = isset($_GET['params'][0]) ? intval($_GET['params'][0]) : 0;
        
        // 检查话题是否存在
        if (!$this->threadModel->threadExists($threadId)) {
            $_SESSION['error'] = '话题不存在！';
            header('Location: /');
            exit;
        }
        
        // 获取话题详情
        $thread = $this->threadModel->getThreadDetails($threadId);
        
        // 检查是否是话题作者或管理员
        if ($thread['user_id'] != $_SESSION['user_id'] && $_SESSION['role'] != 'admin') {
            $_SESSION['error'] = '没有权限删除此话题！';
            header('Location: /thread/show/' . $threadId);
            exit;
        }
        
        // 删除话题
        if ($this->threadModel->deleteThread($threadId)) {
            $_SESSION['success'] = '话题删除成功！';
            header('Location: /forum/show/' . $thread['forum_id']);
            exit;
        } else {
            $_SESSION['error'] = '话题删除失败，请稍后重试！';
            header('Location: /thread/show/' . $threadId);
            exit;
        }
    }

    /**
     * 搜索话题
     */
    public function search() {
        // 获取搜索关键词
        $keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
        
        if (empty($keyword)) {
            header('Location: /');
            exit;
        }
        
        // 获取分页参数
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $page = max(1, $page);
        $limit = 10;
        
        // 搜索话题
        $threads = $this->threadModel->searchThreads($keyword, $page, $limit);
        
        // 获取热门话题
        $hotThreads = $this->threadModel->getHotThreads(8);
        
        // 渲染视图
        $this->view('thread/search', [
            'title' => '搜索话题 - Nexus论坛',
            'threads' => $threads,
            'hotThreads' => $hotThreads,
            'keyword' => $keyword,
            'page' => $page
        ]);
    }

    /**
     * 处理回复请求
     */
    public function reply() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['error'] = '请先登录！';
            header('Location: /auth/login');
            exit;
        }
        
        // 获取表单数据
        $threadId = isset($_POST['thread_id']) ? intval($_POST['thread_id']) : 0;
        $content = isset($_POST['content']) ? trim($_POST['content']) : '';
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        
        // 检查话题是否存在
        if (!$this->threadModel->threadExists($threadId)) {
            $_SESSION['error'] = '话题不存在！';
            header('Location: /');
            exit;
        }
        
        // 验证内容
        if (empty($content)) {
            $_SESSION['error'] = '请填写回复内容！';
            header('Location: /thread/show/' . $threadId . '?page=' . $page);
            exit;
        }
        
        if (strlen($content) < 5) {
            $_SESSION['error'] = '回复内容长度至少为5个字符！';
            header('Location: /thread/show/' . $threadId . '?page=' . $page);
            exit;
        }
        
        // 创建回复数据
        $replyData = [
            'content' => $content,
            'thread_id' => $threadId,
            'user_id' => $_SESSION['user_id']
        ];
        
        // 保存回复
        $replyId = $this->replyModel->createReply($replyData);
        
        if ($replyId) {
            // 增加用户积分
            $this->userModel->addPoints($_SESSION['user_id'], 5);
            
            $_SESSION['success'] = '回复成功！';
            
            // 获取最新的回复总数，跳转到最后一页
            $thread = $this->threadModel->getThreadDetails($threadId);
            $lastPage = ceil($thread['reply_count'] / 20);
            
            header('Location: /thread/show/' . $threadId . '?page=' . $lastPage . '#reply-' . $replyId);
            exit;
        } else {
            $_SESSION['error'] = '回复失败，请稍后重试！';
            header('Location: /thread/show/' . $threadId . '?page=' . $page);
            exit;
        }
    }

    /**
     * 渲染视图
     */
    protected function view($view, $data = []) {
        // 提取数据变量
        extract($data);
        
        // 构建视图路径
        $viewPath = ROOT_PATH . '/app/views/' . $view . '.php';
        
        // 检查视图文件是否存在
        if (!file_exists($viewPath)) {
            die('视图文件不存在：' . $viewPath);
        }
        
        // 包含布局头部
        include ROOT_PATH . '/app/views/layouts/header.php';
        
        // 包含视图内容
        include $viewPath;
        
        // 包含布局尾部
        include ROOT_PATH . '/app/views/layouts/footer.php';
    }
}