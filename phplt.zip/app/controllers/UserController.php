<?php
/**
 * 用户控制器
 * 处理用户相关的所有操作
 */
class UserController {
    /**
     * 显示用户个人资料
     * @param int $userId 用户ID
     */
    public function profile($userId) {
        // 获取用户信息
        $userModel = new User();
        $user = $userModel->find($userId);
        
        if (!$user) {
            $_SESSION['message'] = [
                'type' => 'error',
                'text' => '用户不存在'
            ];
            header('Location: /');
            exit;
        }
        
        // 获取用户统计信息
        $userStats = [
            'threads' => $userModel->getThreadCount($userId),
            'replies' => $userModel->getReplyCount($userId),
            'likes' => $userModel->getLikesReceived($userId)
        ];
        
        // 获取用户最近活动
        $activities = $userModel->getRecentActivities($userId, 5);
        
        // 渲染视图
        $data = [
            'user' => $user,
            'userStats' => $userStats,
            'activities' => $activities
        ];
        
        View::render('user/profile', $data);
    }
    
    /**
     * 显示用户发表的话题列表
     * @param int $userId 用户ID
     */
    public function threads($userId) {
        // 获取用户信息
        $userModel = new User();
        $user = $userModel->find($userId);
        
        if (!$user) {
            $_SESSION['message'] = [
                'type' => 'error',
                'text' => '用户不存在'
            ];
            header('Location: /');
            exit;
        }
        
        // 获取分页参数
        $page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;
        $perPage = 10;
        
        // 获取用户话题列表
        $threadModel = new Thread();
        $threads = $threadModel->getUserThreads($userId, $page, $perPage);
        
        // 获取用户总话题数
        $totalThreads = $userModel->getThreadCount($userId);
        $totalPages = ceil($totalThreads / $perPage);
        
        // 渲染视图
        $data = [
            'user' => $user,
            'threads' => $threads,
            'page' => $page,
            'total_pages' => $totalPages,
            'total_threads' => $totalThreads
        ];
        
        View::render('user/threads', $data);
    }
    
    /**
     * 显示用户发表的回复列表
     * @param int $userId 用户ID
     */
    public function replies($userId) {
        // 获取用户信息
        $userModel = new User();
        $user = $userModel->find($userId);
        
        if (!$user) {
            $_SESSION['message'] = [
                'type' => 'error',
                'text' => '用户不存在'
            ];
            header('Location: /');
            exit;
        }
        
        // 获取分页参数
        $page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;
        $perPage = 10;
        
        // 获取用户回复列表
        $replyModel = new Reply();
        $replies = $replyModel->getUserReplies($userId, $page, $perPage);
        
        // 获取用户总回复数
        $totalReplies = $userModel->getReplyCount($userId);
        $totalPages = ceil($totalReplies / $perPage);
        
        // 渲染视图
        $data = [
            'user' => $user,
            'replies' => $replies,
            'page' => $page,
            'total_pages' => $totalPages,
            'total_replies' => $totalReplies
        ];
        
        View::render('user/replies', $data);
    }
    
    /**
     * 编辑用户个人资料
     */
    public function editProfile() {
        // 验证用户是否已登录
        AuthMiddleware::requireAuth();
        
        // 获取当前用户信息
        $userModel = new User();
        $user = $userModel->find($_SESSION['user_id']);
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // 处理表单提交
            $data = [
                'username' => isset($_POST['username']) ? trim($_POST['username']) : '',
                'email' => isset($_POST['email']) ? trim($_POST['email']) : '',
                'signature' => isset($_POST['signature']) ? trim($_POST['signature']) : '',
                'location' => isset($_POST['location']) ? trim($_POST['location']) : '',
                'website' => isset($_POST['website']) ? trim($_POST['website']) : ''
            ];
            
            // 表单验证
            if (empty($data['username'])) {
                $_SESSION['message'] = [
                    'type' => 'error',
                    'text' => '用户名不能为空'
                ];
                header('Location: /user/editProfile');
                exit;
            }
            
            if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                $_SESSION['message'] = [
                    'type' => 'error',
                    'text' => '请输入有效的邮箱地址'
                ];
                header('Location: /user/editProfile');
                exit;
            }
            
            // 检查用户名是否被其他用户使用
            $existingUser = $userModel->findByUsername($data['username']);
            if ($existingUser && $existingUser['id'] != $_SESSION['user_id']) {
                $_SESSION['message'] = [
                    'type' => 'error',
                    'text' => '用户名已被使用'
                ];
                header('Location: /user/editProfile');
                exit;
            }
            
            // 检查邮箱是否被其他用户使用
            $existingEmail = $userModel->findByEmail($data['email']);
            if ($existingEmail && $existingEmail['id'] != $_SESSION['user_id']) {
                $_SESSION['message'] = [
                    'type' => 'error',
                    'text' => '邮箱已被使用'
                ];
                header('Location: /user/editProfile');
                exit;
            }
            
            // 处理密码修改
            if (!empty($_POST['current_password']) && !empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
                // 验证当前密码
                if (!password_verify($_POST['current_password'], $user['password'])) {
                    $_SESSION['message'] = [
                        'type' => 'error',
                        'text' => '当前密码错误'
                    ];
                    header('Location: /user/editProfile');
                    exit;
                }
                
                // 验证新密码
                if (strlen($_POST['new_password']) < 6) {
                    $_SESSION['message'] = [
                        'type' => 'error',
                        'text' => '新密码至少需要6个字符'
                    ];
                    header('Location: /user/editProfile');
                    exit;
                }
                
                if ($_POST['new_password'] != $_POST['confirm_password']) {
                    $_SESSION['message'] = [
                        'type' => 'error',
                        'text' => '两次输入的密码不一致'
                    ];
                    header('Location: /user/editProfile');
                    exit;
                }
                
                // 添加密码到更新数据
                $data['password'] = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            }
            
            // 处理头像上传（在实际项目中实现）
            
            // 更新用户信息
            try {
                $result = $userModel->update($_SESSION['user_id'], $data);
                
                if ($result) {
                    // 更新会话中的用户信息
                    $_SESSION['username'] = $data['username'];
                    $_SESSION['email'] = $data['email'];
                    
                    $_SESSION['message'] = [
                        'type' => 'success',
                        'text' => '个人资料更新成功'
                    ];
                } else {
                    throw new Exception('更新失败');
                }
            } catch (Exception $e) {
                $_SESSION['message'] = [
                    'type' => 'error',
                    'text' => $e->getMessage()
                ];
            }
            
            header('Location: /user/profile/' . $_SESSION['user_id']);
            exit;
        }
        
        // 渲染编辑页面
        View::render('user/editProfile', ['user' => $user]);
    }
    
    /**
     * 登出用户
     */
    public function logout() {
        // 清除会话数据
        unset($_SESSION['user_id'], 
              $_SESSION['username'], 
              $_SESSION['email'], 
              $_SESSION['role'], 
              $_SESSION['points']);
        
        // 销毁会话
        session_destroy();
        
        // 重定向到首页
        $_SESSION['message'] = [
            'type' => 'success',
            'text' => '您已成功登出'
        ];
        
        header('Location: /');
        exit;
    }
    
    /**
     * 获取用户设置页面
     */
    public function settings() {
        // 验证用户是否已登录
        AuthMiddleware::requireAuth();
        
        // 获取当前用户信息
        $userModel = new User();
        $user = $userModel->find($_SESSION['user_id']);
        
        // 渲染设置页面
        View::render('user/settings', ['user' => $user]);
    }
    
    /**
     * 更新用户设置
     */
    public function updateSettings() {
        // 验证用户是否已登录
        AuthMiddleware::requireAuth();
        
        // 处理表单提交
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // 获取设置数据
            $settings = [
                'email_notification' => isset($_POST['email_notification']) ? 1 : 0,
                'reply_notification' => isset($_POST['reply_notification']) ? 1 : 0,
                'dark_mode' => isset($_POST['dark_mode']) ? 1 : 0,
                'language' => isset($_POST['language']) ? $_POST['language'] : 'zh-CN'
            ];
            
            // 更新用户设置（在实际项目中，这里应该保存到数据库）
            // 暂时保存到会话中
            $_SESSION['settings'] = $settings;
            
            $_SESSION['message'] = [
                'type' => 'success',
                'text' => '设置已更新'
            ];
            
            header('Location: /user/settings');
            exit;
        }
        
        header('Location: /user/settings');
        exit;
    }
}