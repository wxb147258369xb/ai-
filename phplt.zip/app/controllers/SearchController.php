<?php

namespace controllers;

class SearchController {
    private $db;
    private $forumModel;
    private $threadModel;
    private $replyModel;
    private $userModel;
    
    public function __construct() {
        // 初始化数据库连接
        $this->db = Database::getInstance();
        
        // 初始化模型
        $this->forumModel = new Forum($this->db);
        $this->threadModel = new Thread($this->db);
        $this->replyModel = new Reply($this->db);
        $this->userModel = new User($this->db);
    }
    
    /**
     * 搜索功能主入口
     */
    public function search() {
        // 获取搜索参数
        $query = isset($_GET['q']) ? trim($_GET['q']) : '';
        $type = isset($_GET['type']) ? $_GET['type'] : 'all'; // all, thread, reply, user
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 10;
        $offset = ($page - 1) * $limit;
        
        // 检查搜索关键词
        if (empty($query)) {
            $this->renderSearchPage([
                'query' => '',
                'type' => $type,
                'results' => [],
                'total' => 0,
                'page' => 1,
                'pages' => 1,
                'error' => '请输入搜索关键词'
            ]);
            return;
        }
        
        // 记录搜索日志
        $this->logSearch($query);
        
        try {
            $results = [];
            $total = 0;
            
            // 根据类型执行不同的搜索
            switch ($type) {
                case 'thread':
                    $results = $this->searchThreads($query, $limit, $offset);
                    $total = $this->countThreadResults($query);
                    break;
                case 'reply':
                    $results = $this->searchReplies($query, $limit, $offset);
                    $total = $this->countReplyResults($query);
                    break;
                case 'user':
                    $results = $this->searchUsers($query, $limit, $offset);
                    $total = $this->countUserResults($query);
                    break;
                default: // 'all'
                    $results = $this->searchAll($query, $limit, $offset);
                    $total = $this->countAllResults($query);
            }
            
            // 计算总页数
            $pages = ceil($total / $limit);
            
            // 渲染搜索结果页面
            $this->renderSearchPage([
                'query' => $query,
                'type' => $type,
                'results' => $results,
                'total' => $total,
                'page' => $page,
                'pages' => $pages,
                'error' => null
            ]);
            
        } catch (Exception $e) {
            // 错误处理
            $this->renderSearchPage([
                'query' => $query,
                'type' => $type,
                'results' => [],
                'total' => 0,
                'page' => 1,
                'pages' => 1,
                'error' => '搜索过程中发生错误: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * 搜索话题
     */
    private function searchThreads($query, $limit, $offset) {
        $stmt = $this->db->prepare("
            SELECT t.*, u.username as author_username, u.avatar as author_avatar, 
                   COUNT(r.id) as reply_count, 
                   (SELECT COUNT(*) FROM thread_likes WHERE thread_id = t.id) as likes_count
            FROM threads t
            LEFT JOIN users u ON t.user_id = u.id
            LEFT JOIN replies r ON t.id = r.thread_id
            WHERE t.title LIKE :query OR t.content LIKE :query
            GROUP BY t.id
            ORDER BY t.created_at DESC
            LIMIT :limit OFFSET :offset
        ");
        
        $searchQuery = '%' . $query . '%';
        $stmt->bindParam(':query', $searchQuery, PDO::PARAM_STR);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * 统计话题搜索结果数量
     */
    private function countThreadResults($query) {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as count
            FROM threads
            WHERE title LIKE :query OR content LIKE :query
        ");
        
        $searchQuery = '%' . $query . '%';
        $stmt->bindParam(':query', $searchQuery, PDO::PARAM_STR);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'];
    }
    
    /**
     * 搜索回复
     */
    private function searchReplies($query, $limit, $offset) {
        $stmt = $this->db->prepare("
            SELECT r.*, u.username as author_username, u.avatar as author_avatar,
                   t.title as thread_title, t.id as thread_id
            FROM replies r
            LEFT JOIN users u ON r.user_id = u.id
            LEFT JOIN threads t ON r.thread_id = t.id
            WHERE r.content LIKE :query
            ORDER BY r.created_at DESC
            LIMIT :limit OFFSET :offset
        ");
        
        $searchQuery = '%' . $query . '%';
        $stmt->bindParam(':query', $searchQuery, PDO::PARAM_STR);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * 统计回复搜索结果数量
     */
    private function countReplyResults($query) {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as count
            FROM replies
            WHERE content LIKE :query
        ");
        
        $searchQuery = '%' . $query . '%';
        $stmt->bindParam(':query', $searchQuery, PDO::PARAM_STR);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'];
    }
    
    /**
     * 搜索用户
     */
    private function searchUsers($query, $limit, $offset) {
        $stmt = $this->db->prepare("
            SELECT u.*,
                   (SELECT COUNT(*) FROM threads WHERE user_id = u.id) as thread_count,
                   (SELECT COUNT(*) FROM replies WHERE user_id = u.id) as reply_count,
                   (SELECT COUNT(*) FROM user_followers WHERE followed_id = u.id) as follower_count
            FROM users u
            WHERE u.username LIKE :query OR u.email LIKE :query OR u.bio LIKE :query
            ORDER BY u.created_at DESC
            LIMIT :limit OFFSET :offset
        ");
        
        $searchQuery = '%' . $query . '%';
        $stmt->bindParam(':query', $searchQuery, PDO::PARAM_STR);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * 统计用户搜索结果数量
     */
    private function countUserResults($query) {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as count
            FROM users
            WHERE username LIKE :query OR email LIKE :query OR bio LIKE :query
        ");
        
        $searchQuery = '%' . $query . '%';
        $stmt->bindParam(':query', $searchQuery, PDO::PARAM_STR);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'];
    }
    
    /**
     * 搜索所有内容（混合结果）
     */
    private function searchAll($query, $limit, $offset) {
        // 这里我们将分别获取不同类型的结果，然后合并
        $threads = $this->searchThreads($query, ceil($limit/3), 0);
        $replies = $this->searchReplies($query, ceil($limit/3), 0);
        $users = $this->searchUsers($query, ceil($limit/3), 0);
        
        // 为每个结果添加类型标识
        foreach ($threads as &$thread) {
            $thread['result_type'] = 'thread';
        }
        foreach ($replies as &$reply) {
            $reply['result_type'] = 'reply';
        }
        foreach ($users as &$user) {
            $user['result_type'] = 'user';
        }
        
        // 合并结果
        $results = array_merge($threads, $replies, $users);
        
        // 按时间排序
        usort($results, function($a, $b) {
            return strtotime($b['created_at']) - strtotime($a['created_at']);
        });
        
        // 限制结果数量
        return array_slice($results, 0, $limit);
    }
    
    /**
     * 统计所有搜索结果数量
     */
    private function countAllResults($query) {
        return $this->countThreadResults($query) + $this->countReplyResults($query) + $this->countUserResults($query);
    }
    
    /**
     * 记录搜索日志
     */
    private function logSearch($query) {
        // 简单的搜索日志记录
        $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
        $ip = $_SERVER['REMOTE_ADDR'];
        
        try {
            $stmt = $this->db->prepare("
                INSERT INTO search_logs (query, user_id, ip, created_at)
                VALUES (:query, :user_id, :ip, NOW())
            ");
            
            $stmt->bindParam(':query', $query, PDO::PARAM_STR);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':ip', $ip, PDO::PARAM_STR);
            $stmt->execute();
        } catch (Exception $e) {
            // 忽略日志记录错误
        }
    }
    
    /**
     * 渲染搜索结果页面
     */
    private function renderSearchPage($data) {
        // 获取热门搜索
        $hotSearches = $this->getHotSearches();
        
        // 获取相关搜索建议
        $relatedSearches = [];
        if (!empty($data['query'])) {
            $relatedSearches = $this->getRelatedSearches($data['query']);
        }
        
        // 渲染视图
        include ROOT_PATH . '/app/views/search/results.php';
    }
    
    /**
     * 获取热门搜索
     */
    private function getHotSearches() {
        try {
            $stmt = $this->db->prepare("
                SELECT query, COUNT(*) as count
                FROM search_logs
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                GROUP BY query
                ORDER BY count DESC
                LIMIT 10
            ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
    /**
     * 获取相关搜索建议
     */
    private function getRelatedSearches($query) {
        // 简单的相关搜索建议实现
        // 实际项目中可能需要更复杂的算法
        $related = [];
        
        try {
            $stmt = $this->db->prepare("
                SELECT DISTINCT query
                FROM search_logs
                WHERE query LIKE :query AND query != :exact_query
                GROUP BY query
                ORDER BY COUNT(*) DESC
                LIMIT 5
            ");
            
            $likeQuery = '%' . $query . '%';
            $stmt->bindParam(':query', $likeQuery, PDO::PARAM_STR);
            $stmt->bindParam(':exact_query', $query, PDO::PARAM_STR);
            $stmt->execute();
            $related = $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (Exception $e) {
            // 忽略错误
        }
        
        return $related;
    }
    
    /**
     * 搜索自动完成
     */
    public function autocomplete() {
        $query = isset($_GET['q']) ? trim($_GET['q']) : '';
        $suggestions = [];
        
        if (!empty($query) && strlen($query) >= 2) {
            try {
                // 获取话题标题建议
                $threadStmt = $this->db->prepare("
                    SELECT title as suggestion, 'thread' as type
                    FROM threads
                    WHERE title LIKE :query
                    ORDER BY created_at DESC
                    LIMIT 5
                ");
                $searchQuery = '%' . $query . '%';
                $threadStmt->bindParam(':query', $searchQuery, PDO::PARAM_STR);
                $threadStmt->execute();
                $threadSuggestions = $threadStmt->fetchAll(PDO::FETCH_ASSOC);
                
                // 获取用户名建议
                $userStmt = $this->db->prepare("
                    SELECT username as suggestion, 'user' as type
                    FROM users
                    WHERE username LIKE :query
                    ORDER BY username
                    LIMIT 3
                ");
                $userStmt->bindParam(':query', $searchQuery, PDO::PARAM_STR);
                $userStmt->execute();
                $userSuggestions = $userStmt->fetchAll(PDO::FETCH_ASSOC);
                
                // 合并建议
                $suggestions = array_merge($threadSuggestions, $userSuggestions);
            } catch (Exception $e) {
                // 忽略错误
            }
        }
        
        // 返回JSON格式的建议
        header('Content-Type: application/json');
        echo json_encode($suggestions);
        exit;
    }
}