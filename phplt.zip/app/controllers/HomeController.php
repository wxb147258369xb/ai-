<?php
/**
 * 首页控制器
 */
namespace controllers;

class HomeController {
    
    /**
     * 首页方法
     */
    public function index() {
        // 获取版块数据
        $forums = $this->getForums();
        
        // 获取热门话题
        $hotThreads = $this->getHotThreads();
        
        // 获取最新话题
        $latestThreads = $this->getLatestThreads();
        
        // 获取排行榜数据
        $rankings = $this->getRankings();
        
        // 渲染视图
        $this->view('home', [
            'forums' => $forums,
            'hotThreads' => $hotThreads,
            'latestThreads' => $latestThreads,
            'rankings' => $rankings
        ]);
    }
    
    /**
     * 获取版块数据
     */
    private function getForums() {
        // 模拟数据，实际应从数据库获取
        return [
            [
                'id' => 1,
                'name' => '技术讨论',
                'description' => '分享技术心得，解决编程问题',
                'icon' => 'code',
                'color' => '#00ff00',
                'thread_count' => 128,
                'reply_count' => 2105,
                'latest_thread' => [
                    'title' => 'PHP 8.0 新特性详解',
                    'user' => 'user2',
                    'time' => '2小时前'
                ]
            ],
            [
                'id' => 2,
                'name' => '游戏世界',
                'description' => '游戏攻略、心得交流',
                'icon' => 'game',
                'color' => '#ff00ff',
                'thread_count' => 95,
                'reply_count' => 1782,
                'latest_thread' => [
                    'title' => '赛博朋克2077最新更新内容',
                    'user' => 'user3',
                    'time' => '4小时前'
                ]
            ],
            [
                'id' => 3,
                'name' => '创意设计',
                'description' => '设计灵感、作品展示',
                'icon' => 'design',
                'color' => '#00bfff',
                'thread_count' => 76,
                'reply_count' => 1243,
                'latest_thread' => [
                    'title' => '如何创建赛博朋克风格的UI设计',
                    'user' => 'user2',
                    'time' => '昨天'
                ]
            ],
            [
                'id' => 4,
                'name' => '生活闲聊',
                'description' => '日常生活、兴趣爱好',
                'icon' => 'life',
                'color' => '#ff6600',
                'thread_count' => 210,
                'reply_count' => 3567,
                'latest_thread' => [
                    'title' => '程序员的周末生活',
                    'user' => 'user1',
                    'time' => '3天前'
                ]
            ],
            [
                'id' => 5,
                'name' => '站务公告',
                'description' => '论坛规则、系统公告',
                'icon' => 'notice',
                'color' => '#ff0000',
                'thread_count' => 12,
                'reply_count' => 456,
                'latest_thread' => [
                    'title' => '论坛新功能预告',
                    'user' => 'admin',
                    'time' => '1周前'
                ]
            ]
        ];
    }
    
    /**
     * 获取热门话题
     */
    private function getHotThreads() {
        // 模拟数据
        return [
            [
                'id' => 1,
                'title' => 'PHP 8.0 新特性详解',
                'forum' => '技术讨论',
                'user' => 'user2',
                'view_count' => 2456,
                'reply_count' => 128,
                'time' => '2小时前'
            ],
            [
                'id' => 2,
                'title' => '赛博朋克2077最新更新内容',
                'forum' => '游戏世界',
                'user' => 'user3',
                'view_count' => 3241,
                'reply_count' => 235,
                'time' => '4小时前'
            ],
            [
                'id' => 5,
                'title' => '论坛新功能预告',
                'forum' => '站务公告',
                'user' => 'admin',
                'view_count' => 5678,
                'reply_count' => 456,
                'time' => '1周前'
            ]
        ];
    }
    
    /**
     * 获取最新话题
     */
    private function getLatestThreads() {
        // 模拟数据
        return [
            [
                'id' => 1,
                'title' => 'PHP 8.0 新特性详解',
                'forum' => '技术讨论',
                'user' => 'user2',
                'time' => '2小时前'
            ],
            [
                'id' => 2,
                'title' => '赛博朋克2077最新更新内容',
                'forum' => '游戏世界',
                'user' => 'user3',
                'time' => '4小时前'
            ],
            [
                'id' => 3,
                'title' => '如何创建赛博朋克风格的UI设计',
                'forum' => '创意设计',
                'user' => 'user2',
                'time' => '昨天'
            ],
            [
                'id' => 4,
                'title' => '程序员的周末生活',
                'forum' => '生活闲聊',
                'user' => 'user1',
                'time' => '3天前'
            ]
        ];
    }
    
    /**
     * 获取排行榜数据
     */
    private function getRankings() {
        // 模拟数据
        return [
            'users' => [
                ['id' => 2, 'username' => 'user2', 'points' => 5678, 'rank' => 1],
                ['id' => 3, 'username' => 'user3', 'points' => 4321, 'rank' => 2],
                ['id' => 1, 'username' => 'user1', 'points' => 3456, 'rank' => 3],
                ['id' => 4, 'username' => 'user4', 'points' => 2345, 'rank' => 4],
                ['id' => 5, 'username' => 'user5', 'points' => 1234, 'rank' => 5]
            ],
            'threads' => [
                ['id' => 5, 'title' => '论坛新功能预告', 'views' => 5678, 'rank' => 1],
                ['id' => 2, 'title' => '赛博朋克2077最新更新内容', 'views' => 3241, 'rank' => 2],
                ['id' => 1, 'title' => 'PHP 8.0 新特性详解', 'views' => 2456, 'rank' => 3]
            ]
        ];
    }
    
    /**
     * 加载视图文件
     */
    protected function view($viewName, $data = []) {
        // 提取数据到当前作用域
        extract($data);
        
        // 构建视图路径
        $viewPath = ROOT_PATH . '/app/views/' . $viewName . '.php';
        
        // 检查视图文件是否存在
        if (file_exists($viewPath)) {
            // 包含布局文件
            include_once ROOT_PATH . '/app/views/layouts/header.php';
            include_once $viewPath;
            include_once ROOT_PATH . '/app/views/layouts/footer.php';
        } else {
            echo '视图文件不存在: ' . $viewName;
        }
    }
}