<?php
/**
 * 回复控制器
 * 处理回复相关的所有操作
 */
class ReplyController {
    /**
     * 发布回复
     */
    public function reply() {
        // 验证用户是否已登录
        AuthMiddleware::requireAuth();
        
        // 检查请求方法
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /');
            exit;
        }
        
        // 获取表单数据
        $threadId = isset($_POST['thread_id']) ? $_POST['thread_id'] : 0;
        $content = isset($_POST['content']) ? trim($_POST['content']) : '';
        $page = isset($_POST['page']) ? $_POST['page'] : 1;
        
        // 表单验证
        if (!$threadId || !$content) {
            $_SESSION['message'] = [
                'type' => 'error',
                'text' => '请填写所有必填字段'
            ];
            header('Location: /thread/show/' . $threadId . '?page=' . $page);
            exit;
        }
        
        if (strlen($content) < 5) {
            $_SESSION['message'] = [
                'type' => 'error',
                'text' => '回复内容至少需要5个字符'
            ];
            header('Location: /thread/show/' . $threadId . '?page=' . $page);
            exit;
        }
        
        // 创建回复
        $replyModel = new Reply();
        try {
            $result = $replyModel->createReply([
                'thread_id' => $threadId,
                'user_id' => $_SESSION['user_id'],
                'content' => $content
            ]);
            
            if ($result) {
                // 增加用户积分（发布回复获得积分）
                $userModel = new User();
                $userModel->addPoints($_SESSION['user_id'], 5);
                
                // 更新会话中的用户积分
                $_SESSION['points'] += 5;
                
                $_SESSION['message'] = [
                    'type' => 'success',
                    'text' => '回复发布成功！'
                ];
                
                // 获取最新的页面数，跳转到最后一页
                $threadModel = new Thread();
                $thread = $threadModel->find($threadId);
                $newPage = ceil($thread['reply_count'] / 10); // 假设每页10条回复
                
                header('Location: /thread/show/' . $threadId . '?page=' . $newPage . '#latest-reply');
                exit;
            } else {
                throw new Exception('回复发布失败');
            }
        } catch (Exception $e) {
            $_SESSION['message'] = [
                'type' => 'error',
                'text' => $e->getMessage()
            ];
            header('Location: /thread/show/' . $threadId . '?page=' . $page);
            exit;
        }
    }
    
    /**
     * 删除回复
     * @param int $id 回复ID
     */
    public function delete($id) {
        // 验证用户是否已登录
        AuthMiddleware::requireAuth();
        
        // 获取回复信息
        $replyModel = new Reply();
        $reply = $replyModel->getReplyDetails($id);
        
        if (!$reply) {
            $_SESSION['message'] = [
                'type' => 'error',
                'text' => '回复不存在'
            ];
            header('Location: /');
            exit;
        }
        
        // 检查权限（只有回复作者或管理员可以删除）
        if (!AuthMiddleware::isOwnerOrAdmin($reply['user_id'])) {
            $_SESSION['message'] = [
                'type' => 'error',
                'text' => '无权限删除此回复'
            ];
            header('Location: /thread/show/' . $reply['thread_id']);
            exit;
        }
        
        // 执行删除
        try {
            $result = $replyModel->deleteReply($id);
            
            if ($result) {
                // 如果是作者删除自己的回复，减少积分
                if ($reply['user_id'] == $_SESSION['user_id']) {
                    $userModel = new User();
                    $userModel->reducePoints($_SESSION['user_id'], 5);
                    
                    // 更新会话中的用户积分
                    $_SESSION['points'] = max(0, $_SESSION['points'] - 5);
                }
                
                $_SESSION['message'] = [
                    'type' => 'success',
                    'text' => '回复已删除'
                ];
            } else {
                throw new Exception('删除回复失败');
            }
        } catch (Exception $e) {
            $_SESSION['message'] = [
                'type' => 'error',
                'text' => $e->getMessage()
            ];
        }
        
        header('Location: /thread/show/' . $reply['thread_id']);
        exit;
    }
    
    /**
     * 点赞回复
     * @param int $id 回复ID
     */
    public function like($id) {
        // 验证用户是否已登录
        AuthMiddleware::requireAuth();
        
        // 获取回复信息
        $replyModel = new Reply();
        $reply = $replyModel->getReplyDetails($id);
        
        if (!$reply) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => '回复不存在'
            ]);
            exit;
        }
        
        // 检查是否已经点赞
        $isLiked = $replyModel->isLiked($id, $_SESSION['user_id']);
        
        try {
            if ($isLiked) {
                // 取消点赞
                $result = $replyModel->unlikeReply($id, $_SESSION['user_id']);
                $action = 'unlike';
            } else {
                // 点赞
                $result = $replyModel->likeReply($id, $_SESSION['user_id']);
                $action = 'like';
                
                // 给回复作者增加积分
                if ($reply['user_id'] != $_SESSION['user_id']) { // 不能给自己的回复点赞获得积分
                    $userModel = new User();
                    $userModel->addPoints($reply['user_id'], 2);
                }
            }
            
            if ($result) {
                // 获取最新的点赞数
                $likeCount = $replyModel->getLikeCount($id);
                
                header('Content-Type: application/json');
                echo json_encode([
                    'success' => true,
                    'action' => $action,
                    'like_count' => $likeCount,
                    'is_liked' => $action === 'like'
                ]);
            } else {
                throw new Exception('操作失败');
            }
        } catch (Exception $e) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * 获取用户的回复列表
     * @param int $userId 用户ID
     */
    public function getUserReplies($userId) {
        // 获取用户信息
        $userModel = new User();
        $user = $userModel->find($userId);
        
        if (!$user) {
            $_SESSION['message'] = [
                'type' => 'error',
                'text' => '用户不存在'
            ];
            header('Location: /');
            exit;
        }
        
        // 获取分页参数
        $page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;
        $perPage = 10;
        
        // 获取用户回复列表
        $replyModel = new Reply();
        $replies = $replyModel->getUserReplies($userId, $page, $perPage);
        
        // 获取用户总回复数
        $totalReplies = $userModel->getReplyCount($userId);
        $totalPages = ceil($totalReplies / $perPage);
        
        // 渲染视图
        $data = [
            'user' => $user,
            'replies' => $replies,
            'page' => $page,
            'total_pages' => $totalPages,
            'total_replies' => $totalReplies
        ];
        
        View::render('user/replies', $data);
    }
}