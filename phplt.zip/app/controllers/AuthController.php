<?php
/**
 * 用户认证控制器
 */
namespace controllers;

class AuthController {
    
    /**
     * 登录页面
     */
    public function login() {
        // 如果用户已登录，重定向到首页
        if (isset($_SESSION['user_id'])) {
            header('Location: /');
            exit;
        }
        
        // 渲染登录视图
        $this->view('auth/login');
    }
    
    /**
     * 处理登录请求
     */
    public function doLogin() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            
            // 简单验证
            if (empty($username) || empty($password)) {
                $_SESSION['error'] = '请输入用户名和密码';
                header('Location: /auth/login');
                exit;
            }
            
            // 模拟用户验证（实际应从数据库获取）
            // 这里使用设计文档中的默认管理员账户
            $validUsers = [
                ['id' => 1, 'username' => 'admin', 'password' => 'admin123', 'email' => 'admin@nexus.com', 'role' => 'admin'],
                ['id' => 2, 'username' => 'user1', 'password' => 'user123', 'email' => 'user1@example.com', 'role' => 'user']
            ];
            
            $user = null;
            foreach ($validUsers as $validUser) {
                // 实际项目中应该使用password_verify验证哈希密码
                if ($validUser['username'] === $username && $validUser['password'] === $password) {
                    $user = $validUser;
                    break;
                }
            }
            
            if ($user) {
                // 设置会话信息
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['email'] = $user['email'];
                
                $_SESSION['success'] = '登录成功';
                header('Location: /');
                exit;
            } else {
                $_SESSION['error'] = '用户名或密码错误';
                header('Location: /auth/login');
                exit;
            }
        }
        
        // 如果不是POST请求，重定向到登录页面
        header('Location: /auth/login');
        exit;
    }
    
    /**
     * 注册页面
     */
    public function register() {
        // 如果用户已登录，重定向到首页
        if (isset($_SESSION['user_id'])) {
            header('Location: /');
            exit;
        }
        
        // 渲染注册视图
        $this->view('auth/register');
    }
    
    /**
     * 处理注册请求
     */
    public function doRegister() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'] ?? '';
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            
            // 验证输入
            $errors = [];
            
            if (empty($username)) {
                $errors[] = '请输入用户名';
            } elseif (strlen($username) < 3) {
                $errors[] = '用户名至少需要3个字符';
            }
            
            if (empty($email)) {
                $errors[] = '请输入邮箱';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = '请输入有效的邮箱地址';
            }
            
            if (empty($password)) {
                $errors[] = '请输入密码';
            } elseif (strlen($password) < 6) {
                $errors[] = '密码至少需要6个字符';
            }
            
            if ($password !== $confirmPassword) {
                $errors[] = '两次输入的密码不一致';
            }
            
            // 模拟用户名和邮箱已存在检查
            $existingUsers = ['admin', 'user1', 'user2', 'user3'];
            $existingEmails = ['admin@nexus.com', 'user1@example.com'];
            
            if (in_array($username, $existingUsers)) {
                $errors[] = '用户名已存在';
            }
            
            if (in_array($email, $existingEmails)) {
                $errors[] = '邮箱已被注册';
            }
            
            if (!empty($errors)) {
                $_SESSION['errors'] = $errors;
                $_SESSION['form_data'] = $_POST;
                header('Location: /auth/register');
                exit;
            }
            
            // 模拟注册成功（实际应插入数据库）
            $_SESSION['success'] = '注册成功，请登录';
            header('Location: /auth/login');
            exit;
        }
        
        // 如果不是POST请求，重定向到注册页面
        header('Location: /auth/register');
        exit;
    }
    
    /**
     * 注销
     */
    public function logout() {
        // 清除会话信息
        session_unset();
        session_destroy();
        
        // 重定向到首页
        $_SESSION = [];
        session_start();
        $_SESSION['success'] = '已成功退出登录';
        header('Location: /');
        exit;
    }
    
    /**
     * 用户个人资料页面
     */
    public function profile($userId = null) {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['error'] = '请先登录';
            header('Location: /auth/login');
            exit;
        }
        
        // 如果没有指定用户ID，使用当前登录用户的ID
        $targetUserId = $userId ?? $_SESSION['user_id'];
        
        // 模拟用户数据
        $userData = [
            'id' => $targetUserId,
            'username' => $targetUserId == 1 ? 'admin' : 'user' . $targetUserId,
            'email' => $targetUserId == 1 ? 'admin@nexus.com' : 'user' . $targetUserId . '@example.com',
            'avatar' => '/images/default-avatar.jpg',
            'joined_date' => '2024-01-01',
            'posts_count' => rand(10, 500),
            'replies_count' => rand(50, 1000),
            'points' => rand(1000, 10000),
            'level' => 'Level ' . floor(rand(1, 10)),
            'signature' => '这是一个很酷的签名',
            'is_online' => true,
            'last_active' => '刚刚'
        ];
        
        // 渲染个人资料视图
        $this->view('auth/profile', ['user' => $userData]);
    }
    
    /**
     * 编辑个人资料
     */
    public function editProfile() {
        // 检查用户是否登录
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['error'] = '请先登录';
            header('Location: /auth/login');
            exit;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            $signature = $_POST['signature'] ?? '';
            
            // 简单验证
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $_SESSION['error'] = '请输入有效的邮箱地址';
                header('Location: /auth/edit-profile');
                exit;
            }
            
            // 模拟更新成功
            $_SESSION['success'] = '个人资料已更新';
            // 更新会话中的邮箱
            $_SESSION['email'] = $email;
            
            header('Location: /auth/profile');
            exit;
        }
        
        // 渲染编辑个人资料视图
        $this->view('auth/edit-profile', ['user' => [
            'id' => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'email' => $_SESSION['email'],
            'signature' => '这是一个很酷的签名'
        ]]);
    }
    
    /**
     * 加载视图文件
     */
    protected function view($viewName, $data = []) {
        // 提取数据到当前作用域
        extract($data);
        
        // 构建视图路径
        $viewPath = ROOT_PATH . '/app/views/' . $viewName . '.php';
        
        // 检查视图文件是否存在
        if (file_exists($viewPath)) {
            // 包含布局文件
            include_once ROOT_PATH . '/app/views/layouts/header.php';
            include_once $viewPath;
            include_once ROOT_PATH . '/app/views/layouts/footer.php';
        } else {
            echo '视图文件不存在: ' . $viewName;
        }
    }
}