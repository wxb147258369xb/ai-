<?php
/**
 * 基础模型类
 */
class Model {
    protected $db;
    protected $table;
    protected $primaryKey = 'id';

    /**
     * 构造函数，初始化数据库连接
     */
    public function __construct() {
        $this->db = new Database();
    }

    /**
     * 设置表名
     */
    protected function setTable($table) {
        $this->table = $table;
        return $this;
    }

    /**
     * 设置主键
     */
    protected function setPrimaryKey($primaryKey) {
        $this->primaryKey = $primaryKey;
        return $this;
    }

    /**
     * 获取所有记录
     */
    public function all() {
        $this->db->query("SELECT * FROM {$this->table}");
        return $this->db->resultSet();
    }

    /**
     * 根据条件获取记录
     */
    public function where($field, $value, $operator = '=') {
        $this->db->query("SELECT * FROM {$this->table} WHERE {$field} {$operator} :value");
        $this->db->bind(':value', $value);
        return $this->db->resultSet();
    }

    /**
     * 根据ID获取记录
     */
    public function find($id) {
        $this->db->query("SELECT * FROM {$this->table} WHERE {$this->primaryKey} = :id");
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    /**
     * 创建记录
     */
    public function create($data) {
        $fields = implode(', ', array_keys($data));
        $values = ':' . implode(', :', array_keys($data));

        $this->db->query("INSERT INTO {$this->table} ({$fields}) VALUES ({$values})");

        foreach ($data as $key => $value) {
            $this->db->bind(':'. $key, $value);
        }

        if ($this->db->execute()) {
            return $this->db->lastInsertId();
        }

        return false;
    }

    /**
     * 更新记录
     */
    public function update($id, $data) {
        $set = '';
        foreach (array_keys($data) as $key) {
            $set .= "{$key} = :{$key}, ";
        }
        $set = rtrim($set, ', ');

        $this->db->query("UPDATE {$this->table} SET {$set} WHERE {$this->primaryKey} = :id");
        $this->db->bind(':id', $id);

        foreach ($data as $key => $value) {
            $this->db->bind(':'. $key, $value);
        }

        return $this->db->execute();
    }

    /**
     * 删除记录
     */
    public function delete($id) {
        $this->db->query("DELETE FROM {$this->table} WHERE {$this->primaryKey} = :id");
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    /**
     * 自定义查询
     */
    public function query($sql, $params = []) {
        $this->db->query($sql);
        
        foreach ($params as $key => $value) {
            $this->db->bind($key, $value);
        }

        return $this->db->resultSet();
    }

    /**
     * 获取单行数据的自定义查询
     */
    public function querySingle($sql, $params = []) {
        $this->db->query($sql);
        
        foreach ($params as $key => $value) {
            $this->db->bind($key, $value);
        }

        return $this->db->single();
    }

    /**
     * 分页查询
     */
    public function paginate($page = 1, $limit = 10, $where = '', $params = []) {
        $offset = ($page - 1) * $limit;
        $sql = "SELECT * FROM {$this->table}";
        $countSql = "SELECT COUNT(*) as total FROM {$this->table}";

        if (!empty($where)) {
            $sql .= " WHERE {$where}";
            $countSql .= " WHERE {$where}";
        }

        $sql .= " LIMIT :limit OFFSET :offset";

        // 获取总数
        $this->db->query($countSql);
        foreach ($params as $key => $value) {
            $this->db->bind($key, $value);
        }
        $total = $this->db->single()['total'];

        // 获取分页数据
        $this->db->query($sql);
        foreach ($params as $key => $value) {
            $this->db->bind($key, $value);
        }
        $this->db->bind(':limit', $limit);
        $this->db->bind(':offset', $offset);
        $data = $this->db->resultSet();

        return [
            'data' => $data,
            'total' => $total,
            'pages' => ceil($total / $limit),
            'page' => $page,
            'limit' => $limit
        ];
    }
}