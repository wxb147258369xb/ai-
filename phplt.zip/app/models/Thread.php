<?php
/**
 * 话题模型类
 */
class Thread extends Model {
    /**
     * 构造函数，设置表名和主键
     */
    public function __construct() {
        parent::__construct();
        $this->setTable('threads');
        $this->setPrimaryKey('id');
    }

    /**
     * 获取话题详情
     */
    public function getThreadDetails($threadId) {
        $sql = "SELECT 
                    t.*, 
                    u.username as author_username, 
                    u.avatar as author_avatar,
                    u.role as author_role,
                    u.points as author_points,
                    f.name as forum_name,
                    COUNT(DISTINCT r.id) as reply_count,
                    COALESCE((SELECT MAX(r.created_at) FROM replies r WHERE r.thread_id = t.id), t.created_at) as last_activity,
                    COALESCE((SELECT u2.username FROM replies r 
                              LEFT JOIN users u2 ON r.user_id = u2.id 
                              WHERE r.thread_id = t.id 
                              ORDER BY r.created_at DESC 
                              LIMIT 1), '') as last_replier_username
                FROM 
                    threads t
                LEFT JOIN 
                    users u ON t.user_id = u.id
                LEFT JOIN 
                    forums f ON t.forum_id = f.id
                LEFT JOIN 
                    replies r ON t.id = r.thread_id
                WHERE 
                    t.id = :thread_id
                GROUP BY 
                    t.id, t.title, t.content, t.forum_id, t.user_id, t.view_count, t.reply_count, t.created_at, t.updated_at, t.status, 
                    u.username, u.avatar, u.role, u.points, f.name";
        
        return $this->querySingle($sql, [':thread_id' => $threadId]);
    }

    /**
     * 创建新话题
     */
    public function createThread($data) {
        // 设置创建时间
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        // 设置默认值
        $data['view_count'] = 0;
        $data['reply_count'] = 0;
        $data['status'] = isset($data['status']) ? $data['status'] : 1;
        
        // 开启事务
        $this->db->beginTransaction();
        
        try {
            // 创建话题
            $threadId = $this->create($data);
            
            // 更新版块的最后活动时间
            $this->db->query("UPDATE forums SET updated_at = :updated_at WHERE id = :forum_id");
            $this->db->bind(':updated_at', date('Y-m-d H:i:s'));
            $this->db->bind(':forum_id', $data['forum_id']);
            $this->db->execute();
            
            // 提交事务
            $this->db->commit();
            
            return $threadId;
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            return false;
        }
    }

    /**
     * 更新话题
     */
    public function updateThread($id, $data) {
        // 设置更新时间
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        return $this->update($id, $data);
    }

    /**
     * 增加浏览次数
     */
    public function incrementViewCount($threadId) {
        $this->db->query("UPDATE {$this->table} SET view_count = view_count + 1 WHERE id = :id");
        $this->db->bind(':id', $threadId);
        return $this->db->execute();
    }

    /**
     * 更新回复数量
     */
    public function updateReplyCount($threadId) {
        $this->db->query("UPDATE {$this->table} SET reply_count = (SELECT COUNT(*) FROM replies WHERE thread_id = :thread_id) WHERE id = :thread_id");
        $this->db->bind(':thread_id', $threadId);
        return $this->db->execute();
    }

    /**
     * 获取热门话题
     */
    public function getHotThreads($limit = 10) {
        $sql = "SELECT 
                    t.*, 
                    u.username as author_username,
                    u.avatar as author_avatar,
                    f.name as forum_name
                FROM 
                    threads t
                LEFT JOIN 
                    users u ON t.user_id = u.id
                LEFT JOIN 
                    forums f ON t.forum_id = f.id
                WHERE 
                    t.created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
                ORDER BY 
                    t.reply_count DESC, t.view_count DESC
                LIMIT :limit";
        
        return $this->query($sql, [':limit' => $limit]);
    }

    /**
     * 获取最新话题
     */
    public function getLatestThreads($limit = 10) {
        $sql = "SELECT 
                    t.*, 
                    u.username as author_username,
                    u.avatar as author_avatar,
                    f.name as forum_name
                FROM 
                    threads t
                LEFT JOIN 
                    users u ON t.user_id = u.id
                LEFT JOIN 
                    forums f ON t.forum_id = f.id
                ORDER BY 
                    t.created_at DESC
                LIMIT :limit";
        
        return $this->query($sql, [':limit' => $limit]);
    }

    /**
     * 获取用户发布的话题
     */
    public function getUserThreads($userId, $page = 1, $limit = 10) {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT 
                    t.*, 
                    f.name as forum_name,
                    COUNT(DISTINCT r.id) as reply_count
                FROM 
                    threads t
                LEFT JOIN 
                    forums f ON t.forum_id = f.id
                LEFT JOIN 
                    replies r ON t.id = r.thread_id
                WHERE 
                    t.user_id = :user_id
                GROUP BY 
                    t.id, t.title, t.forum_id, t.view_count, t.reply_count, t.created_at
                ORDER BY 
                    t.created_at DESC
                LIMIT :limit OFFSET :offset";
        
        $this->db->query($sql);
        $this->db->bind(':user_id', $userId);
        $this->db->bind(':limit', $limit);
        $this->db->bind(':offset', $offset);
        $threads = $this->db->resultSet();
        
        // 获取总数
        $this->db->query("SELECT COUNT(*) as total FROM threads WHERE user_id = :user_id");
        $this->db->bind(':user_id', $userId);
        $total = $this->db->single()['total'];
        
        return [
            'data' => $threads,
            'total' => $total,
            'pages' => ceil($total / $limit),
            'page' => $page,
            'limit' => $limit
        ];
    }

    /**
     * 搜索话题
     */
    public function searchThreads($keyword, $page = 1, $limit = 10) {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT 
                    t.*, 
                    u.username as author_username,
                    u.avatar as author_avatar,
                    f.name as forum_name
                FROM 
                    threads t
                LEFT JOIN 
                    users u ON t.user_id = u.id
                LEFT JOIN 
                    forums f ON t.forum_id = f.id
                WHERE 
                    t.title LIKE :keyword OR t.content LIKE :keyword
                ORDER BY 
                    t.created_at DESC
                LIMIT :limit OFFSET :offset";
        
        $this->db->query($sql);
        $this->db->bind(':keyword', '%' . $keyword . '%');
        $this->db->bind(':limit', $limit);
        $this->db->bind(':offset', $offset);
        $threads = $this->db->resultSet();
        
        // 获取总数
        $this->db->query("SELECT COUNT(*) as total FROM threads WHERE title LIKE :keyword OR content LIKE :keyword");
        $this->db->bind(':keyword', '%' . $keyword . '%');
        $total = $this->db->single()['total'];
        
        return [
            'data' => $threads,
            'total' => $total,
            'pages' => ceil($total / $limit),
            'page' => $page,
            'limit' => $limit
        ];
    }

    /**
     * 检查话题是否存在
     */
    public function threadExists($threadId) {
        $this->db->query("SELECT COUNT(*) as count FROM {$this->table} WHERE id = :id");
        $this->db->bind(':id', $threadId);
        return $this->db->single()['count'] > 0;
    }

    /**
     * 删除话题（包括相关回复）
     */
    public function deleteThread($threadId) {
        // 开启事务
        $this->db->beginTransaction();
        
        try {
            // 删除相关回复
            $this->db->query("DELETE FROM replies WHERE thread_id = :thread_id");
            $this->db->bind(':thread_id', $threadId);
            $this->db->execute();
            
            // 删除话题
            $this->db->query("DELETE FROM {$this->table} WHERE id = :thread_id");
            $this->db->bind(':thread_id', $threadId);
            $this->db->execute();
            
            // 提交事务
            $this->db->commit();
            
            return true;
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            return false;
        }
    }
}