<?php
/**
 * 用户模型类
 */
class User extends Model {
    /**
     * 构造函数，设置表名和主键
     */
    public function __construct() {
        parent::__construct();
        $this->setTable('users');
        $this->setPrimaryKey('id');
    }

    /**
     * 根据用户名查找用户
     */
    public function findByUsername($username) {
        return $this->where('username', $username);
    }

    /**
     * 根据邮箱查找用户
     */
    public function findByEmail($email) {
        return $this->where('email', $email);
    }

    /**
     * 用户登录验证
     */
    public function login($username, $password) {
        $this->db->query("SELECT * FROM {$this->table} WHERE username = :username");
        $this->db->bind(':username', $username);
        $user = $this->db->single();

        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }

        return false;
    }

    /**
     * 创建新用户
     */
    public function createUser($data) {
        // 对密码进行哈希处理
        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        // 设置创建时间
        $data['created_at'] = date('Y-m-d H:i:s');
        // 设置默认头像
        if (!isset($data['avatar'])) {
            $data['avatar'] = '/images/default_avatar.png';
        }
        // 设置默认角色
        if (!isset($data['role'])) {
            $data['role'] = 'member';
        }
        // 设置默认积分
        if (!isset($data['points'])) {
            $data['points'] = 0;
        }

        return $this->create($data);
    }

    /**
     * 更新用户资料
     */
    public function updateProfile($id, $data) {
        // 如果更新密码，则进行哈希处理
        if (isset($data['password']) && !empty($data['password'])) {
            $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        } else {
            // 如果不更新密码，移除该字段
            unset($data['password']);
        }

        // 设置更新时间
        $data['updated_at'] = date('Y-m-d H:i:s');

        return $this->update($id, $data);
    }

    /**
     * 获取用户发布的话题数量
     */
    public function getThreadCount($userId) {
        $this->db->query("SELECT COUNT(*) as count FROM threads WHERE user_id = :user_id");
        $this->db->bind(':user_id', $userId);
        return $this->db->single()['count'];
    }

    /**
     * 获取用户的回复数量
     */
    public function getReplyCount($userId) {
        $this->db->query("SELECT COUNT(*) as count FROM replies WHERE user_id = :user_id");
        $this->db->bind(':user_id', $userId);
        return $this->db->single()['count'];
    }

    /**
     * 获取用户活跃的版块
     */
    public function getActiveForums($userId, $limit = 5) {
        $sql = "SELECT f.id, f.name, COUNT(t.id) as thread_count, COUNT(r.id) as reply_count
                FROM forums f
                LEFT JOIN threads t ON f.id = t.forum_id AND t.user_id = :user_id
                LEFT JOIN replies r ON f.id = r.forum_id AND r.user_id = :user_id
                GROUP BY f.id, f.name
                ORDER BY (thread_count + reply_count) DESC
                LIMIT :limit";

        $this->db->query($sql);
        $this->db->bind(':user_id', $userId);
        $this->db->bind(':limit', $limit);
        return $this->db->resultSet();
    }

    /**
     * 增加用户积分
     */
    public function addPoints($userId, $points) {
        $this->db->query("UPDATE {$this->table} SET points = points + :points WHERE id = :id");
        $this->db->bind(':points', $points);
        $this->db->bind(':id', $userId);
        return $this->db->execute();
    }

    /**
     * 减少用户积分
     */
    public function reducePoints($userId, $points) {
        $this->db->query("UPDATE {$this->table} SET points = points - :points WHERE id = :id AND points >= :points");
        $this->db->bind(':points', $points);
        $this->db->bind(':id', $userId);
        return $this->db->execute();
    }

    /**
     * 获取排行榜用户列表
     */
    public function getTopUsers($limit = 10) {
        $this->db->query("SELECT * FROM {$this->table} ORDER BY points DESC, created_at ASC LIMIT :limit");
        $this->db->bind(':limit', $limit);
        return $this->db->resultSet();
    }

    /**
     * 检查用户名是否已存在
     */
    public function usernameExists($username, $excludeId = null) {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE username = :username";
        if ($excludeId) {
            $sql .= " AND id != :id";
        }
        
        $this->db->query($sql);
        $this->db->bind(':username', $username);
        if ($excludeId) {
            $this->db->bind(':id', $excludeId);
        }
        
        return $this->db->single()['count'] > 0;
    }

    /**
     * 检查邮箱是否已存在
     */
    public function emailExists($email, $excludeId = null) {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE email = :email";
        if ($excludeId) {
            $sql .= " AND id != :id";
        }
        
        $this->db->query($sql);
        $this->db->bind(':email', $email);
        if ($excludeId) {
            $this->db->bind(':id', $excludeId);
        }
        
        return $this->db->single()['count'] > 0;
    }
}