<?php
/**
 * 论坛版块模型类
 */
class Forum extends Model {
    /**
     * 构造函数，设置表名和主键
     */
    public function __construct() {
        parent::__construct();
        $this->setTable('forums');
        $this->setPrimaryKey('id');
    }

    /**
     * 获取所有版块，按顺序排列
     */
    public function getAllForums() {
        $this->db->query("SELECT * FROM {$this->table} ORDER BY sort_order ASC");
        return $this->db->resultSet();
    }

    /**
     * 获取活跃版块
     */
    public function getActiveForums($limit = 5) {
        $sql = "SELECT f.*, COUNT(t.id) as thread_count, COUNT(r.id) as reply_count
                FROM forums f
                LEFT JOIN threads t ON f.id = t.forum_id
                LEFT JOIN replies r ON t.id = r.thread_id
                GROUP BY f.id
                ORDER BY (thread_count + reply_count) DESC
                LIMIT :limit";
        
        $this->db->query($sql);
        $this->db->bind(':limit', $limit);
        return $this->db->resultSet();
    }

    /**
     * 获取版块的统计信息
     */
    public function getForumStats($forumId) {
        // 获取版块信息
        $forum = $this->find($forumId);
        if (!$forum) return false;

        // 获取话题数量
        $this->db->query("SELECT COUNT(*) as thread_count FROM threads WHERE forum_id = :forum_id");
        $this->db->bind(':forum_id', $forumId);
        $threadCount = $this->db->single()['thread_count'];

        // 获取回复数量
        $this->db->query("SELECT COUNT(*) as reply_count FROM replies r JOIN threads t ON r.thread_id = t.id WHERE t.forum_id = :forum_id");
        $this->db->bind(':forum_id', $forumId);
        $replyCount = $this->db->single()['reply_count'];

        // 获取最新话题
        $this->db->query("SELECT t.id, t.title, t.created_at, u.username 
                          FROM threads t 
                          JOIN users u ON t.user_id = u.id 
                          WHERE t.forum_id = :forum_id 
                          ORDER BY t.created_at DESC 
                          LIMIT 1");
        $this->db->bind(':forum_id', $forumId);
        $latestThread = $this->db->single();

        return [
            'forum' => $forum,
            'thread_count' => $threadCount,
            'reply_count' => $replyCount,
            'latest_thread' => $latestThread
        ];
    }

    /**
     * 创建新版块
     */
    public function createForum($data) {
        // 设置默认值
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        $data['status'] = isset($data['status']) ? $data['status'] : 1;
        $data['sort_order'] = isset($data['sort_order']) ? $data['sort_order'] : 0;

        return $this->create($data);
    }

    /**
     * 更新版块信息
     */
    public function updateForum($id, $data) {
        // 设置更新时间
        $data['updated_at'] = date('Y-m-d H:i:s');

        return $this->update($id, $data);
    }

    /**
     * 删除版块
     */
    public function deleteForum($id) {
        // 开启事务
        $this->db->beginTransaction();

        try {
            // 删除版块下的所有话题回复
            $this->db->query("DELETE r FROM replies r JOIN threads t ON r.thread_id = t.id WHERE t.forum_id = :forum_id");
            $this->db->bind(':forum_id', $id);
            $this->db->execute();

            // 删除版块下的所有话题
            $this->db->query("DELETE FROM threads WHERE forum_id = :forum_id");
            $this->db->bind(':forum_id', $id);
            $this->db->execute();

            // 删除版块
            $this->db->query("DELETE FROM {$this->table} WHERE id = :id");
            $this->db->bind(':id', $id);
            $this->db->execute();

            // 提交事务
            $this->db->commit();
            return true;
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            return false;
        }
    }

    /**
     * 搜索版块
     */
    public function searchForums($keyword) {
        $this->db->query("SELECT * FROM {$this->table} WHERE name LIKE :keyword OR description LIKE :keyword ORDER BY sort_order ASC");
        $this->db->bind(':keyword', '%' . $keyword . '%');
        return $this->db->resultSet();
    }

    /**
     * 更新版块排序
     */
    public function updateSortOrder($forumId, $sortOrder) {
        $this->db->query("UPDATE {$this->table} SET sort_order = :sort_order WHERE id = :id");
        $this->db->bind(':sort_order', $sortOrder);
        $this->db->bind(':id', $forumId);
        return $this->db->execute();
    }

    /**
     * 切换版块状态
     */
    public function toggleStatus($forumId) {
        $this->db->query("UPDATE {$this->table} SET status = CASE WHEN status = 1 THEN 0 ELSE 1 END WHERE id = :id");
        $this->db->bind(':id', $forumId);
        return $this->db->execute();
    }
}