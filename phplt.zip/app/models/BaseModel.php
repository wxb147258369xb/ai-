<?php
/**
 * 基础模型类
 */
class BaseModel {
    protected $db;
    protected $table;
    protected $primaryKey = 'id';
    protected $allowedFields = [];
    protected $validationRules = [];
    protected $errors = [];

    /**
     * 构造函数
     */
    public function __construct() {
        // 加载数据库助手类
        require_once ROOT_PATH . '/app/helpers/Database.php';
        $this->db = new Database();
        
        // 设置表名
        $this->setTableName();
    }

    /**
     * 自动设置表名
     */
    private function setTableName() {
        // 从类名自动生成表名（例如 UserModel 对应 users 表）
        $className = get_class($this);
        $parts = explode('\\', $className);
        $className = end($parts);
        $tableName = strtolower(preg_replace('/Model$/', '', $className));
        $this->table = strtolower(preg_replace('/(?<!^)[A-Z]/', '_$0', $tableName)) . 's';
    }

    /**
     * 获取所有记录
     */
    public function getAll($limit = null, $offset = 0) {
        $sql = "SELECT * FROM {$this->table}";
        
        if (!is_null($limit)) {
            $sql .= " LIMIT :limit OFFSET :offset";
        }
        
        $this->db->query($sql);
        
        if (!is_null($limit)) {
            $this->db->bind(':limit', (int)$limit);
            $this->db->bind(':offset', (int)$offset);
        }
        
        return $this->db->resultSet();
    }

    /**
     * 根据ID获取记录
     */
    public function getById($id) {
        $sql = "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = :id";
        $this->db->query($sql);
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    /**
     * 根据条件获取记录
     */
    public function getWhere($conditions, $limit = null, $offset = 0, $order = null) {
        $sql = "SELECT * FROM {$this->table} WHERE ";
        $params = [];
        
        // 构建条件
        $whereClauses = [];
        foreach ($conditions as $field => $value) {
            $whereClauses[] = "{$field} = :{$field}";
            $params[":{$field}"] = $value;
        }
        
        $sql .= implode(' AND ', $whereClauses);
        
        // 添加排序
        if (!is_null($order)) {
            $sql .= " ORDER BY {$order}";
        }
        
        // 添加分页
        if (!is_null($limit)) {
            $sql .= " LIMIT :limit OFFSET :offset";
            $params[':limit'] = (int)$limit;
            $params[':offset'] = (int)$offset;
        }
        
        $this->db->query($sql);
        
        // 绑定参数
        foreach ($params as $param => $value) {
            $this->db->bind($param, $value);
        }
        
        return $this->db->resultSet();
    }

    /**
     * 创建新记录
     */
    public function create($data) {
        // 验证数据
        if (!$this->validate($data)) {
            return false;
        }
        
        // 过滤数据，只保留允许的字段
        $data = $this->filterData($data);
        
        // 构建SQL
        $fields = implode(', ', array_keys($data));
        $placeholders = implode(', :', array_keys($data));
        $placeholders = ':' . $placeholders;
        
        $sql = "INSERT INTO {$this->table} ({$fields}) VALUES ({$placeholders})";
        
        $this->db->query($sql);
        
        // 绑定参数
        foreach ($data as $field => $value) {
            $this->db->bind(":{$field}", $value);
        }
        
        // 执行
        if ($this->db->execute()) {
            return $this->db->lastInsertId();
        }
        
        return false;
    }

    /**
     * 更新记录
     */
    public function update($id, $data) {
        // 验证数据
        if (!$this->validate($data, false)) {
            return false;
        }
        
        // 过滤数据，只保留允许的字段
        $data = $this->filterData($data);
        
        // 构建SQL
        $setClauses = [];
        foreach ($data as $field => $value) {
            $setClauses[] = "{$field} = :{$field}";
        }
        
        $sql = "UPDATE {$this->table} SET " . implode(', ', $setClauses) . " WHERE {$this->primaryKey} = :id";
        
        $this->db->query($sql);
        
        // 绑定参数
        foreach ($data as $field => $value) {
            $this->db->bind(":{$field}", $value);
        }
        $this->db->bind(':id', $id);
        
        return $this->db->execute();
    }

    /**
     * 删除记录
     */
    public function delete($id) {
        $sql = "DELETE FROM {$this->table} WHERE {$this->primaryKey} = :id";
        $this->db->query($sql);
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    /**
     * 过滤数据，只保留允许的字段
     */
    protected function filterData($data) {
        $filteredData = [];
        
        foreach ($this->allowedFields as $field) {
            if (isset($data[$field])) {
                $filteredData[$field] = $data[$field];
            }
        }
        
        return $filteredData;
    }

    /**
     * 验证数据
     */
    public function validate($data, $isCreate = true) {
        $this->errors = [];
        
        foreach ($this->validationRules as $field => $rules) {
            $rules = explode('|', $rules);
            $value = isset($data[$field]) ? $data[$field] : null;
            
            foreach ($rules as $rule) {
                // 必填验证
                if ($rule === 'required' && ($value === null || $value === '')) {
                    $this->errors[] = "{$field} 是必填字段";
                }
                
                // 最小长度验证
                if (strpos($rule, 'min_length:') === 0) {
                    $min = substr($rule, 11);
                    if (strlen($value) < $min) {
                        $this->errors[] = "{$field} 长度不能小于 {$min} 个字符";
                    }
                }
                
                // 最大长度验证
                if (strpos($rule, 'max_length:') === 0) {
                    $max = substr($rule, 11);
                    if (strlen($value) > $max) {
                        $this->errors[] = "{$field} 长度不能大于 {$max} 个字符";
                    }
                }
                
                // 邮箱验证
                if ($rule === 'email' && $value && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $this->errors[] = "{$field} 不是有效的邮箱地址";
                }
                
                // 唯一性验证
                if ($rule === 'unique') {
                    $conditions = [$field => $value];
                    if (!$isCreate && isset($data[$this->primaryKey])) {
                        $conditions[] = "{$this->primaryKey} != " . $data[$this->primaryKey];
                    }
                    $results = $this->getWhere($conditions);
                    if (!empty($results)) {
                        $this->errors[] = "{$field} 已经被使用";
                    }
                }
            }
        }
        
        return empty($this->errors);
    }

    /**
     * 获取错误信息
     */
    public function getErrors() {
        return $this->errors;
    }

    /**
     * 获取记录总数
     */
    public function count($conditions = []) {
        $sql = "SELECT COUNT(*) as count FROM {$this->table}";
        
        if (!empty($conditions)) {
            $sql .= " WHERE ";
            $whereClauses = [];
            $params = [];
            
            foreach ($conditions as $field => $value) {
                $whereClauses[] = "{$field} = :{$field}";
                $params[":{$field}"] = $value;
            }
            
            $sql .= implode(' AND ', $whereClauses);
        }
        
        $this->db->query($sql);
        
        // 绑定参数
        if (!empty($params)) {
            foreach ($params as $param => $value) {
                $this->db->bind($param, $value);
            }
        }
        
        $result = $this->db->single();
        return $result['count'];
    }
}