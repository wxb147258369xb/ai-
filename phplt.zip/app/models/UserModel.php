<?php
/**
 * 用户模型类
 */
class UserModel extends BaseModel {
    protected $allowedFields = [
        'username',
        'email', 
        'password',
        'avatar',
        'signature',
        'role',
        'status',
        'created_at',
        'updated_at'
    ];
    
    protected $validationRules = [
        'username' => 'required|min_length:3|max_length:50|unique',
        'email' => 'required|email|max_length:100|unique',
        'password' => 'required|min_length:6|max_length:255'
    ];
    
    /**
     * 验证用户登录
     */
    public function verifyLogin($username, $password) {
        $sql = "SELECT * FROM users WHERE (username = :username OR email = :username) AND status = 1";
        $this->db->query($sql);
        $this->db->bind(':username', $username);
        $user = $this->db->single();
        
        if ($user && password_verify($password, $user['password'])) {
            // 登录成功，移除密码字段后返回用户信息
            unset($user['password']);
            return $user;
        }
        
        return false;
    }
    
    /**
     * 根据用户名获取用户信息
     */
    public function getUserByUsername($username) {
        return $this->getWhere(['username' => $username])[0] ?? null;
    }
    
    /**
     * 根据邮箱获取用户信息
     */
    public function getUserByEmail($email) {
        return $this->getWhere(['email' => $email])[0] ?? null;
    }
    
    /**
     * 创建新用户
     */
    public function createUser($data) {
        // 哈希密码
        if (isset($data['password'])) {
            $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        }
        
        // 设置默认值
        $data['role'] = $data['role'] ?? 'user';
        $data['status'] = $data['status'] ?? 1;
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        return $this->create($data);
    }
    
    /**
     * 更新用户信息
     */
    public function updateUser($id, $data) {
        // 如果需要更新密码，则进行哈希
        if (isset($data['password']) && !empty($data['password'])) {
            $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        } else {
            // 如果密码为空，则不更新密码
            unset($data['password']);
        }
        
        // 更新时间
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        return $this->update($id, $data);
    }
    
    /**
     * 获取用户发布的主题数
     */
    public function getThreadCount($userId) {
        $sql = "SELECT COUNT(*) as count FROM threads WHERE user_id = :userId";
        $this->db->query($sql);
        $this->db->bind(':userId', $userId);
        $result = $this->db->single();
        return $result['count'];
    }
    
    /**
     * 获取用户发布的回复数
     */
    public function getReplyCount($userId) {
        $sql = "SELECT COUNT(*) as count FROM replies WHERE user_id = :userId";
        $this->db->query($sql);
        $this->db->bind(':userId', $userId);
        $result = $this->db->single();
        return $result['count'];
    }
    
    /**
     * 获取用户统计信息
     */
    public function getUserStats($userId) {
        // 获取用户信息
        $user = $this->getById($userId);
        if (!$user) return false;
        
        // 获取主题数
        $threadCount = $this->getThreadCount($userId);
        
        // 获取回复数
        $replyCount = $this->getReplyCount($userId);
        
        // 获取积分
        $sql = "SELECT points FROM user_points WHERE user_id = :userId";
        $this->db->query($sql);
        $this->db->bind(':userId', $userId);
        $points = $this->db->single();
        
        return [
            'user' => $user,
            'thread_count' => $threadCount,
            'reply_count' => $replyCount,
            'points' => $points['points'] ?? 0
        ];
    }
    
    /**
     * 获取活跃用户列表
     */
    public function getActiveUsers($limit = 10) {
        $sql = "SELECT users.*, 
                   (SELECT COUNT(*) FROM threads WHERE user_id = users.id) as thread_count,
                   (SELECT COUNT(*) FROM replies WHERE user_id = users.id) as reply_count,
                   (SELECT points FROM user_points WHERE user_id = users.id) as points
                FROM users 
                WHERE users.status = 1
                ORDER BY (thread_count + reply_count) DESC
                LIMIT :limit";
        
        $this->db->query($sql);
        $this->db->bind(':limit', $limit);
        return $this->db->resultSet();
    }
    
    /**
     * 检查用户名是否已存在
     */
    public function usernameExists($username, $excludeId = null) {
        $conditions = ['username' => $username];
        $users = $this->getWhere($conditions);
        
        if (empty($users)) return false;
        
        // 如果排除特定ID，则检查返回的结果是否包含排除ID
        if ($excludeId) {
            return count(array_filter($users, function($user) use ($excludeId) {
                return $user['id'] != $excludeId;
            })) > 0;
        }
        
        return true;
    }
    
    /**
     * 检查邮箱是否已存在
     */
    public function emailExists($email, $excludeId = null) {
        $conditions = ['email' => $email];
        $users = $this->getWhere($conditions);
        
        if (empty($users)) return false;
        
        // 如果排除特定ID，则检查返回的结果是否包含排除ID
        if ($excludeId) {
            return count(array_filter($users, function($user) use ($excludeId) {
                return $user['id'] != $excludeId;
            })) > 0;
        }
        
        return true;
    }
    
    /**
     * 更新用户积分
     */
    public function updatePoints($userId, $points) {
        // 检查积分记录是否存在
        $sql = "SELECT * FROM user_points WHERE user_id = :userId";
        $this->db->query($sql);
        $this->db->bind(':userId', $userId);
        $result = $this->db->single();
        
        if ($result) {
            // 更新现有积分
            $newPoints = $result['points'] + $points;
            $sql = "UPDATE user_points SET points = :points WHERE user_id = :userId";
        } else {
            // 创建新积分记录
            $newPoints = $points;
            $sql = "INSERT INTO user_points (user_id, points) VALUES (:userId, :points)";
        }
        
        $this->db->query($sql);
        $this->db->bind(':userId', $userId);
        $this->db->bind(':points', $newPoints);
        return $this->db->execute();
    }
}