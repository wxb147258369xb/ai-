<?php
/**
 * 回复模型类
 */
class Reply extends Model {
    /**
     * 构造函数，设置表名和主键
     */
    public function __construct() {
        parent::__construct();
        $this->setTable('replies');
        $this->setPrimaryKey('id');
    }

    /**
     * 获取话题的所有回复
     */
    public function getRepliesByThreadId($threadId, $page = 1, $limit = 20) {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT r.*, u.username, u.avatar, u.rank_id
                FROM replies r
                JOIN users u ON r.user_id = u.id
                WHERE r.thread_id = :thread_id
                ORDER BY r.created_at ASC
                LIMIT :limit OFFSET :offset";
        
        $this->db->query($sql);
        $this->db->bind(':thread_id', $threadId);
        $this->db->bind(':limit', $limit);
        $this->db->bind(':offset', $offset);
        $replies = $this->db->resultSet();
        
        // 获取总数
        $this->db->query("SELECT COUNT(*) as total FROM replies WHERE thread_id = :thread_id");
        $this->db->bind(':thread_id', $threadId);
        $total = $this->db->single()['total'];
        
        return [
            'data' => $replies,
            'total' => $total,
            'pages' => ceil($total / $limit),
            'page' => $page,
            'limit' => $limit
        ];
    }

    /**
     * 创建回复
     */
    public function createReply($data) {
        // 设置创建时间
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        // 开启事务
        $this->db->beginTransaction();
        
        try {
            // 创建回复
            $replyId = $this->create($data);
            
            // 更新话题的回复数和最后回复时间
            $this->db->query("UPDATE threads SET reply_count = reply_count + 1, last_reply_at = :created_at WHERE id = :thread_id");
            $this->db->bind(':created_at', $data['created_at']);
            $this->db->bind(':thread_id', $data['thread_id']);
            $this->db->execute();
            
            // 提交事务
            $this->db->commit();
            
            return $replyId;
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            return false;
        }
    }

    /**
     * 更新回复
     */
    public function updateReply($id, $data) {
        // 设置更新时间
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        return $this->update($id, $data);
    }

    /**
     * 删除回复
     */
    public function deleteReply($id) {
        // 获取回复信息
        $reply = $this->find($id);
        if (!$reply) return false;
        
        // 开启事务
        $this->db->beginTransaction();
        
        try {
            // 删除回复
            $this->db->query("DELETE FROM {$this->table} WHERE id = :id");
            $this->db->bind(':id', $id);
            $this->db->execute();
            
            // 更新话题的回复数
            $this->db->query("UPDATE threads SET reply_count = reply_count - 1 WHERE id = :thread_id");
            $this->db->bind(':thread_id', $reply['thread_id']);
            $this->db->execute();
            
            // 更新话题的最后回复时间（如果需要）
            $this->db->query("SELECT MAX(created_at) as last_reply FROM replies WHERE thread_id = :thread_id");
            $this->db->bind(':thread_id', $reply['thread_id']);
            $lastReply = $this->db->single()['last_reply'];
            
            $this->db->query("UPDATE threads SET last_reply_at = :last_reply WHERE id = :thread_id");
            $this->db->bind(':last_reply', $lastReply);
            $this->db->bind(':thread_id', $reply['thread_id']);
            $this->db->execute();
            
            // 提交事务
            $this->db->commit();
            
            return true;
        } catch (Exception $e) {
            // 回滚事务
            $this->db->rollBack();
            return false;
        }
    }

    /**
     * 获取用户的所有回复
     */
    public function getUserReplies($userId, $page = 1, $limit = 20) {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT r.*, t.title as thread_title, t.id as thread_id, f.name as forum_name, f.id as forum_id
                FROM replies r
                JOIN threads t ON r.thread_id = t.id
                JOIN forums f ON t.forum_id = f.id
                WHERE r.user_id = :user_id
                ORDER BY r.created_at DESC
                LIMIT :limit OFFSET :offset";
        
        $this->db->query($sql);
        $this->db->bind(':user_id', $userId);
        $this->db->bind(':limit', $limit);
        $this->db->bind(':offset', $offset);
        $replies = $this->db->resultSet();
        
        // 获取总数
        $this->db->query("SELECT COUNT(*) as total FROM replies WHERE user_id = :user_id");
        $this->db->bind(':user_id', $userId);
        $total = $this->db->single()['total'];
        
        return [
            'data' => $replies,
            'total' => $total,
            'pages' => ceil($total / $limit),
            'page' => $page,
            'limit' => $limit
        ];
    }

    /**
     * 获取最新回复
     */
    public function getLatestReplies($limit = 10) {
        $sql = "SELECT r.*, u.username, u.avatar, t.title as thread_title, t.id as thread_id
                FROM replies r
                JOIN users u ON r.user_id = u.id
                JOIN threads t ON r.thread_id = t.id
                ORDER BY r.created_at DESC
                LIMIT :limit";
        
        $this->db->query($sql);
        $this->db->bind(':limit', $limit);
        return $this->db->resultSet();
    }

    /**
     * 获取回复数量统计
     */
    public function getReplyStats($userId = null) {
        $whereClause = $userId ? "WHERE user_id = :user_id" : "";
        $params = $userId ? [':user_id' => $userId] : [];
        
        // 总回复数
        $this->db->query("SELECT COUNT(*) as total FROM replies {$whereClause}");
        if ($userId) {
            $this->db->bind(':user_id', $userId);
        }
        $totalReplies = $this->db->single()['total'];
        
        // 今日回复数
        $this->db->query("SELECT COUNT(*) as today FROM replies {$whereClause} AND DATE(created_at) = CURDATE()");
        if ($userId) {
            $this->db->bind(':user_id', $userId);
        }
        $todayReplies = $this->db->single()['today'];
        
        // 本周回复数
        $this->db->query("SELECT COUNT(*) as week FROM replies {$whereClause} AND WEEK(created_at, 1) = WEEK(NOW(), 1)");
        if ($userId) {
            $this->db->bind(':user_id', $userId);
        }
        $weekReplies = $this->db->single()['week'];
        
        return [
            'total' => $totalReplies,
            'today' => $todayReplies,
            'week' => $weekReplies
        ];
    }
}