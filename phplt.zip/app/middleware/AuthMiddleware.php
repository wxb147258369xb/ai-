<?php
/**
 * 认证中间件
 * 用于保护需要用户登录才能访问的路由
 */
class AuthMiddleware {
    /**
     * 检查用户是否已登录
     * 如果未登录，则重定向到登录页面
     */
    public static function requireAuth() {
        // 检查用户会话是否存在
        if (!isset($_SESSION['user_id'])) {
            // 保存当前URL，登录后重定向回来
            $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
            
            // 设置未登录提示消息
            $_SESSION['message'] = [
                'type' => 'error',
                'text' => '请先登录后再访问此页面'
            ];
            
            // 重定向到登录页面
            header('Location: /auth/login');
            exit;
        }
    }
    
    /**
     * 检查用户是否为管理员
     * 如果不是管理员，则重定向到首页
     */
    public static function requireAdmin() {
        // 首先检查是否已登录
        self::requireAuth();
        
        // 然后检查用户角色是否为管理员
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            // 设置权限不足提示消息
            $_SESSION['message'] = [
                'type' => 'error',
                'text' => '权限不足，只有管理员可以访问此页面'
            ];
            
            // 重定向到首页
            header('Location: /');
            exit;
        }
    }
    
    /**
     * 获取当前登录用户信息
     * @return array|null 用户信息数组或null（未登录时）
     */
    public static function getCurrentUser() {
        if (isset($_SESSION['user_id'])) {
            return [
                'id' => $_SESSION['user_id'],
                'username' => $_SESSION['username'],
                'email' => $_SESSION['email'],
                'role' => $_SESSION['role'],
                'points' => $_SESSION['points']
            ];
        }
        return null;
    }
    
    /**
     * 检查用户是否已登录
     * @return bool 是否已登录
     */
    public static function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
    
    /**
     * 检查用户是否为管理员
     * @return bool 是否为管理员
     */
    public static function isAdmin() {
        return self::isLoggedIn() && $_SESSION['role'] === 'admin';
    }
    
    /**
     * 检查用户是否为某个资源的所有者或管理员
     * @param int $resourceUserId 资源所有者的用户ID
     * @return bool 是否有权限
     */
    public static function isOwnerOrAdmin($resourceUserId) {
        return self::isLoggedIn() && 
              (self::isAdmin() || $_SESSION['user_id'] == $resourceUserId);
    }
    
    /**
     * 登出用户
     */
    public static function logout() {
        // 清除会话中的用户数据
        unset($_SESSION['user_id'], 
              $_SESSION['username'], 
              $_SESSION['email'], 
              $_SESSION['role'], 
              $_SESSION['points']);
        
        // 可选：完全销毁会话
        session_destroy();
        
        // 重定向到首页
        header('Location: /');
        exit;
    }
    
    /**
     * 处理登录重定向
     * 检查是否有之前保存的重定向URL，如果有则重定向到该URL，否则重定向到默认页面
     * @param string $defaultUrl 默认重定向URL
     */
    public static function handleRedirect($defaultUrl = '/') {
        if (isset($_SESSION['redirect_url'])) {
            $redirectUrl = $_SESSION['redirect_url'];
            unset($_SESSION['redirect_url']);
            header('Location: ' . $redirectUrl);
        } else {
            header('Location: ' . $defaultUrl);
        }
        exit;
    }
}