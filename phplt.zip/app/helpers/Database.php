<?php
/**
 * 数据库连接类
 */
class Database {
    private $host;
    private $dbname;
    private $username;
    private $password;
    private $charset;
    private $pdo;
    private $stmt;
    private $error;

    /**
     * 构造函数，初始化数据库配置
     */
    public function __construct() {
        $config = require_once ROOT_PATH . '/app/config/database.php';
        
        $this->host = $config['host'];
        $this->dbname = $config['dbname'];
        $this->username = $config['username'];
        $this->password = $config['password'];
        $this->charset = $config['charset'];
        
        // 连接数据库
        $this->connect();
    }

    /**
     * 连接到数据库
     */
    private function connect() {
        $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset={$this->charset}";
        $options = [
            PDO::ATTR_PERSISTENT => true,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ];

        try {
            $this->pdo = new PDO($dsn, $this->username, $this->password, $options);
        } catch(PDOException $e) {
            $this->error = $e->getMessage();
            die('数据库连接失败: ' . $this->error);
        }
    }

    /**
     * 准备SQL语句
     */
    public function query($sql) {
        try {
            $this->stmt = $this->pdo->prepare($sql);
        } catch(PDOException $e) {
            $this->error = $e->getMessage();
            return false;
        }
        return $this;
    }

    /**
     * 绑定参数
     */
    public function bind($param, $value, $type = null) {
        if (is_null($type)) {
            switch (true) {
                case is_int($value):
                    $type = PDO::PARAM_INT;
                    break;
                case is_bool($value):
                    $type = PDO::PARAM_BOOL;
                    break;
                case is_null($value):
                    $type = PDO::PARAM_NULL;
                    break;
                default:
                    $type = PDO::PARAM_STR;
            }
        }

        $this->stmt->bindValue($param, $value, $type);
        return $this;
    }

    /**
     * 执行SQL语句
     */
    public function execute() {
        try {
            return $this->stmt->execute();
        } catch(PDOException $e) {
            $this->error = $e->getMessage();
            return false;
        }
    }

    /**
     * 获取所有结果
     */
    public function resultSet() {
        $this->execute();
        return $this->stmt->fetchAll();
    }

    /**
     * 获取单行结果
     */
    public function single() {
        $this->execute();
        return $this->stmt->fetch();
    }

    /**
     * 获取记录数量
     */
    public function rowCount() {
        return $this->stmt->rowCount();
    }

    /**
     * 获取最后插入的ID
     */
    public function lastInsertId() {
        return $this->pdo->lastInsertId();
    }

    /**
     * 开启事务
     */
    public function beginTransaction() {
        return $this->pdo->beginTransaction();
    }

    /**
     * 提交事务
     */
    public function commit() {
        return $this->pdo->commit();
    }

    /**
     * 回滚事务
     */
    public function rollBack() {
        return $this->pdo->rollBack();
    }

    /**
     * 调试SQL语句
     */
    public function debugDumpParams() {
        return $this->stmt->debugDumpParams();
    }
}