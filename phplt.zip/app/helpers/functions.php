<?php

/**
 * 格式化时间为"多久前"的形式
 * @param string $datetime 时间戳或日期时间字符串
 * @param boolean $full 是否显示完整格式
 * @return string 格式化后的时间字符串
 */
function time_ago($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => '年',
        'm' => '月',
        'w' => '周',
        'd' => '天',
        'h' => '小时',
        'i' => '分钟',
        's' => '秒',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . $v;
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . '前' : '刚刚';
}

/**
 * 高亮显示搜索关键词
 * @param string $text 原始文本
 * @param string $keyword 搜索关键词
 * @return string 高亮后的HTML
 */
function highlight_search_term($text, $keyword) {
    if (empty($keyword)) {
        return htmlspecialchars($text);
    }
    
    // 转义正则表达式特殊字符
    $escaped_keyword = preg_quote($keyword, '/');
    
    // 使用正则表达式替换关键词，添加高亮标记
    $highlighted = preg_replace(
        "/($escaped_keyword)/i",
        '<span class="bg-cyan-900/50 text-cyan-400">$1</span>',
        htmlspecialchars($text)
    );
    
    return $highlighted;
}

/**
 * 格式化时间为相对时间（例如：3小时前）
 * @param string $time 时间戳或日期字符串
 * @return string 相对时间字符串
 */
function format_relative_time($time) {
    // 将时间转换为时间戳
    $timestamp = is_numeric($time) ? $time : strtotime($time);
    
    // 获取当前时间戳
    $now = time();
    
    // 计算时间差（秒）
    $diff = $now - $timestamp;
    
    // 如果时间差为负数，表示未来时间，返回"刚刚"
    if ($diff < 0) {
        return '刚刚';
    }
    
    // 定义时间单位和对应的秒数
    $intervals = [
        '年' => 31536000,
        '月' => 2592000,
        '周' => 604800,
        '天' => 86400,
        '小时' => 3600,
        '分钟' => 60,
        '秒' => 1
    ];
    
    // 遍历时间单位，找到最合适的
    foreach ($intervals as $unit => $seconds) {
        $count = floor($diff / $seconds);
        
        // 如果这个时间单位合适
        if ($count >= 1) {
            // 特殊处理1秒钟的情况
            if ($unit === '秒' && $count === 1) {
                return '刚刚';
            }
            // 特殊处理超过30天的情况，直接返回日期
            if ($unit === '月' && $count > 12) {
                return date('Y-m-d', $timestamp);
            }
            return "{$count}{$unit}前";
        }
    }
    
    // 默认返回"刚刚"
    return '刚刚';
}

/**
 * 安全转义HTML特殊字符
 * @param mixed $value 要转义的值
 * @return mixed 转义后的值
 */
function e($value) {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

/**
 * 生成随机字符串
 * @param int $length 字符串长度
 * @param string $type 字符串类型：alnum(字母数字), alpha(字母), numeric(数字), nozero(非零数字), unique(唯一ID)
 * @return string 随机字符串
 */
function random_string($length = 8, $type = 'alnum') {
    switch ($type) {
        case 'alnum':
            $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            break;
        case 'alpha':
            $pool = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            break;
        case 'numeric':
            $pool = '0123456789';
            break;
        case 'nozero':
            $pool = '123456789';
            break;
        case 'unique':
            return md5(uniqid(mt_rand(), true));
        default:
            $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    }

    $pool = str_shuffle($pool);
    return substr(str_shuffle(str_repeat($pool, ceil($length / strlen($pool)))), 0, $length);
}

/**
 * 重定向到指定URL
 * @param string $url 重定向URL
 * @param int $statusCode HTTP状态码
 */
function redirect($url, $statusCode = 302) {
    header('Location: ' . $url, true, $statusCode);
    exit;
}

/**
 * 生成友好的URL
 * @param string $string 原始字符串
 * @return string 友好的URL
 */
function slug($string) {
    // 转换为小写
    $string = mb_strtolower($string, 'UTF-8');
    
    // 替换中文为拼音（简单实现，实际应用中可能需要更复杂的处理）
    // 这里只是一个占位符，实际应用中可能需要使用拼音转换库
    
    // 替换非字母数字字符为连字符
    $string = preg_replace('/[^a-z0-9]+/', '-', $string);
    
    // 移除首尾连字符
    $string = trim($string, '-');
    
    return $string;
}

/**
 * 获取用户IP地址
 * @return string IP地址
 */
function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

/**
 * 生成分页链接
 * @param int $total_items 总条目数
 * @param int $per_page 每页条目数
 * @param int $current_page 当前页码
 * @param string $url 基础URL
 * @return array 分页信息数组
 */
function pagination($total_items, $per_page, $current_page, $url) {
    $total_pages = ceil($total_items / $per_page);
    
    // 确保当前页在有效范围内
    $current_page = max(1, min($current_page, $total_pages));
    
    // 计算起始页码和结束页码
    $start_page = max(1, $current_page - 2);
    $end_page = min($total_pages, $start_page + 4);
    
    // 调整起始页码
    if ($end_page - $start_page < 4) {
        $start_page = max(1, $end_page - 4);
    }
    
    // 计算偏移量
    $offset = ($current_page - 1) * $per_page;
    
    return [
        'total_items' => $total_items,
        'per_page' => $per_page,
        'total_pages' => $total_pages,
        'current_page' => $current_page,
        'start_page' => $start_page,
        'end_page' => $end_page,
        'offset' => $offset,
        'url' => $url
    ];
}

/**
 * 验证邮箱格式
 * @param string $email 邮箱地址
 * @return bool 是否为有效邮箱
 */
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * 验证密码强度
 * @param string $password 密码
 * @return array 包含强度等级和提示信息
 */
function validate_password_strength($password) {
    $strength = 0;
    $messages = [];
    
    // 长度检查
    if (strlen($password) < 8) {
        $messages[] = '密码长度至少8个字符';
    } else {
        $strength++;
        if (strlen($password) >= 12) {
            $strength++;
        }
    }
    
    // 包含数字
    if (preg_match('/[0-9]/', $password)) {
        $strength++;
    } else {
        $messages[] = '密码应包含至少一个数字';
    }
    
    // 包含小写字母
    if (preg_match('/[a-z]/', $password)) {
        $strength++;
    } else {
        $messages[] = '密码应包含至少一个小写字母';
    }
    
    // 包含大写字母
    if (preg_match('/[A-Z]/', $password)) {
        $strength++;
    } else {
        $messages[] = '密码应包含至少一个大写字母';
    }
    
    // 包含特殊字符
    if (preg_match('/[^a-zA-Z0-9]/', $password)) {
        $strength++;
    } else {
        $messages[] = '密码应包含至少一个特殊字符';
    }
    
    // 计算强度百分比
    $percentage = min(100, ($strength / 6) * 100);
    
    // 确定强度级别
    if ($percentage < 40) {
        $level = '弱';
        $class = 'text-red-500';
    } elseif ($percentage < 70) {
        $level = '中';
        $class = 'text-yellow-500';
    } else {
        $level = '强';
        $class = 'text-green-500';
    }
    
    return [
        'strength' => $strength,
        'percentage' => $percentage,
        'level' => $level,
        'class' => $class,
        'messages' => $messages
    ];
}

/**
 * 格式化文件大小
 * @param int $bytes 字节数
 * @param int $precision 精度
 * @return string 格式化后的文件大小
 */
function format_file_size($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
    
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    
    $bytes /= pow(1024, $pow);
    
    return round($bytes, $precision) . ' ' . $units[$pow];
}

/**
 * 检查文件类型是否允许上传
 * @param string $filename 文件名
 * @param array $allowed_types 允许的文件类型
 * @return bool 是否允许上传
 */
function is_allowed_file_type($filename, $allowed_types = array('jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'txt')) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, $allowed_types);
}

/**
 * 生成令牌
 * @return string 令牌
 */
function generate_token() {
    if (function_exists('random_bytes')) {
        return bin2hex(random_bytes(32));
    } elseif (function_exists('mcrypt_create_iv')) {
        return bin2hex(mcrypt_create_iv(32, MCRYPT_DEV_URANDOM));
    } else {
        return bin2hex(openssl_random_pseudo_bytes(32));
    }
}

/**
 * 设置会话消息
 * @param string $type 消息类型
 * @param string $message 消息内容
 */
function flash($type, $message) {
    $_SESSION['flash'][$type] = $message;
}

/**
 * 获取并清除会话消息
 * @param string $type 消息类型
 * @return string|null 消息内容
 */
function get_flash($type) {
    if (isset($_SESSION['flash'][$type])) {
        $message = $_SESSION['flash'][$type];
        unset($_SESSION['flash'][$type]);
        return $message;
    }
    return null;
}

/**
 * 检查是否存在会话消息
 * @param string $type 消息类型
 * @return bool 是否存在
 */
function has_flash($type) {
    return isset($_SESSION['flash'][$type]);
}

/**
 * 计算阅读时间
 * @param string $text 文本内容
 * @return int 预计阅读时间（分钟）
 */
function reading_time($text) {
    $word_count = str_word_count(strip_tags($text));
    $reading_speed = 200; // 中文阅读速度约为每分钟200字
    return max(1, ceil($word_count / $reading_speed));
}

/**
 * 获取用户角色名称
 * @param int $role_id 角色ID
 * @return string 角色名称
 */
function get_role_name($role_id) {
    $roles = array(
        1 => '游客',
        2 => '会员',
        3 => '版主',
        4 => '管理员'
    );
    return isset($roles[$role_id]) ? $roles[$role_id] : '未知角色';
}

/**
 * 获取用户角色颜色类
 * @param int $role_id 角色ID
 * @return string CSS颜色类
 */
function get_role_color($role_id) {
    $colors = array(
        1 => 'text-gray-500',
        2 => 'text-cyan-400',
        3 => 'text-purple-400',
        4 => 'text-red-500'
    );
    return isset($colors[$role_id]) ? $colors[$role_id] : 'text-gray-500';
}

/**
 * 限制文本长度并添加省略号
 * @param string $text 原始文本
 * @param int $length 最大长度
 * @return string 处理后的文本
 */
function truncate($text, $length = 100) {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . '...';
}

/**
 * 解析Markdown文本为HTML
 * @param string $text Markdown文本
 * @return string HTML文本
 */
function parse_markdown($text) {
    // 简单的Markdown解析
    // 实际应用中可能需要使用专业的Markdown解析库
    
    // 标题
    $text = preg_replace('/^(#{1,6})\s+(.+)$/m', '<h$1>$2</h$1>', $text);
    
    // 粗体
    $text = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $text);
    
    // 斜体
    $text = preg_replace('/\*(.+?)\*/', '<em>$1</em>', $text);
    
    // 链接
    $text = preg_replace('/\[(.*?)\]\((.*?)\)/', '<a href="$2" target="_blank">$1</a>', $text);
    
    // 列表
    $text = preg_replace('/^\s*\-\s+(.+)$/m', '<ul><li>$1</li></ul>', $text);
    $text = preg_replace('/^\s*\d+\.\s+(.+)$/m', '<ol><li>$1</li></ol>', $text);
    
    // 段落
    $text = preg_replace('/^(?!<h|\s*<ul|\s*<ol|\s*<li|\s*<p).+$/m', '<p>$0</p>', $text);
    
    return $text;
}

/**
 * 计算两个IP地址之间的相似度（用于检测IP段）
 * @param string $ip1 IP地址1
 * @param string $ip2 IP地址2
 * @return float 相似度百分比
 */
function ip_similarity($ip1, $ip2) {
    $parts1 = explode('.', $ip1);
    $parts2 = explode('.', $ip2);
    
    if (count($parts1) != 4 || count($parts2) != 4) {
        return 0;
    }
    
    $match = 0;
    for ($i = 0; $i < 4; $i++) {
        if ($parts1[$i] == $parts2[$i]) {
            $match++;
        }
    }
    
    return ($match / 4) * 100;
}

/**
 * 检查是否为移动设备访问
 * @return bool 是否为移动设备
 */
function is_mobile() {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $mobile_agents = array(
        'Android', 'webOS', 'iPhone', 'iPad', 'iPod', 'BlackBerry', 'IEMobile', 'Opera Mini'
    );
    
    foreach ($mobile_agents as $agent) {
        if (stripos($user_agent, $agent) !== false) {
            return true;
        }
    }
    
    return false;
}