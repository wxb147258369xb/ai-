<?php include ROOT_PATH . '/app/views/layouts/header.php'; ?>

<!-- 动态背景装饰 -->
<div class="cyber-bg"></div>
<div class="cyber-grid"></div>
<div class="cyber-scanlines"></div>
<div class="cyber-blob blob-1"></div>
<div class="cyber-blob blob-2"></div>
<div class="cyber-blob blob-3"></div>

<section class="py-8 relative z-10">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <!-- 主要内容区 -->
            <div class="lg:col-span-8">
                <div class="cyberpunk-card bg-black bg-opacity-70 border border-cyan-500 rounded-xl p-8 shadow-glow-cyan neon-border-green animate-fade-in" data-delay="100">
                    <div class="mb-8">
                        <div class="flex justify-between items-center">
                            <h1 class="text-2xl font-bold text-white mb-2 cyber-text glitch-text">我的回复</h1>
                            <span class="text-xs text-cyan-600 bg-cyan-900 bg-opacity-30 px-2 py-1 rounded">V2.0</span>
                        </div>
                        <p class="text-gray-400">查看您在论坛中发表的所有回复</p>
                    </div>

                    <!-- 筛选和排序 -->
                    <div class="bg-gray-900 rounded-lg p-4 mb-6 border border-cyan-900">
                        <div class="flex flex-col sm:flex-row sm:justify-between items-center gap-4">
                            <div class="text-gray-400">共 <span class="stat-count text-cyan-400" data-count="<?php echo $totalReplies; ?>">0</span> 条回复</div>
                            <div class="flex gap-2">
                                <a href="/user/replies?sort=newest" class="px-3 py-1 rounded-lg text-sm bg-gray-800 text-gray-300 hover:bg-gray-700 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                    最新
                                </a>
                                <a href="/user/replies?sort=oldest" class="px-3 py-1 rounded-lg text-sm bg-gray-800 text-gray-300 hover:bg-gray-700 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                    最早
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- 回复列表 -->
                    <div class="space-y-6">
                        <?php if (!empty($replies)): ?>
                            <?php foreach ($replies as $reply): ?>
                                <div class="bg-gray-900 border border-gray-800 rounded-lg p-6 hover:border-cyan-700 transition-all duration-300 reply-card animate-fade-in" data-delay="200">
                                    <div class="flex justify-between items-start mb-4">
                                        <div class="flex items-center">
                                            <div class="relative">
                                                <img src="<?php echo !empty($reply['author_avatar']) ? $reply['author_avatar'] : '/images/default_avatar.png'; ?>" alt="Avatar" class="w-10 h-10 rounded-full border border-cyan-600 mr-3 pulse-on-hover">
                                                <div class="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border border-black"></div>
                                            </div>
                                            <div>
                                                <h4 class="font-bold text-cyan-400 cyber-text"><?php echo htmlspecialchars($reply['author_username']); ?></h4>
                                                <p class="text-gray-500 text-xs">回复于 <?php echo date('Y-m-d H:i', strtotime($reply['created_at'])); ?></p>
                                            </div>
                                        </div>
                                        <div class="flex items-center">
                                            <span class="px-2 py-1 bg-gray-800 text-gray-400 text-xs rounded icon-pulse">
                                                <i class="fas fa-thumbs-up mr-1"></i> <span class="stat-count" data-count="<?php echo $reply['like_count'] ?? 0; ?>">0</span>
                                            </span>
                                        </div>
                                    </div>

                                    <!-- 回复内容 -->
                                    <div class="mb-4 cyber-text">
                                        <p class="text-gray-300 whitespace-pre-wrap"><?php echo nl2br(htmlspecialchars($reply['content'])); ?></p>
                                    </div>

                                    <!-- 所属话题 -->
                                    <div class="bg-black bg-opacity-50 p-3 rounded-lg border border-gray-800 hover:border-cyan-700 transition-colors group">
                                        <p class="text-sm text-gray-400 mb-1">回复在：</p>
                                        <a href="/thread/show/<?php echo $reply['thread_id']; ?>" class="text-cyan-400 hover:text-cyan-300 transition-colors cyber-text group-hover:shadow-glow-cyan-sm">
                                            <i class="fas fa-comment-alt mr-1"></i> <?php echo htmlspecialchars($reply['thread_title']); ?>
                                        </a>
                                        <div class="mt-2 flex items-center text-xs text-gray-500">
                                            <a href="/forum/show/<?php echo $reply['forum_id']; ?>" class="hover:text-cyan-400 transition-colors">
                                                <i class="fas fa-layer-group mr-1"></i> <?php echo htmlspecialchars($reply['forum_name']); ?>
                                            </a>
                                        </div>
                                    </div>

                                    <!-- 操作按钮 -->
                                    <div class="mt-4 flex justify-end">
                                        <a href="/thread/show/<?php echo $reply['thread_id']; ?>#reply-<?php echo $reply['id']; ?>" class="px-3 py-1 bg-cyan-900 text-cyan-300 text-sm rounded-lg hover:bg-cyan-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                            <i class="fas fa-external-link-alt mr-1"></i> 查看上下文
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-12">
                                <div class="text-gray-500 text-6xl mb-4 animate-fade-in">
                                    <i class="fas fa-comment-slash"></i>
                                </div>
                                <h3 class="text-xl text-gray-400 mb-2 animate-fade-in" data-delay="100">暂无回复</h3>
                                <p class="text-gray-500 mb-6 animate-fade-in" data-delay="200">您还没有发表过任何回复</p>
                                <a href="/forum" class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-bold rounded-lg hover:from-cyan-400 hover:to-blue-500 transition-colors cyber-button shadow-glow-cyan-sm animate-fade-in" data-delay="300">
                                    <i class="fas fa-arrow-right mr-2"></i> 去论坛看看
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- 分页 -->
                    <?php if ($pages > 1): ?>
                        <div class="mt-8 flex justify-center">
                            <nav class="flex items-center">
                                <?php if ($page > 1): ?>
                                    <a href="/user/replies?page=<?php echo $page - 1; ?>&sort=<?php echo $sort; ?>" class="px-3 py-2 bg-gray-900 border border-cyan-800 rounded-l-lg text-gray-300 hover:bg-gray-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                        <i class="fas fa-chevron-left"></i>
                                    </a>
                                <?php endif; ?>
                                
                                <?php for ($i = 1; $i <= $pages; $i++): ?>
                                    <a href="/user/replies?page=<?php echo $i; ?>&sort=<?php echo $sort; ?>" class="px-4 py-2 text-sm cyber-button hover:shadow-glow-cyan-sm <?php echo $i == $page ? 'bg-cyan-600 text-black border-y border-cyan-800 font-bold cyber-button-active shadow-glow-cyan-sm' : 'bg-gray-900 text-gray-300 border-y border-cyan-800 hover:bg-gray-800 transition-colors'; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                <?php endfor; ?>
                                
                                <?php if ($page < $pages): ?>
                                    <a href="/user/replies?page=<?php echo $page + 1; ?>&sort=<?php echo $sort; ?>" class="px-3 py-2 bg-gray-900 border border-cyan-800 rounded-r-lg text-gray-300 hover:bg-gray-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                        <i class="fas fa-chevron-right"></i>
                                    </a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- 侧边栏 -->
            <div class="lg:col-span-4">
                <!-- 用户信息 -->
                <div class="cyberpunk-card bg-black bg-opacity-70 border border-cyan-800 rounded-lg p-6 mb-8 shadow-glow-cyan animate-fade-in neon-border" data-delay="300">
                    <div class="text-center mb-4">
                        <div class="relative inline-block">
                            <img src="<?php echo !empty($userInfo['avatar']) ? $userInfo['avatar'] : '/images/default_avatar.png'; ?>" alt="<?php echo htmlspecialchars($userInfo['username']); ?>" class="w-24 h-24 mx-auto rounded-full border-2 border-cyan-600 mb-4 pulse-on-hover">
                            <div class="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-2 border-black"></div>
                        </div>
                        <h3 class="text-xl font-bold text-white cyber-text glitch-text"><?php echo htmlspecialchars($userInfo['username']); ?></h3>
                        <p class="text-cyan-400 text-sm mt-1"><?php echo ucfirst($userInfo['role']); ?></p>
                    </div>
                    <div class="grid grid-cols-3 gap-2 text-center">
                        <div class="bg-gray-900 rounded-lg p-2 border border-gray-800 hover:border-cyan-700 transition-colors">
                            <div class="text-cyan-400 font-bold stat-count" data-count="<?php echo $userStats['threads']; ?>">0</div>
                            <div class="text-xs text-gray-500">话题</div>
                        </div>
                        <div class="bg-gray-900 rounded-lg p-2 border border-gray-800 hover:border-cyan-700 transition-colors">
                            <div class="text-cyan-400 font-bold stat-count" data-count="<?php echo $totalReplies; ?>">0</div>
                            <div class="text-xs text-gray-500">回复</div>
                        </div>
                        <div class="bg-gray-900 rounded-lg p-2 border border-gray-800 hover:border-cyan-700 transition-colors">
                            <div class="text-cyan-400 font-bold stat-count" data-count="<?php echo $userInfo['points']; ?>">0</div>
                            <div class="text-xs text-gray-500">积分</div>
                        </div>
                    </div>
                    <a href="/user/profile" class="mt-4 block w-full text-center px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-bold rounded-lg hover:from-cyan-400 hover:to-blue-500 transition-colors cyber-button shadow-glow-cyan-sm">
                        <i class="fas fa-user-cog mr-2"></i> 编辑资料
                    </a>
                </div>

                <!-- 最近回复的话题 -->
                <div class="cyberpunk-card bg-black bg-opacity-70 border border-cyan-800 rounded-lg p-6 shadow-glow-cyan animate-fade-in neon-border" data-delay="400">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4 flex items-center cyber-text">
                        <i class="fas fa-history text-purple-500 mr-2 icon-pulse"></i> 最近参与的话题
                    </h3>
                    <div class="space-y-3">
                        <?php if (!empty($recentThreads)): ?>
                            <?php foreach ($recentThreads as $thread): ?>
                                <a href="/thread/show/<?php echo $thread['id']; ?>" class="block hover:bg-gray-900 p-3 rounded-lg transition-colors group border border-transparent hover:border-cyan-700">
                                    <p class="text-gray-300 text-sm mb-1 truncate group-hover:text-cyan-400 transition-colors cyber-text">
                                        <?php echo htmlspecialchars($thread['title']); ?>
                                    </p>
                                    <div class="flex justify-between items-center text-xs text-gray-500">
                                        <span><?php echo htmlspecialchars($thread['forum_name']); ?></span>
                                        <span><?php echo timeAgo($thread['last_reply_at']); ?></span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-gray-500 text-sm text-center py-4">暂无参与话题</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 动态背景网格
        createCyberGrid();
        
        // 扫描线动画
        createScanlines();
        
        // 标题故障效果
        applyGlitchEffect();
        
        // 滚动渐入效果
        const animatedElements = document.querySelectorAll('.animate-fade-in');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const delay = entry.target.getAttribute('data-delay') || 0;
                    setTimeout(() => {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }, delay);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        animatedElements.forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(el);
        });
        
        // 数字计数器动画
        const statCounts = document.querySelectorAll('.stat-count');
        statCounts.forEach(count => {
            const target = parseInt(count.getAttribute('data-count'));
            let current = 0;
            const duration = 1500; // 1.5秒
            const step = target / (duration / 16); // 60fps
            
            const timer = setInterval(() => {
                current += step;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                count.textContent = Math.floor(current).toLocaleString();
            }, 16);
        });
        
        // 回复卡片悬停效果
        const replyCards = document.querySelectorAll('.reply-card');
        replyCards.forEach((card, index) => {
            card.addEventListener('mouseenter', function() {
                this.classList.add('transform', 'translate-y-[-5px]', 'transition-transform', 'duration-300');
                
                // 霓虹边框效果
                const borderColor = ['#00ffff', '#ff00ff', '#00ff00'][index % 3];
                this.style.borderColor = borderColor;
                this.style.boxShadow = `0 0 15px ${borderColor}`;
            });
            
            card.addEventListener('mouseleave', function() {
                this.classList.remove('transform', 'translate-y-[-5px]', 'transition-transform', 'duration-300');
                this.style.borderColor = '#1f2937'; // 恢复原始边框颜色
                this.style.boxShadow = 'none';
            });
        });
        
        // 图标脉动效果
        const pulseIcons = document.querySelectorAll('.icon-pulse');
        pulseIcons.forEach((icon, index) => {
            setInterval(() => {
                icon.style.opacity = '0.5';
                setTimeout(() => {
                    icon.style.opacity = '1';
                }, 800);
            }, 3000 + index * 500);
        });
        
        // 按钮点击波纹效果
        const buttons = document.querySelectorAll('.cyber-button, .cyber-button-active');
        buttons.forEach(button => {
            button.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.width = ripple.style.height = size + 'px';
                ripple.style.left = x + 'px';
                ripple.style.top = y + 'px';
                ripple.classList.add('ripple');
                
                this.appendChild(ripple);
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
        });
        
        // 平滑滚动到锚点
        document.querySelectorAll('a[href*="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href').split('#')[1];
                const targetElement = document.getElementById(targetId);
                
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth' });
                    // 添加高亮效果
                    targetElement.classList.add('bg-cyan-900', 'bg-opacity-30');
                    setTimeout(() => {
                        targetElement.classList.remove('bg-cyan-900', 'bg-opacity-30');
                    }, 3000);
                }
            });
        });
    });
</script>

<?php include ROOT_PATH . '/app/views/layouts/footer.php'; ?>