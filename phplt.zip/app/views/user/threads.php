<?php include ROOT_PATH . '/app/views/layouts/header.php'; ?>

<!-- 动态背景装饰 -->
<div class="cyber-bg"></div>
<div class="cyber-grid"></div>
<div class="cyber-scanlines"></div>
<div class="cyber-blob blob-1"></div>
<div class="cyber-blob blob-2"></div>
<div class="cyber-blob blob-3"></div>

<section class="py-8 relative z-10">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <!-- 主要内容区 -->
            <div class="lg:col-span-8">
                <!-- 用户信息头部 -->
                <div class="cyberpunk-card bg-black bg-opacity-70 border border-cyan-500 rounded-lg p-6 mb-8 shadow-glow-cyan neon-border-green animate-fade-in" data-delay="100">
                    <div class="flex items-center mb-4">
                        <div class="relative">
                            <img src="<?php echo !empty($user['avatar']) ? $user['avatar'] : '/images/default_avatar.png'; ?>" alt="<?php echo htmlspecialchars($user['username']); ?>" class="w-16 h-16 rounded-full border-2 border-cyan-600 mr-4 animate-fade-in pulse-on-hover">
                            <div class="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-black"></div>
                        </div>
                        <div>
                            <div class="flex items-center">
                                <h1 class="text-2xl font-bold text-white mr-3 cyber-text glitch-text">
                                    <?php echo htmlspecialchars($user['username']); ?>
                                </h1>
                                <span class="px-3 py-1 bg-purple-900 text-purple-300 text-sm rounded-full border border-purple-700">
                                    <?php echo ucfirst($user['role']); ?>
                                </span>
                            </div>
                            <p class="text-gray-500">话题总数: <?php echo $total_threads; ?> | 积分: <?php echo $user['points']; ?></p>
                        </div>
                    </div>
                    <div class="flex space-x-3">
                        <a href="/user/profile/<?php echo $user['id']; ?>" class="px-4 py-2 bg-gray-900 border border-cyan-800 rounded-lg text-gray-300 hover:bg-gray-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                            <i class="fas fa-user mr-2"></i> 个人资料
                        </a>
                        <a href="/user/threads/<?php echo $user['id']; ?>" class="px-4 py-2 bg-cyan-900 border border-cyan-600 rounded-lg text-cyan-200 font-medium hover:bg-cyan-800 transition-colors cyber-button-active shadow-glow-cyan-sm">
                            <i class="fas fa-list-alt mr-2"></i> 发表的话题
                        </a>
                        <a href="/user/replies/<?php echo $user['id']; ?>" class="px-4 py-2 bg-gray-900 border border-cyan-800 rounded-lg text-gray-300 hover:bg-gray-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                            <i class="fas fa-comment-alt mr-2"></i> 发表的回复
                        </a>
                    </div>
                </div>

                <!-- 话题列表 -->
                <div class="cyberpunk-card bg-black bg-opacity-70 border border-cyan-800 rounded-lg p-6 animate-fade-in" data-delay="200">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-xl font-bold text-cyan-400 cyber-text">话题列表</h2>
                        <span class="text-xs text-cyan-600 bg-cyan-900 bg-opacity-30 px-2 py-1 rounded">V2.0</span>
                    </div>
                    
                    <?php if (!empty($threads)): ?>
                        <div class="space-y-4">
                            <?php foreach ($threads as $thread): ?>
                                <a href="/thread/show/<?php echo $thread['id']; ?>" class="block bg-gray-900 border border-cyan-900 rounded-lg p-4 hover:border-cyan-700 hover:shadow-glow-cyan-sm transition-all duration-300 thread-card group">
                                    <div class="flex justify-between items-start mb-2">
                                        <h3 class="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors cyber-text">
                                            <?php echo htmlspecialchars($thread['title']); ?>
                                        </h3>
                                        <span class="px-2 py-1 bg-gray-800 text-gray-400 text-xs rounded">
                                            <?php echo $thread['forum_name']; ?>
                                        </span>
                                    </div>
                                    
                                    <div class="text-gray-400 text-sm mb-3">
                                        <?php 
                                        // 截断过长的描述
                                        $excerpt = strip_tags($thread['content']);
                                        if (strlen($excerpt) > 150) {
                                            $excerpt = substr($excerpt, 0, 150) . '...';
                                        }
                                        echo htmlspecialchars($excerpt);
                                        ?>
                                    </div>
                                    
                                    <div class="flex justify-between items-center text-xs text-gray-500">
                                        <div>
                                            <span>发布于 <?php echo date('Y-m-d H:i', strtotime($thread['created_at'])); ?></span>
                                            <?php if ($thread['updated_at'] != $thread['created_at']): ?>
                                                <span class="ml-2 text-yellow-600">• 已编辑</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="flex space-x-4">
                                            <span class="flex items-center icon-pulse">
                                                <i class="far fa-eye mr-1"></i>
                                                <span class="thread-view-count" data-count="<?php echo $thread['view_count']; ?>">0</span>
                                            </span>
                                            <span class="flex items-center icon-pulse">
                                                <i class="far fa-comment mr-1"></i>
                                                <span class="thread-reply-count" data-count="<?php echo $thread['reply_count']; ?>">0</span>
                                            </span>
                                        </div>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                        
                        <!-- 分页 -->
                        <?php if ($total_pages > 1): ?>
                            <div class="mt-8 flex justify-center">
                                <nav class="flex items-center">
                                    <?php if ($page > 1): ?>
                                        <a href="/user/threads/<?php echo $user['id']; ?>?page=<?php echo $page - 1; ?>" class="px-3 py-2 bg-gray-900 border border-cyan-800 rounded-l-lg text-gray-300 hover:bg-gray-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                            <i class="fas fa-chevron-left"></i>
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                        <?php if ($i == $page): ?>
                                            <a href="/user/threads/<?php echo $user['id']; ?>?page=<?php echo $i; ?>" class="px-4 py-2 bg-cyan-600 text-black border-y border-cyan-800 font-bold cyber-button-active shadow-glow-cyan-sm">
                                                <?php echo $i; ?>
                                            </a>
                                        <?php else: ?>
                                            <a href="/user/threads/<?php echo $user['id']; ?>?page=<?php echo $i; ?>" class="px-4 py-2 bg-gray-900 text-gray-300 border-y border-cyan-800 hover:bg-gray-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                                <?php echo $i; ?>
                                            </a>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                    
                                    <?php if ($page < $total_pages): ?>
                                        <a href="/user/threads/<?php echo $user['id']; ?>?page=<?php echo $page + 1; ?>" class="px-3 py-2 bg-gray-900 border border-cyan-800 rounded-r-lg text-gray-300 hover:bg-gray-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                            <i class="fas fa-chevron-right"></i>
                                        </a>
                                    <?php endif; ?>
                                </nav>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="text-center py-12">
                            <div class="inline-flex items-center justify-center w-16 h-16 bg-gray-900 rounded-full mb-4">
                                <i class="fas fa-file-alt text-gray-700 text-2xl"></i>
                            </div>
                            <p class="text-gray-400 text-lg">暂无话题记录</p>
                            <a href="/forum" class="mt-4 inline-flex items-center text-cyan-500 hover:text-cyan-400 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                <i class="fas fa-arrow-right mr-2"></i> 去浏览话题
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- 侧边栏 -->
            <div class="lg:col-span-4">
                <!-- 用户统计 -->
                <div class="cyberpunk-card bg-black bg-opacity-70 border border-cyan-800 rounded-lg p-6 mb-8 shadow-glow-cyan animate-fade-in neon-border" data-delay="300">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4 cyber-text">用户统计</h3>
                    <div class="space-y-4">
                        <div class="flex justify-between items-center">
                            <span class="text-gray-400">注册时间</span>
                            <span class="text-gray-300"><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-400">话题数量</span>
                            <span class="text-gray-300 stat-count" data-count="<?php echo $total_threads; ?>">0</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-400">回复数量</span>
                            <span class="text-gray-300">
                                <a href="/user/replies/<?php echo $user['id']; ?>" class="text-cyan-500 hover:text-cyan-400 transition-colors">
                                    <span class="stat-count" data-count="<?php echo $user['reply_count']; ?>">0</span>
                                </a>
                            </span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-400">总浏览量</span>
                            <span class="text-gray-300 stat-count" data-count="<?php echo $total_views; ?>">0</span>
                        </div>
                        <div class="pt-4 border-t border-gray-800">
                            <div class="flex items-center mb-2">
                                <span class="text-gray-400 mr-2">积分</span>
                                <span class="text-yellow-500 font-bold text-lg stat-count" data-count="<?php echo $user['points']; ?>">0</span>
                            </div>
                            <div class="w-full bg-gray-800 rounded-full h-2.5">
                                <div class="bg-gradient-to-r from-yellow-500 to-orange-500 h-2.5 rounded-full cyber-progress-bar" data-width="<?php echo min(100, ($user['points'] / 1000) * 100); ?>%"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 热门话题 -->
                <div class="cyberpunk-card bg-black bg-opacity-70 border border-cyan-800 rounded-lg p-6 shadow-glow-cyan animate-fade-in neon-border" data-delay="400">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4 cyber-text">用户热门话题</h3>
                    <div class="space-y-4">
                        <?php if (!empty($hotThreads)): ?>
                            <?php foreach ($hotThreads as $hotThread): ?>
                                <a href="/thread/show/<?php echo $hotThread['id']; ?>" class="block p-3 bg-gray-900 rounded-lg border border-gray-800 hover:border-cyan-700 transition-colors group">
                                    <h4 class="text-cyan-400 text-sm font-bold mb-1 line-clamp-2 group-hover:text-cyan-300 transition-colors cyber-text">
                                        <?php echo htmlspecialchars($hotThread['title']); ?>
                                    </h4>
                                    <div class="flex justify-between items-center text-xs text-gray-500">
                                        <span class="icon-pulse">
                                            <i class="far fa-eye mr-1"></i>
                                            <span class="stat-count" data-count="<?php echo $hotThread['view_count']; ?>">0</span>
                                        </span>
                                        <span class="icon-pulse">
                                            <i class="far fa-comment mr-1"></i>
                                            <span class="stat-count" data-count="<?php echo $hotThread['reply_count']; ?>">0</span>
                                        </span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-gray-500 text-sm text-center py-4">暂无热门话题</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 动态背景网格
        createCyberGrid();
        
        // 扫描线动画
        createScanlines();
        
        // 标题故障效果
        applyGlitchEffect();
        
        // 滚动渐入效果
        const animatedElements = document.querySelectorAll('.animate-fade-in');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const delay = entry.target.getAttribute('data-delay') || 0;
                    setTimeout(() => {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }, delay);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        animatedElements.forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(el);
        });
        
        // 进度条动画
        const progressBars = document.querySelectorAll('.cyber-progress-bar');
        progressBars.forEach(bar => {
            const width = bar.getAttribute('data-width');
            setTimeout(() => {
                bar.style.width = width;
                bar.style.transition = 'width 1.5s ease-out';
            }, 500);
        });
        
        // 数字计数器动画
        const statCounts = document.querySelectorAll('.stat-count, .thread-view-count, .thread-reply-count');
        statCounts.forEach(count => {
            const target = parseInt(count.getAttribute('data-count'));
            let current = 0;
            const duration = 1500; // 1.5秒
            const step = target / (duration / 16); // 60fps
            
            const timer = setInterval(() => {
                current += step;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                count.textContent = Math.floor(current).toLocaleString();
            }, 16);
        });
        
        // 卡片悬停效果增强
        const threadCards = document.querySelectorAll('.thread-card');
        threadCards.forEach((card, index) => {
            card.addEventListener('mouseenter', function() {
                this.classList.add('transform', 'translate-y-[-5px]', 'transition-transform', 'duration-300');
                this.style.boxShadow = '0 0 15px rgba(0, 255, 255, 0.4)';
                
                // 霓虹边框效果
                const borderColor = ['#00ffff', '#ff00ff', '#00ff00'][index % 3];
                this.style.borderColor = borderColor;
                this.style.boxShadow = `0 0 15px ${borderColor}`;
            });
            
            card.addEventListener('mouseleave', function() {
                this.classList.remove('transform', 'translate-y-[-5px]', 'transition-transform', 'duration-300');
                this.style.boxShadow = 'none';
                this.style.borderColor = '#0a4a5c'; // 恢复原始边框颜色
            });
        });
        
        // 图标脉动效果
        const pulseIcons = document.querySelectorAll('.icon-pulse');
        pulseIcons.forEach((icon, index) => {
            setInterval(() => {
                icon.style.opacity = '0.5';
                setTimeout(() => {
                    icon.style.opacity = '1';
                }, 800);
            }, 3000 + index * 500);
        });
        
        // 按钮点击波纹效果
        const buttons = document.querySelectorAll('.cyber-button, .cyber-button-active');
        buttons.forEach(button => {
            button.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.width = ripple.style.height = size + 'px';
                ripple.style.left = x + 'px';
                ripple.style.top = y + 'px';
                ripple.classList.add('ripple');
                
                this.appendChild(ripple);
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
        });
    });
</script>

<?php include ROOT_PATH . '/app/views/layouts/footer.php'; ?>