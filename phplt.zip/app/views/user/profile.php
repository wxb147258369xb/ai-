<?php include ROOT_PATH . '/app/views/layouts/header.php'; ?>

<!-- 动态背景装饰 -->
<div class="cyber-bg"></div>
<div class="cyber-grid"></div>
<div class="cyber-scanlines"></div>
<div class="cyber-blob blob-1"></div>
<div class="cyber-blob blob-2"></div>
<div class="cyber-blob blob-3"></div>

<section class="py-8 relative z-10">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <!-- 侧边栏：用户信息卡片 -->
            <div class="lg:col-span-3">
                <div class="cyberpunk-card bg-black bg-opacity-70 border border-cyan-500 rounded-xl p-6 shadow-glow-cyan mb-8 animate-fade-in neon-border-purple" data-delay="100">
                    <div class="text-center mb-6">
                        <div class="relative inline-block">
                            <img src="<?php echo !empty($user['avatar']) ? $user['avatar'] : '/images/default_avatar.png'; ?>" 
                                 alt="<?php echo htmlspecialchars($user['username']); ?>" 
                                 class="w-32 h-32 mx-auto rounded-full border-2 border-cyan-600 mb-4 object-cover shadow-glow-cyan pulse-on-hover">
                            <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $user['id']): ?>
                                <button class="absolute bottom-4 right-0 bg-cyan-600 text-black w-8 h-8 rounded-full flex items-center justify-center shadow-glow-cyan hover:bg-cyan-500 transition-colors cyber-button" title="更换头像">
                                    <i class="fas fa-camera"></i>
                                </button>
                            <?php endif; ?>
                        </div>
                        <h2 class="text-2xl font-bold text-white mb-1 cyber-text glitch-text"><?php echo htmlspecialchars($user['username']); ?></h2>
                        <div class="inline-flex items-center px-3 py-1 bg-purple-900 text-purple-300 text-xs rounded-full border border-purple-700 mb-3">
                            <?php echo ucfirst($user['role']); ?>
                        </div>
                        <p class="text-gray-400 text-sm mb-4">加入于 <?php echo date('Y年m月d日', strtotime($user['created_at'])); ?></p>
                        <div class="flex justify-center items-center text-cyan-400">
                            <i class="fas fa-points text-2xl mr-2 icon-pulse"></i>
                            <span class="text-lg font-bold stat-count" data-count="<?php echo $user['points']; ?>">0</span>
                            <span class="ml-1 text-gray-400 text-sm">积分</span>
                        </div>
                    </div>
                    
                    <div class="space-y-4">
                        <div class="bg-gray-900 rounded-lg p-4 border border-gray-800 hover:border-cyan-700 transition-colors">
                            <h3 class="text-gray-400 text-sm mb-2">统计数据</h3>
                            <div class="grid grid-cols-3 gap-2">
                                <div class="text-center">
                                    <div class="text-cyan-400 font-bold stat-count" data-count="<?php echo $userStats['threads']; ?>">0</div>
                                    <div class="text-xs text-gray-500">话题</div>
                                </div>
                                <div class="text-center">
                                    <div class="text-cyan-400 font-bold stat-count" data-count="<?php echo $userStats['replies']; ?>">0</div>
                                    <div class="text-xs text-gray-500">回复</div>
                                </div>
                                <div class="text-center">
                                    <div class="text-cyan-400 font-bold stat-count" data-count="<?php echo $userStats['likes']; ?>">0</div>
                                    <div class="text-xs text-gray-500">获赞</div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != $user['id']): ?>
                            <div class="flex gap-2">
                                <button class="flex-1 py-2 bg-gray-900 border border-gray-700 rounded-lg text-gray-300 hover:bg-gray-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                    <i class="fas fa-user-plus mr-2"></i> 关注
                                </button>
                                <button class="py-2 px-3 bg-gray-900 border border-gray-700 rounded-lg text-gray-300 hover:bg-gray-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                    <i class="fas fa-envelope"></i>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- 主要内容区 -->
            <div class="lg:col-span-9">
                <!-- 用户基本信息 -->
                <div class="cyberpunk-card bg-black bg-opacity-70 border border-cyan-500 rounded-xl p-6 shadow-glow-cyan mb-8 animate-fade-in neon-border-cyan" data-delay="200">
                    <div class="flex justify-between items-center mb-6">
                        <div class="flex items-center">
                            <h2 class="text-xl font-bold text-white cyber-text glitch-text">基本信息</h2>
                            <span class="ml-3 text-xs text-cyan-600 bg-cyan-900 bg-opacity-30 px-2 py-1 rounded">V2.0</span>
                        </div>
                        <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $user['id']): ?>
                            <button class="px-4 py-2 bg-cyan-900 text-cyan-300 rounded-lg hover:bg-cyan-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                <i class="fas fa-edit mr-2"></i> 编辑资料
                            </button>
                        <?php endif; ?>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <div class="mb-4">
                                <label class="block text-gray-500 text-sm mb-1 cyber-label">用户名</label>
                                <p class="text-white cyber-text"><?php echo htmlspecialchars($user['username']); ?></p>
                            </div>
                            <div class="mb-4">
                                <label class="block text-gray-500 text-sm mb-1 cyber-label">邮箱</label>
                                <p class="text-white cyber-text"><?php echo isset($_SESSION['user_id']) && $_SESSION['user_id'] == $user['id'] ? htmlspecialchars($user['email']) : '******'; ?></p>
                            </div>
                            <div>
                                <label class="block text-gray-500 text-sm mb-1 cyber-label">个性签名</label>
                                <p class="text-gray-300 cyber-text"><?php echo !empty($user['signature']) ? htmlspecialchars($user['signature']) : '暂无签名'; ?></p>
                            </div>
                        </div>
                        <div>
                            <div class="mb-4">
                                <label class="block text-gray-500 text-sm mb-1 cyber-label">最后在线</label>
                                <p class="text-white cyber-text"><?php echo timeAgo($user['last_login']); ?></p>
                            </div>
                            <div class="mb-4">
                                <label class="block text-gray-500 text-sm mb-1 cyber-label">所在地</label>
                                <p class="text-white cyber-text"><?php echo !empty($user['location']) ? htmlspecialchars($user['location']) : '未设置'; ?></p>
                            </div>
                            <div>
                                <label class="block text-gray-500 text-sm mb-1 cyber-label">个人网站</label>
                                <p class="text-cyan-400 hover:text-cyan-300 transition-colors cyber-text">
                                    <?php echo !empty($user['website']) ? '<a href="' . htmlspecialchars($user['website']) . '" target="_blank" class="hover:shadow-glow-cyan-sm">' . htmlspecialchars($user['website']) . '</a>' : '未设置'; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 用户动态 -->
                <div class="cyberpunk-card bg-black bg-opacity-70 border border-cyan-500 rounded-xl p-6 shadow-glow-cyan animate-fade-in neon-border-green" data-delay="300">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-xl font-bold text-white cyber-text glitch-text">最近动态</h2>
                        <div class="flex gap-2">
                            <a href="/user/threads/<?php echo $user['id']; ?>" class="px-3 py-1 rounded-lg text-sm bg-cyan-900 text-cyan-300 hover:bg-cyan-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                查看所有话题
                            </a>
                            <a href="/user/replies/<?php echo $user['id']; ?>" class="px-3 py-1 rounded-lg text-sm bg-gray-900 text-gray-300 hover:bg-gray-800 transition-colors cyber-button hover:shadow-glow-cyan-sm">
                                查看所有回复
                            </a>
                        </div>
                    </div>
                    
                    <!-- 动态列表 -->
                    <div class="space-y-6">
                        <?php if (!empty($activities)): ?>
                            <?php foreach ($activities as $index => $activity): ?>
                                <div class="bg-gray-900 border border-gray-800 rounded-lg p-4 hover:border-cyan-700 transition-all duration-300 activity-card animate-fade-in" data-delay="<?php echo 400 + ($index * 100); ?>">
                                    <div class="flex items-start">
                                        <div class="w-10 h-10 rounded-full bg-cyan-900 flex items-center justify-center text-cyan-300 mr-3 flex-shrink-0 icon-pulse">
                                            <?php if ($activity['type'] == 'thread'): ?>
                                                <i class="fas fa-edit"></i>
                                            <?php else: ?>
                                                <i class="fas fa-comment"></i>
                                            <?php endif; ?>
                                        </div>
                                        <div class="flex-1">
                                            <div class="flex justify-between items-start">
                                                <div>
                                                    <h4 class="font-medium text-white cyber-text">
                                                        <?php if ($activity['type'] == 'thread'): ?>
                                                            发布了话题
                                                        <?php else: ?>
                                                            回复了话题
                                                        <?php endif; ?>
                                                    </h4>
                                                    <div class="mt-1 mb-2">
                                                        <a href="/thread/show/<?php echo $activity['thread_id']; ?>" class="text-cyan-400 hover:text-cyan-300 transition-colors cyber-text hover:shadow-glow-cyan-sm">
                                                            <?php echo htmlspecialchars($activity['thread_title']); ?>
                                                        </a>
                                                    </div>
                                                </div>
                                                <span class="text-xs text-gray-500">
                                                    <?php echo timeAgo($activity['created_at']); ?>
                                                </span>
                                            </div>
                                            <div class="text-gray-300 text-sm cyber-text">
                                                <?php echo nl2br(htmlspecialchars(substr($activity['content'], 0, 150))) . (strlen($activity['content']) > 150 ? '...' : ''); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-10 bg-gray-900 rounded-lg animate-fade-in" data-delay="400">
                                <div class="text-gray-500 text-4xl mb-3 icon-pulse">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <p class="text-gray-400 cyber-text">暂无动态</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 动态背景网格
        createCyberGrid();
        
        // 扫描线动画
        createScanlines();
        
        // 标题故障效果
        applyGlitchEffect();
        
        // 滚动渐入效果
        const animatedElements = document.querySelectorAll('.animate-fade-in');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const delay = entry.target.getAttribute('data-delay') || 0;
                    setTimeout(() => {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }, delay);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        animatedElements.forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(el);
        });
        
        // 数字计数器动画
        const statCounts = document.querySelectorAll('.stat-count');
        statCounts.forEach(count => {
            const target = parseInt(count.getAttribute('data-count'));
            let current = 0;
            const duration = 1500; // 1.5秒
            const step = target / (duration / 16); // 60fps
            
            const timer = setInterval(() => {
                current += step;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                count.textContent = Math.floor(current).toLocaleString();
            }, 16);
        });
        
        // 动态卡片悬停效果
        const activityCards = document.querySelectorAll('.activity-card');
        activityCards.forEach((card, index) => {
            card.addEventListener('mouseenter', function() {
                this.classList.add('transform', 'translate-y-[-5px]', 'transition-transform', 'duration-300');
                
                // 霓虹边框效果
                const borderColor = ['#00ffff', '#ff00ff', '#00ff00'][index % 3];
                this.style.borderColor = borderColor;
                this.style.boxShadow = `0 0 15px ${borderColor}`;
            });
            
            card.addEventListener('mouseleave', function() {
                this.classList.remove('transform', 'translate-y-[-5px]', 'transition-transform', 'duration-300');
                this.style.borderColor = '#1f2937'; // 恢复原始边框颜色
                this.style.boxShadow = 'none';
            });
        });
        
        // 图标脉动效果
        const pulseIcons = document.querySelectorAll('.icon-pulse');
        pulseIcons.forEach((icon, index) => {
            setInterval(() => {
                icon.style.opacity = '0.5';
                setTimeout(() => {
                    icon.style.opacity = '1';
                }, 800);
            }, 3000 + index * 500);
        });
        
        // 按钮点击波纹效果
        const buttons = document.querySelectorAll('.cyber-button');
        buttons.forEach(button => {
            button.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.width = ripple.style.height = size + 'px';
                ripple.style.left = x + 'px';
                ripple.style.top = y + 'px';
                ripple.classList.add('ripple');
                
                this.appendChild(ripple);
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
        });
        
        // 处理头像上传按钮点击（在实际项目中需要添加文件上传功能）
        const avatarUploadBtn = document.querySelector('button[title="更换头像"]');
        if (avatarUploadBtn) {
            avatarUploadBtn.addEventListener('click', function() {
                // 在实际项目中，这里可以触发文件选择对话框
                alert('头像上传功能正在开发中');
            });
        }
        
        // 编辑资料按钮
        const editProfileBtn = document.querySelector('button:has(.fa-edit)');
        if (editProfileBtn) {
            editProfileBtn.addEventListener('click', function() {
                // 在实际项目中，这里可以打开编辑资料模态框或跳转到编辑页面
                window.location.href = '/auth/edit_profile';
            });
        }
    });
</script>

<?php include ROOT_PATH . '/app/views/layouts/footer.php'; ?>