<!-- 页脚 -->
    <footer class="bg-dark border-t border-neon-blue/30 mt-auto">
        <div class="container mx-auto px-4 py-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <!-- 关于我们 -->
                <div>
                    <div class="flex items-center gap-2 mb-4">
                        <div class="h-8 w-8 bg-primary rounded flex items-center justify-center">
                            <i class="fa fa-connectdevelop text-lg text-dark"></i>
                        </div>
                        <span class="text-lg font-cyber font-bold text-primary">NEXUS</span>
                    </div>
                    <p class="text-gray-400 text-sm mb-4">
                        Nexus 是一个具有未来感的赛博朋克风格社区论坛，
                        致力于为用户提供一个独特而沉浸式的交流平台。
                    </p>
                    <div class="flex gap-3">
                        <a href="#" class="h-8 w-8 rounded-full border border-neon-blue/50 flex items-center justify-center hover:bg-neon-blue/10 transition-colors">
                            <i class="fa fa-weibo text-neon-blue"></i>
                        </a>
                        <a href="#" class="h-8 w-8 rounded-full border border-neon-blue/50 flex items-center justify-center hover:bg-neon-blue/10 transition-colors">
                            <i class="fa fa-wechat text-neon-green"></i>
                        </a>
                        <a href="#" class="h-8 w-8 rounded-full border border-neon-blue/50 flex items-center justify-center hover:bg-neon-blue/10 transition-colors">
                            <i class="fa fa-qq text-neon-blue"></i>
                        </a>
                        <a href="#" class="h-8 w-8 rounded-full border border-neon-blue/50 flex items-center justify-center hover:bg-neon-blue/10 transition-colors">
                            <i class="fa fa-github text-white"></i>
                        </a>
                    </div>
                </div>
                
                <!-- 快速链接 -->
                <div>
                    <h3 class="text-white font-cyber text-sm uppercase tracking-wider mb-4 text-neon-blue">快速链接</h3>
                    <ul class="space-y-2">
                        <li><a href="/" class="text-gray-400 hover:text-white transition-colors">首页</a></li>
                        <li><a href="/forum" class="text-gray-400 hover:text-white transition-colors">版块浏览</a></li>
                        <li><a href="/ranking" class="text-gray-400 hover:text-white transition-colors">排行榜</a></li>
                        <li><a href="/shop" class="text-gray-400 hover:text-white transition-colors">积分商城</a></li>
                        <li><a href="/help" class="text-gray-400 hover:text-white transition-colors">帮助中心</a></li>
                    </ul>
                </div>
                
                <!-- 帮助中心 -->
                <div>
                    <h3 class="text-white font-cyber text-sm uppercase tracking-wider mb-4 text-neon-pink">帮助中心</h3>
                    <ul class="space-y-2">
                        <li><a href="/faq" class="text-gray-400 hover:text-white transition-colors">常见问题</a></li>
                        <li><a href="/rules" class="text-gray-400 hover:text-white transition-colors">论坛规则</a></li>
                        <li><a href="/terms" class="text-gray-400 hover:text-white transition-colors">服务条款</a></li>
                        <li><a href="/privacy" class="text-gray-400 hover:text-white transition-colors">隐私政策</a></li>
                        <li><a href="/contact" class="text-gray-400 hover:text-white transition-colors">联系我们</a></li>
                    </ul>
                </div>
                
                <!-- 订阅 -->
                <div>
                    <h3 class="text-white font-cyber text-sm uppercase tracking-wider mb-4 text-neon-purple">订阅通知</h3>
                    <p class="text-gray-400 text-sm mb-3">
                        订阅我们的通知，获取最新活动和更新信息。
                    </p>
                    <form class="flex">
                        <input type="email" placeholder="您的邮箱地址" class="flex-1 px-4 py-2 bg-darker border border-gray-700 rounded-l focus:outline-none focus:border-neon-blue">
                        <button type="submit" class="px-4 py-2 bg-neon-blue text-dark font-medium rounded-r hover:bg-neon-blue/80 transition-colors">
                            订阅
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="border-t border-gray-800 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
                <p class="text-gray-500 text-sm mb-4 md:mb-0">
                    &copy; 2024 Nexus 论坛. 保留所有权利.
                </p>
                <div class="flex gap-4">
                    <a href="/terms" class="text-gray-500 hover:text-gray-300 text-sm">服务条款</a>
                    <a href="/privacy" class="text-gray-500 hover:text-gray-300 text-sm">隐私政策</a>
                    <a href="/cookies" class="text-gray-500 hover:text-gray-300 text-sm">Cookie 设置</a>
                </div>
            </div>
        </div>
        
        <!-- 底部霓虹线 -->
        <div class="h-1 bg-gradient-to-r from-neon-blue via-neon-pink to-neon-green"></div>
    </footer>
    
    <!-- 返回顶部按钮 -->
    <button id="back-to-top" class="fixed bottom-6 right-6 h-12 w-12 bg-neon-blue rounded-full flex items-center justify-center text-dark font-medium opacity-0 invisible transition-all duration-300 hover:bg-neon-blue/80">
        <i class="fa fa-arrow-up"></i>
    </button>
    
    <!-- JavaScript -->
    <script src="/js/cyberpunk.js"></script>
    
    <!-- 页面加载完成后执行的脚本 -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 导航栏滚动效果
            const header = document.querySelector('header');
            window.addEventListener('scroll', function() {
                if (window.scrollY > 10) {
                    header.classList.add('py-2');
                    header.classList.add('shadow-lg');
                    header.classList.add('shadow-neon-blue/10');
                } else {
                    header.classList.remove('py-2');
                    header.classList.remove('shadow-lg');
                    header.classList.remove('shadow-neon-blue/10');
                }
            });
            
            // 移动端菜单切换
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const mobileMenu = document.getElementById('mobile-menu');
            if (mobileMenuBtn && mobileMenu) {
                mobileMenuBtn.addEventListener('click', function() {
                    mobileMenu.classList.toggle('hidden');
                });
            }
            
            // 返回顶部按钮
            const backToTopBtn = document.getElementById('back-to-top');
            if (backToTopBtn) {
                window.addEventListener('scroll', function() {
                    if (window.scrollY > 300) {
                        backToTopBtn.classList.remove('opacity-0', 'invisible');
                    } else {
                        backToTopBtn.classList.add('opacity-0', 'invisible');
                    }
                });
                
                backToTopBtn.addEventListener('click', function() {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                });
            }
            
            // 添加卡片悬停效果
            document.querySelectorAll('.cyberpunk-card').forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.classList.add('neon-border');
                    this.classList.add('transition-all');
                    this.classList.add('duration-300');
                });
                card.addEventListener('mouseleave', function() {
                    this.classList.remove('neon-border');
                });
            });
        });
    </script>
</body>
</html>