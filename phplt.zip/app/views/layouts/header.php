<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($title) ? $title . ' - Nexus 论坛' : 'Nexus 论坛'; ?></title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    
    <!-- 自定义样式 -->
    <link rel="stylesheet" href="/css/cyberpunk.css">
    
    <!-- Tailwind 配置 -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        // 赛博朋克主题色
                        primary: '#00ff00',
                        secondary: '#ff00ff',
                        accent: '#00bfff',
                        danger: '#ff0000',
                        warning: '#ff6600',
                        dark: '#121212',
                        darker: '#0a0a0a',
                        neon: {
                            green: '#00ff00',
                            blue: '#00bfff',
                            pink: '#ff00ff',
                            purple: '#9900ff',
                            yellow: '#ffff00'
                        }
                    },
                    fontFamily: {
                        cyber: ['Orbitron', 'Rajdhani', 'sans-serif'],
                        mono: ['Courier New', 'monospace']
                    },
                    animation: {
                        'glow': 'glow 2s ease-in-out infinite alternate',
                        'float': 'float 3s ease-in-out infinite',
                        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                        'glitch': 'glitch 1s infinite',
                        'scanline': 'scanline 6s linear infinite'
                    },
                    keyframes: {
                        glow: {
                            '0%': { textShadow: '0 0 5px #fff, 0 0 10px #00ff00' },
                            '100%': { textShadow: '0 0 10px #fff, 0 0 20px #00ff00, 0 0 30px #00ff00' }
                        },
                        float: {
                            '0%, 100%': { transform: 'translateY(0)' },
                            '50%': { transform: 'translateY(-10px)' }
                        },
                        glitch: {
                            '0%, 100%': { transform: 'translate(0)' },
                            '20%': { transform: 'translate(-5px, 5px)' },
                            '40%': { transform: 'translate(-5px, -5px)' },
                            '60%': { transform: 'translate(5px, 5px)' },
                            '80%': { transform: 'translate(5px, -5px)' }
                        },
                        scanline: {
                            '0%': { top: '-100%' },
                            '100%': { top: '100%' }
                        }
                    }
                }
            }
        }
    </script>
    
    <style type="text/tailwindcss">
        @layer utilities {
            .content-auto { content-visibility: auto; }
            .neon-border {
                box-shadow: 0 0 5px theme('colors.neon.blue'), 0 0 10px theme('colors.neon.blue');
                border: 1px solid theme('colors.neon.blue');
            }
            .neon-text {
                text-shadow: 0 0 5px #fff, 0 0 10px theme('colors.neon.blue');
            }
            .cyberpunk-card {
                background: rgba(18, 18, 18, 0.8);
                border: 1px solid rgba(0, 191, 255, 0.3);
                box-shadow: 0 0 10px rgba(0, 191, 255, 0.2);
            }
            .glassmorphism {
                background: rgba(18, 18, 18, 0.6);
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
            }
            .scanline-effect::before {
                content: '';
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 3px;
                background: rgba(255, 255, 255, 0.1);
                z-index: 50;
                animation: scanline 6s linear infinite;
            }
        }
    </style>
</head>
<body class="bg-darker text-gray-200 font-sans min-h-screen flex flex-col">
    <!-- 扫描线效果 -->
    <div class="scanline-effect fixed inset-0 pointer-events-none z-50"></div>
    
    <!-- 导航栏 -->
    <header class="glassmorphism sticky top-0 z-40 border-b border-neon-blue/30">
        <nav class="container mx-auto px-4 py-3 flex items-center justify-between">
            <!-- Logo -->
            <a href="/" class="flex items-center gap-2">
                <div class="h-10 w-10 bg-primary rounded flex items-center justify-center animate-pulse-slow">
                    <i class="fa fa-connectdevelop text-2xl text-dark"></i>
                </div>
                <span class="text-xl font-cyber font-bold text-primary animate-glow">NEXUS</span>
            </a>
            
            <!-- 主导航 -->
            <div class="hidden md:flex items-center gap-6">
                <a href="/" class="text-neon-blue hover:text-white transition-colors font-medium">首页</a>
                <a href="/forum" class="text-gray-400 hover:text-white transition-colors">版块</a>
                <a href="/ranking" class="text-gray-400 hover:text-white transition-colors">排行榜</a>
                <a href="/shop" class="text-gray-400 hover:text-white transition-colors">积分商城</a>
            </div>
            
            <!-- 用户区域 -->
            <div class="flex items-center gap-4">
                <?php if (isset($_SESSION['user'])): ?>
                    <!-- 已登录 -->
                    <div class="relative group">
                        <button class="flex items-center gap-2 p-2 rounded-full hover:bg-gray-800 transition-colors">
                            <img src="/images/<?php echo $_SESSION['user']['avatar'] ?? 'default_avatar.png'; ?>" alt="头像" class="h-8 w-8 rounded-full border border-neon-blue/50">
                            <span class="hidden md:inline text-sm font-medium text-white"><?php echo $_SESSION['user']['username']; ?></span>
                            <i class="fa fa-angle-down text-gray-400"></i>
                        </button>
                        <!-- 下拉菜单 -->
                        <div class="absolute right-0 mt-2 w-48 cyberpunk-card rounded-md overflow-hidden opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform group-hover:translate-y-0 translate-y-2 z-50">
                            <a href="/profile" class="block px-4 py-3 hover:bg-gray-800 transition-colors flex items-center gap-2">
                                <i class="fa fa-user text-neon-blue"></i>
                                <span>个人中心</span>
                            </a>
                            <a href="/settings" class="block px-4 py-3 hover:bg-gray-800 transition-colors flex items-center gap-2">
                                <i class="fa fa-cog text-neon-blue"></i>
                                <span>设置</span>
                            </a>
                            <?php if ($_SESSION['user']['role'] === 'admin' || $_SESSION['user']['role'] === 'moderator'): ?>
                                <a href="/admin" class="block px-4 py-3 hover:bg-gray-800 transition-colors flex items-center gap-2">
                                    <i class="fa fa-tachometer text-neon-pink"></i>
                                    <span>管理后台</span>
                                </a>
                            <?php endif; ?>
                            <div class="border-t border-gray-700"></div>
                            <a href="/logout" class="block px-4 py-3 hover:bg-gray-800 transition-colors flex items-center gap-2">
                                <i class="fa fa-sign-out text-danger"></i>
                                <span>退出登录</span>
                            </a>
                        </div>
                    </div>
                    <!-- 消息通知 -->
                    <button class="relative p-2 rounded-full hover:bg-gray-800 transition-colors">
                        <i class="fa fa-bell text-gray-400 hover:text-white"></i>
                        <span class="absolute top-1 right-1 h-2 w-2 bg-danger rounded-full"></span>
                    </button>
                <?php else: ?>
                    <!-- 未登录 -->
                    <a href="/login" class="px-4 py-2 border border-neon-blue text-neon-blue rounded hover:bg-neon-blue/10 transition-colors">登录</a>
                    <a href="/register" class="px-4 py-2 bg-neon-blue text-dark font-medium rounded hover:bg-neon-blue/80 transition-colors">注册</a>
                <?php endif; ?>
                
                <!-- 移动端菜单按钮 -->
                <button id="mobile-menu-btn" class="md:hidden p-2 rounded-full hover:bg-gray-800 transition-colors">
                    <i class="fa fa-bars text-gray-400 hover:text-white"></i>
                </button>
            </div>
        </nav>
        
        <!-- 移动端菜单 -->
        <div id="mobile-menu" class="md:hidden bg-dark/95 hidden">
            <div class="container mx-auto px-4 py-3 space-y-3">
                <a href="/" class="block px-4 py-2 rounded bg-gray-800 text-neon-blue">首页</a>
                <a href="/forum" class="block px-4 py-2 rounded hover:bg-gray-800 transition-colors">版块</a>
                <a href="/ranking" class="block px-4 py-2 rounded hover:bg-gray-800 transition-colors">排行榜</a>
                <a href="/shop" class="block px-4 py-2 rounded hover:bg-gray-800 transition-colors">积分商城</a>
                <?php if (!isset($_SESSION['user'])): ?>
                    <div class="flex gap-2 pt-2 border-t border-gray-800">
                        <a href="/login" class="flex-1 text-center px-4 py-2 border border-neon-blue text-neon-blue rounded hover:bg-neon-blue/10 transition-colors">登录</a>
                        <a href="/register" class="flex-1 text-center px-4 py-2 bg-neon-blue text-dark font-medium rounded hover:bg-neon-blue/80 transition-colors">注册</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </header>