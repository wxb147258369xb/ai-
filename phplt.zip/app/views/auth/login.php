<?php include ROOT_PATH . '/app/views/layouts/header.php'; ?>

<!-- 动态背景 -->
<div class="fixed inset-0 bg-grid-cyan opacity-10 z-[-2]"></div>
<div class="fixed inset-0 bg-black z-[-3]"></div>
<div class="scanlines absolute inset-0 z-[-1] pointer-events-none"></div>

<!-- 装饰性元素 -->
<div class="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-[-1]">
    <div class="absolute top-1/4 left-1/4 w-72 h-72 bg-blue-600 rounded-full mix-blend-multiply filter blur-[100px] opacity-20 animate-blob"></div>
    <div class="absolute top-1/3 right-1/3 w-72 h-72 bg-cyan-600 rounded-full mix-blend-multiply filter blur-[100px] opacity-20 animate-blob animation-delay-2000"></div>
    <div class="absolute bottom-1/4 right-1/4 w-72 h-72 bg-purple-600 rounded-full mix-blend-multiply filter blur-[100px] opacity-20 animate-blob animation-delay-4000"></div>
</div>

<!-- 登录页面 -->
<section class="min-h-[calc(100vh-120px)] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 relative">
    <div class="max-w-md w-full space-y-8 z-10">
        <!-- 登录卡片 -->
        <div class="bg-black bg-opacity-80 border border-cyan-800 rounded-lg shadow-glow-cyan p-8 cyberpunk-card animate-fade-in neon-border">
            <!-- 登录标题 -->
            <div class="text-center">
                <h2 class="text-3xl font-bold text-cyan-400 mb-2 tracking-wider cyberpunk-title">
                    <i class="fas fa-terminal mr-2"></i>登录系统
                    <span class="text-xs text-cyan-400 bg-cyan-900/30 px-2 py-1 rounded-full ml-2 border border-cyan-700">
                        V2.0
                    </span>
                </h2>
                <div class="text-gray-400 text-sm">
                    请输入您的账号密码以继续
                </div>
                <div class="mt-6">
                    <div class="w-32 h-1 bg-gradient-to-r from-cyan-500 to-blue-500 mx-auto rounded-full shadow-glow-cyan"></div>
                </div>
            </div>

            <!-- 登录表单 -->
            <form class="mt-8 space-y-6" action="/auth/login" method="post">
                <!-- 错误提示 -->
                <?php if (!empty($errors)): ?>
                    <div class="bg-red-900/30 border border-red-800 rounded-lg p-4 animate-fade-in error-notification">
                        <div class="text-red-400 font-medium mb-2">
                            <i class="fas fa-exclamation-triangle mr-2"></i>登录失败
                        </div>
                        <ul class="list-disc pl-5 text-gray-400 text-sm">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- 成功提示 -->
                <?php if (!empty($success_message)): ?>
                    <div class="bg-green-900/30 border border-green-800 rounded-lg p-4 animate-fade-in success-notification">
                        <div class="text-green-400">
                            <i class="fas fa-check-circle mr-2"></i><?php echo $success_message; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- 用户名/邮箱 -->
                <div class="input-wrapper animate-fade-in" style="animation-delay: 0.2s">
                    <label for="username" class="block text-gray-300 mb-1 text-sm font-medium cyber-label">
                        用户名/邮箱
                    </label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-user text-gray-500 cyber-icon"></i>
                        </div>
                        <input id="username" name="username" type="text" required 
                               class="appearance-none block w-full pl-10 pr-3 py-3 bg-gray-900 border border-gray-700 rounded-lg 
                                      text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-cyan-400 
                                      focus:border-cyan-400 transition-colors duration-200 cyber-input" 
                               placeholder="输入用户名或邮箱" 
                               value="<?php echo !empty($username) ? htmlspecialchars($username) : ''; ?>">
                    </div>
                </div>

                <!-- 密码 -->
                <div class="input-wrapper animate-fade-in" style="animation-delay: 0.3s">
                    <label for="password" class="block text-gray-300 mb-1 text-sm font-medium cyber-label">
                        密码
                    </label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-500 cyber-icon"></i>
                        </div>
                        <input id="password" name="password" type="password" required 
                               class="appearance-none block w-full pl-10 pr-10 py-3 bg-gray-900 border border-gray-700 rounded-lg 
                                      text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-cyan-400 
                                      focus:border-cyan-400 transition-colors duration-200 cyber-input" 
                               placeholder="输入密码">
                        <div class="absolute inset-y-0 right-0 pr-3 flex items-center">
                            <button type="button" id="toggle-password" class="text-gray-500 hover:text-white focus:outline-none cyber-button-icon">
                                <i class="far fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- 记住我和忘记密码 -->
                <div class="flex items-center justify-between animate-fade-in" style="animation-delay: 0.4s">
                    <div class="flex items-center">
                        <input id="remember" name="remember" type="checkbox" 
                               class="h-4 w-4 text-cyan-500 border-gray-700 rounded focus:ring-cyan-500 bg-gray-900 cyber-checkbox">
                        <label for="remember" class="ml-2 block text-gray-400 text-sm cyber-checkbox-label">
                            记住我
                        </label>
                    </div>
                    <div class="text-sm">
                        <a href="/auth/forgot" class="font-medium text-cyan-400 hover:text-cyan-300 transition-colors cyber-link">
                            忘记密码？
                        </a>
                    </div>
                </div>

                <!-- 登录按钮 -->
                <div class="animate-fade-in" style="animation-delay: 0.5s">
                    <button type="submit" 
                            class="group relative w-full flex justify-center py-3 px-4 border border-transparent rounded-lg text-black font-bold tracking-wide bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 transition-all duration-300 focus:outline-none shadow-glow-cyan cyber-button">
                        <span class="absolute left-0 inset-y-0 flex items-center pl-4">
                            <i class="fas fa-sign-in-alt text-black cyber-button-icon"></i>
                        </span>
                        登录账户
                    </button>
                </div>
            </form>

            <!-- 注册链接 -->
            <div class="mt-6 text-center animate-fade-in" style="animation-delay: 0.6s">
                <div class="text-sm">
                    <span class="text-gray-400">还没有账号？</span>
                    <a href="/auth/register" class="font-medium text-cyan-400 hover:text-cyan-300 transition-colors ml-1 cyber-link">
                        立即注册
                    </a>
                </div>
            </div>
        </div>

        <!-- 快速登录选项 -->
        <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg shadow-glow-cyan p-6 cyberpunk-card animate-fade-in neon-border" style="animation-delay: 0.7s">
            <div class="flex items-center justify-center mb-4">
                <div class="flex-grow h-px bg-gray-800"></div>
                <span class="px-3 text-sm text-gray-500">快速登录</span>
                <div class="flex-grow h-px bg-gray-800"></div>
            </div>
            <div class="grid grid-cols-3 gap-4">
                <button class="flex flex-col items-center justify-center py-3 px-4 bg-gray-900 border border-gray-800 rounded-lg hover:border-cyan-700 transition-all duration-300 hover:shadow-glow-cyan-sm hover:-translate-y-1 social-button">
                    <i class="fab fa-github text-2xl text-gray-400 mb-2 group-hover:text-white social-icon"></i>
                    <span class="text-xs text-gray-500">GitHub</span>
                </button>
                <button class="flex flex-col items-center justify-center py-3 px-4 bg-gray-900 border border-gray-800 rounded-lg hover:border-cyan-700 transition-all duration-300 hover:shadow-glow-cyan-sm hover:-translate-y-1 social-button">
                    <i class="fab fa-google text-2xl text-gray-400 mb-2 group-hover:text-white social-icon"></i>
                    <span class="text-xs text-gray-500">Google</span>
                </button>
                <button class="flex flex-col items-center justify-center py-3 px-4 bg-gray-900 border border-gray-800 rounded-lg hover:border-cyan-700 transition-all duration-300 hover:shadow-glow-cyan-sm hover:-translate-y-1 social-button">
                    <i class="fab fa-twitter text-2xl text-gray-400 mb-2 group-hover:text-white social-icon"></i>
                    <span class="text-xs text-gray-500">Twitter</span>
                </button>
            </div>
        </div>

        <!-- 站点信息 -->
        <div class="text-center text-xs text-gray-600 animate-fade-in" style="animation-delay: 0.8s">
            <p>&copy; 2023 CYBERNETIC FORUM. <span class="text-cyan-500 cyber-text">赛博朋克风格论坛系统</span></p>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 动态背景网格动画
        const createGrid = () => {
            const grid = document.createElement('div');
            grid.className = 'bg-grid-cyan';
            let html = '';
            for (let i = 0; i < 50; i++) {
                html += '<div class="absolute h-[1px] bg-cyan-500/20" style="top:' + (i * 2) + 'vh; left:0; right:0;"></div>';
            }
            for (let i = 0; i < 50; i++) {
                html += '<div class="absolute w-[1px] bg-cyan-500/20" style="left:' + (i * 2) + 'vw; top:0; bottom:0;"></div>';
            }
            grid.innerHTML = html;
            document.querySelector('.fixed.inset-0.bg-grid-cyan').appendChild(grid);
        };
        createGrid();
        
        // 扫描线效果
        const createScanlines = () => {
            const scanlines = document.querySelector('.scanlines');
            let html = '';
            for (let i = 0; i < 50; i++) {
                html += '<div class="absolute h-[1px] bg-cyan-500/10" style="top:' + (i * 2) + 'vh; left:0; right:0; animation: scanline 6s linear infinite;"></div>';
            }
            scanlines.innerHTML = html;
        };
        createScanlines();
        
        // 添加动画样式
        const style = document.createElement('style');
        style.innerHTML = `
            @keyframes scanline {
                0% { opacity: 0.1; }
                50% { opacity: 0.2; }
                100% { opacity: 0.1; }
            }
            @keyframes glitch {
                0% { transform: translate(0); }
                20% { transform: translate(-2px, 2px); }
                40% { transform: translate(-2px, -2px); }
                60% { transform: translate(2px, 2px); }
                80% { transform: translate(2px, -2px); }
                100% { transform: translate(0); }
            }
            @keyframes fadeInUp {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }
            @keyframes pulse {
                0%, 100% { opacity: 0.7; }
                50% { opacity: 1; }
            }
            @keyframes blob {
                0% { transform: translate(0px, 0px) scale(1); }
                33% { transform: translate(30px, -50px) scale(1.1); }
                66% { transform: translate(-20px, 20px) scale(0.9); }
                100% { transform: translate(0px, 0px) scale(1); }
            }
            .animate-blob {
                animation: blob 7s infinite;
            }
            .animation-delay-2000 {
                animation-delay: 2s;
            }
            .animation-delay-4000 {
                animation-delay: 4s;
            }
            .animate-fade-in {
                animation: fadeInUp 0.8s ease forwards;
                opacity: 0;
            }
            .ripple {
                position: absolute;
                border-radius: 50%;
                background-color: rgba(255, 255, 255, 0.3);
                transform: scale(0);
                animation: ripple 0.6s linear;
                pointer-events: none;
            }
            @keyframes ripple {
                to { transform: scale(4); opacity: 0; }
            }
            .neon-border {
                position: relative;
            }
            .neon-border::before {
                content: '';
                position: absolute;
                top: -2px;
                left: -2px;
                right: -2px;
                bottom: -2px;
                border: 2px solid transparent;
                background: linear-gradient(45deg, cyan, blue, purple, cyan) border-box;
                -webkit-mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);
                -webkit-mask-composite: xor;
                mask-composite: exclude;
                z-index: -1;
                border-radius: 8px;
                animation: borderRotate 4s linear infinite;
            }
            @keyframes borderRotate {
                0% {
                    background-position: 0% 0%;
                }
                100% {
                    background-position: 300% 0%;
                }
            }
        `;
        document.head.appendChild(style);
        
        // 密码显示切换
        const togglePassword = document.getElementById('toggle-password');
        const passwordInput = document.getElementById('password');
        
        if (togglePassword && passwordInput) {
            togglePassword.addEventListener('click', function() {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                // 切换图标
                const icon = this.querySelector('i');
                if (type === 'password') {
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                } else {
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                }
            });
        }

        // 表单输入焦点效果
        const formInputs = document.querySelectorAll('.cyber-input');
        formInputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.style.boxShadow = '0 0 10px rgba(6, 182, 212, 0.5)';
                this.style.borderColor = '#06b6d4';
            });
            input.addEventListener('blur', function() {
                this.style.boxShadow = 'none';
                this.style.borderColor = '#1f2937';
            });
        });

        // 图标脉动效果
        const pulseIcon = () => {
            const icons = document.querySelectorAll('.cyber-icon');
            icons.forEach(icon => {
                setInterval(() => {
                    icon.style.transform = 'scale(1.1)';
                    setTimeout(() => {
                        icon.style.transform = 'scale(1)';
                    }, 500);
                }, 2000);
            });
        };
        pulseIcon();
        
        // 按钮点击波纹效果
        const addRippleEffect = () => {
            const buttons = document.querySelectorAll('.cyber-button');
            buttons.forEach(button => {
                button.addEventListener('click', function(e) {
                    const ripple = document.createElement('span');
                    const rect = this.getBoundingClientRect();
                    const size = Math.max(rect.width, rect.height);
                    const x = e.clientX - rect.left - size / 2;
                    const y = e.clientY - rect.top - size / 2;
                    
                    ripple.style.width = ripple.style.height = size + 'px';
                    ripple.style.left = x + 'px';
                    ripple.style.top = y + 'px';
                    ripple.classList.add('ripple');
                    
                    this.appendChild(ripple);
                    setTimeout(() => {
                        ripple.remove();
                    }, 600);
                });
            });
        };
        addRippleEffect();
        
        // 标题故障效果
        const glitchEffect = () => {
            const titles = document.querySelectorAll('.cyberpunk-title');
            titles.forEach(title => {
                setInterval(() => {
                    title.style.textShadow = '2px 0 0 rgba(255,0,255,0.7), -2px 0 0 rgba(0,255,255,0.7)';
                    title.style.animation = 'glitch 0.2s linear';
                    setTimeout(() => {
                        title.style.textShadow = 'none';
                        title.style.animation = 'none';
                    }, 200);
                }, Math.random() * 5000 + 3000);
            });
        };
        glitchEffect();
        
        // 社交按钮悬停效果增强
        const socialButtons = document.querySelectorAll('.social-button');
        socialButtons.forEach((button, index) => {
            button.addEventListener('mouseenter', function() {
                this.style.borderColor = '#06b6d4';
                this.querySelector('.social-icon').style.color = '#06b6d4';
            });
            button.addEventListener('mouseleave', function() {
                this.style.borderColor = '#1f2937';
                this.querySelector('.social-icon').style.color = '#9ca3af';
            });
        });
        
        // 通知闪烁效果
        const notifications = document.querySelectorAll('.error-notification, .success-notification');
        notifications.forEach(notification => {
            notification.style.animation = 'pulse 1.5s ease-in-out infinite';
        });
        
        // 链接悬停效果
        const links = document.querySelectorAll('.cyber-link');
        links.forEach(link => {
            link.addEventListener('mouseenter', function() {
                this.style.textDecoration = 'underline';
                this.style.textShadow = '0 0 5px rgba(6, 182, 212, 0.7)';
            });
            link.addEventListener('mouseleave', function() {
                this.style.textDecoration = 'none';
                this.style.textShadow = 'none';
            });
        });
        
        // 输入框标签动画
        const labels = document.querySelectorAll('.cyber-label');
        formInputs.forEach((input, index) => {
            input.addEventListener('focus', function() {
                labels[index].style.color = '#06b6d4';
                labels[index].style.transform = 'translateX(5px)';
                labels[index].style.transition = 'all 0.3s ease';
            });
            input.addEventListener('blur', function() {
                labels[index].style.color = '#d1d5db';
                labels[index].style.transform = 'translateX(0)';
            });
        });
        
        // 页面载入效果
        document.body.classList.add('loaded');
    });
</script>

<?php include ROOT_PATH . '/app/views/layouts/footer.php'; ?>