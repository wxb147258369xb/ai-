<?php include ROOT_PATH . '/app/views/layouts/header.php'; ?>

<!-- 动态背景装饰 -->
<div class="cyberpunk-bg fixed inset-0 z-0">
    <div class="grid-overlay"></div>
    <div class="scanline"></div>
    <div class="cyber-blob blob-1"></div>
    <div class="cyber-blob blob-2"></div>
    <div class="cyber-blob blob-3"></div>
</div>

<section class="py-8 relative z-10">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <!-- 主要内容区 -->
            <div class="lg:col-span-8">
                <!-- 编辑个人资料表单 -->
                <div class="cyberpunk-card neon-border-cyan bg-black bg-opacity-70 rounded-lg p-6 mb-8 shadow-glow-cyan animate-fade-in">
                    <div class="flex items-center justify-between mb-6">
                        <h1 class="text-2xl font-bold text-cyan-400 glitch-text">编辑个人资料 <span class="text-xs bg-cyan-900 text-cyan-300 px-2 py-1 rounded ml-2">V2.0</span></h1>
                        <a href="/user/profile/<?php echo $user['id']; ?>" class="px-4 py-2 bg-gray-800 border border-cyan-700 rounded-lg text-gray-300 hover:bg-gray-700 transition-all duration-300 cyber-btn">
                            <i class="fas fa-arrow-left mr-2"></i> 返回
                        </a>
                    </div>
                    
                    <!-- 错误/成功消息 -->
                    <?php if (isset($error)): ?>
                        <div class="bg-red-900 bg-opacity-50 border border-red-700 rounded-lg p-4 mb-6 animate-fade-in" style="animation-delay: 0.2s;">
                            <p class="text-red-300"><i class="fas fa-exclamation-circle mr-2"></i> <?php echo htmlspecialchars($error); ?></p>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['message']) && $_SESSION['message']['type'] === 'success'): ?>
                        <div class="bg-green-900 bg-opacity-50 border border-green-700 rounded-lg p-4 mb-6 animate-fade-in" style="animation-delay: 0.2s;">
                            <p class="text-green-300"><i class="fas fa-check-circle mr-2"></i> <?php echo htmlspecialchars($_SESSION['message']['text']); ?></p>
                        </div>
                        <?php unset($_SESSION['message']); ?>
                    <?php endif; ?>
                    
                    <form action="/user/editProfile" method="post" class="edit-profile-form">
                        <!-- 用户头像 -->
                        <div class="flex flex-col md:flex-row items-center mb-8 animate-fade-in" style="animation-delay: 0.3s;">
                            <div class="relative mb-4 md:mb-0 md:mr-6">
                                <div class="avatar-container relative group">
                                    <img src="<?php echo !empty($user['avatar']) ? $user['avatar'] : '/images/default_avatar.png'; ?>" alt="您的头像" class="w-24 h-24 rounded-full border-2 border-cyan-600 object-cover transition-transform duration-300 group-hover:scale-105">
                                    <div class="avatar-overlay absolute inset-0 bg-black bg-opacity-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                                        <button type="button" class="w-10 h-10 bg-cyan-600 rounded-full flex items-center justify-center text-black shadow-glow-cyan avatar-upload-btn transform transition-transform hover:scale-110">
                                            <i class="fas fa-camera"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center md:text-left">
                                <h3 class="text-lg font-bold text-white mb-1"><?php echo htmlspecialchars($user['username']); ?></h3>
                                <p class="text-gray-400 text-sm mb-2">点击头像可上传新头像</p>
                                <span class="text-gray-500 text-xs">支持 JPG、PNG、GIF 格式，大小不超过 2MB</span>
                            </div>
                        </div>
                        
                        <!-- 基本信息 -->
                        <div class="mb-6 animate-fade-in" style="animation-delay: 0.4s;">
                            <label for="username" class="block text-gray-300 font-medium mb-2 cyber-label">用户名</label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-cyan-500">
                                    <i class="fas fa-user"></i>
                                </span>
                                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" 
                                       class="w-full bg-gray-900 border border-cyan-700 rounded-lg px-10 py-3 text-gray-300 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all duration-300 cyber-input" 
                                       placeholder="请输入用户名" required>
                            </div>
                        </div>
                        
                        <div class="mb-6 animate-fade-in" style="animation-delay: 0.5s;">
                            <label for="email" class="block text-gray-300 font-medium mb-2 cyber-label">邮箱</label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-cyan-500">
                                    <i class="fas fa-envelope"></i>
                                </span>
                                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" 
                                       class="w-full bg-gray-900 border border-cyan-700 rounded-lg px-10 py-3 text-gray-300 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all duration-300 cyber-input" 
                                       placeholder="请输入邮箱" required>
                            </div>
                        </div>
                        
                        <!-- 密码修改 -->
                        <div class="border-t border-gray-800 pt-6 mb-6 animate-fade-in" style="animation-delay: 0.6s;">
                            <h3 class="text-lg font-bold text-cyan-400 mb-4 flex items-center">
                                <i class="fas fa-lock text-cyan-500 mr-2"></i> 修改密码
                            </h3>
                            <p class="text-gray-400 text-sm mb-4">如不需要修改密码，请留空以下字段</p>
                            
                            <div class="mb-6">
                                <label for="current_password" class="block text-gray-300 font-medium mb-2 cyber-label">当前密码</label>
                                <div class="relative">
                                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-cyan-500">
                                        <i class="fas fa-key"></i>
                                    </span>
                                    <input type="password" id="current_password" name="current_password" 
                                           class="w-full bg-gray-900 border border-cyan-700 rounded-lg px-10 py-3 text-gray-300 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all duration-300 cyber-input" 
                                           placeholder="请输入当前密码">
                                    <button type="button" class="absolute inset-y-0 right-0 flex items-center pr-3 text-cyan-500 toggle-password" data-target="current_password">
                                        <i class="fas fa-eye-slash"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="mb-6">
                                <label for="new_password" class="block text-gray-300 font-medium mb-2 cyber-label">新密码</label>
                                <div class="relative">
                                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-cyan-500">
                                        <i class="fas fa-key"></i>
                                    </span>
                                    <input type="password" id="new_password" name="new_password" 
                                           class="w-full bg-gray-900 border border-cyan-700 rounded-lg px-10 py-3 text-gray-300 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all duration-300 cyber-input" 
                                           placeholder="请输入新密码（至少6个字符）">
                                    <button type="button" class="absolute inset-y-0 right-0 flex items-center pr-3 text-cyan-500 toggle-password" data-target="new_password">
                                        <i class="fas fa-eye-slash"></i>
                                    </button>
                                </div>
                                <!-- 密码强度指示器 -->
                                <div id="password-strength-container" class="mt-2 hidden">
                                    <div class="flex gap-1 mb-1">
                                        <div class="strength-bar w-1/4 h-1 bg-gray-700 rounded-full"></div>
                                        <div class="strength-bar w-1/4 h-1 bg-gray-700 rounded-full"></div>
                                        <div class="strength-bar w-1/4 h-1 bg-gray-700 rounded-full"></div>
                                        <div class="strength-bar w-1/4 h-1 bg-gray-700 rounded-full"></div>
                                    </div>
                                    <p id="strength-text" class="text-xs text-gray-500">密码强度: 未输入</p>
                                </div>
                            </div>
                            
                            <div class="mb-6">
                                <label for="confirm_password" class="block text-gray-300 font-medium mb-2 cyber-label">确认新密码</label>
                                <div class="relative">
                                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-cyan-500">
                                        <i class="fas fa-key"></i>
                                    </span>
                                    <input type="password" id="confirm_password" name="confirm_password" 
                                           class="w-full bg-gray-900 border border-cyan-700 rounded-lg px-10 py-3 text-gray-300 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all duration-300 cyber-input" 
                                           placeholder="请再次输入新密码">
                                    <button type="button" class="absolute inset-y-0 right-0 flex items-center pr-3 text-cyan-500 toggle-password" data-target="confirm_password">
                                        <i class="fas fa-eye-slash"></i>
                                    </button>
                                </div>
                                <p id="password-match-text" class="text-xs mt-1 hidden"></p>
                            </div>
                        </div>
                        
                        <div class="flex flex-col sm:flex-row justify-between gap-4 animate-fade-in" style="animation-delay: 0.7s;">
                            <button type="button" class="px-6 py-3 bg-gray-800 border border-cyan-700 rounded-lg text-gray-300 hover:bg-gray-700 transition-all duration-300 cyber-btn" onclick="window.history.back()">
                                <i class="fas fa-times mr-2"></i> 取消
                            </button>
                            <button type="submit" class="px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-bold rounded-lg hover:from-cyan-400 hover:to-blue-500 transition-all duration-300 transform hover:-translate-y-1 shadow-glow-cyan save-profile-btn cyber-btn-primary">
                                <i class="fas fa-save mr-2"></i> 保存更改
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- 侧边栏 -->
            <div class="lg:col-span-4">
                <!-- 账户安全提示 -->
                <div class="cyberpunk-card neon-border-green bg-black bg-opacity-70 rounded-lg p-6 mb-8 shadow-glow-green animate-fade-in" style="animation-delay: 0.8s;">
                    <h3 class="text-xl font-bold text-green-400 mb-4 flex items-center">
                        <i class="fas fa-shield-alt text-green-500 mr-2 pulse-icon"></i> 账户安全
                    </h3>
                    <ul class="space-y-3 text-gray-300">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-green-500 mt-1 mr-2 flex-shrink-0 pulse-icon-slow"></i>
                            <span>请定期更新您的密码以保持账户安全</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-green-500 mt-1 mr-2 flex-shrink-0 pulse-icon-slow"></i>
                            <span>建议使用强密码，包含大小写字母、数字和特殊字符</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-exclamation-circle text-yellow-500 mt-1 mr-2 flex-shrink-0 pulse-icon-slow"></i>
                            <span>不要与他人分享您的账户信息</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-exclamation-circle text-yellow-500 mt-1 mr-2 flex-shrink-0 pulse-icon-slow"></i>
                            <span>请确保您的邮箱地址是有效的，用于找回密码</span>
                        </li>
                    </ul>
                </div>

                <!-- 账户信息 -->
                <div class="cyberpunk-card neon-border-purple bg-black bg-opacity-70 rounded-lg p-6 shadow-glow-purple animate-fade-in" style="animation-delay: 0.9s;">
                    <h3 class="text-xl font-bold text-purple-400 mb-4">账户信息</h3>
                    <div class="space-y-4">
                        <div class="flex justify-between items-center">
                            <span class="text-gray-400">用户ID</span>
                            <span class="text-gray-300">#<?php echo $user['id']; ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-400">注册时间</span>
                            <span class="text-gray-300"><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-400">用户角色</span>
                            <span class="px-2 py-1 bg-purple-900 text-purple-300 text-xs rounded-full border border-purple-700 cyber-badge">
                                <?php echo ucfirst($user['role']); ?>
                            </span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-400">用户积分</span>
                            <span class="text-yellow-500 font-bold cyber-points">
                                <span class="point-count"><?php echo $user['points']; ?></span>
                                <span class="ml-1">pts</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 头像上传表单（隐藏） -->
<form id="avatar-form" action="/user/updateAvatar" method="post" enctype="multipart/form-data" style="display: none;">
    <input type="file" id="avatar-input" name="avatar" accept="image/*" onchange="this.form.submit();">
</form>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 动态背景网格
        const gridOverlay = document.querySelector('.grid-overlay');
        if (gridOverlay) {
            for (let i = 0; i < 20; i++) {
                for (let j = 0; j < 20; j++) {
                    const dot = document.createElement('div');
                    dot.classList.add('grid-dot');
                    dot.style.left = `${i * 5}%`;
                    dot.style.top = `${j * 5}%`;
                    dot.style.animationDelay = `${Math.random() * 5}s`;
                    gridOverlay.appendChild(dot);
                }
            }
        }

        // 扫描线动画
        const scanline = document.querySelector('.scanline');
        if (scanline) {
            scanline.style.animation = 'scanline 6s linear infinite';
        }

        // 密码显示/隐藏切换
        const togglePasswordBtns = document.querySelectorAll('.toggle-password');
        togglePasswordBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target');
                const targetInput = document.getElementById(targetId);
                const icon = this.querySelector('i');
                
                if (targetInput.type === 'password') {
                    targetInput.type = 'text';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                } else {
                    targetInput.type = 'password';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                }
            });
        });

        // 头像上传功能
        const avatarUploadBtn = document.querySelector('.avatar-upload-btn');
        const avatarInput = document.getElementById('avatar-input');
        
        if (avatarUploadBtn && avatarInput) {
            avatarUploadBtn.addEventListener('click', function() {
                avatarInput.click();
            });
        }

        // 密码强度检测
        const newPasswordInput = document.getElementById('new_password');
        const passwordStrengthContainer = document.getElementById('password-strength-container');
        const strengthBars = document.querySelectorAll('.strength-bar');
        const strengthText = document.getElementById('strength-text');
        const confirmPasswordInput = document.getElementById('confirm_password');
        const passwordMatchText = document.getElementById('password-match-text');
        
        if (newPasswordInput && passwordStrengthContainer) {
            newPasswordInput.addEventListener('input', function() {
                const password = this.value;
                
                if (password.length > 0) {
                    passwordStrengthContainer.classList.remove('hidden');
                    
                    // 计算密码强度
                    let strength = 0;
                    
                    // 长度检查
                    if (password.length >= 6) strength++;
                    if (password.length >= 10) strength++;
                    
                    // 复杂度检查
                    if (/[A-Z]/.test(password)) strength++;
                    if (/[0-9]/.test(password)) strength++;
                    if (/[^A-Za-z0-9]/.test(password)) strength++;
                    
                    // 更新强度条
                    for (let i = 0; i < strengthBars.length; i++) {
                        strengthBars[i].className = 'strength-bar w-1/4 h-1 rounded-full';
                        
                        if (i < Math.min(strength, 4)) {
                            if (strength <= 1) strengthBars[i].classList.add('bg-red-500');
                            else if (strength <= 2) strengthBars[i].classList.add('bg-yellow-500');
                            else if (strength <= 3) strengthBars[i].classList.add('bg-green-500');
                            else strengthBars[i].classList.add('bg-cyan-500');
                        } else {
                            strengthBars[i].classList.add('bg-gray-700');
                        }
                    }
                    
                    // 更新强度文本
                    if (strength <= 1) {
                        strengthText.textContent = '密码强度: 弱';
                        strengthText.className = 'text-xs text-red-500';
                    } else if (strength <= 2) {
                        strengthText.textContent = '密码强度: 中';
                        strengthText.className = 'text-xs text-yellow-500';
                    } else if (strength <= 3) {
                        strengthText.textContent = '密码强度: 良好';
                        strengthText.className = 'text-xs text-green-500';
                    } else {
                        strengthText.textContent = '密码强度: 强';
                        strengthText.className = 'text-xs text-cyan-500';
                    }
                } else {
                    passwordStrengthContainer.classList.add('hidden');
                }
                
                // 检查密码匹配
                checkPasswordMatch();
            });
        }
        
        // 密码匹配检查
        if (confirmPasswordInput && passwordMatchText) {
            confirmPasswordInput.addEventListener('input', checkPasswordMatch);
        }
        
        function checkPasswordMatch() {
            const newPassword = newPasswordInput.value;
            const confirmPassword = confirmPasswordInput.value;
            
            if (confirmPassword.length > 0) {
                passwordMatchText.classList.remove('hidden');
                
                if (newPassword === confirmPassword) {
                    passwordMatchText.textContent = '密码匹配';
                    passwordMatchText.className = 'text-xs mt-1 text-green-500';
                } else {
                    passwordMatchText.textContent = '密码不匹配';
                    passwordMatchText.className = 'text-xs mt-1 text-red-500';
                }
            } else {
                passwordMatchText.classList.add('hidden');
            }
        }

        // 添加表单输入焦点效果
        const formInputs = document.querySelectorAll('.cyber-input');
        formInputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('input-focused');
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.classList.remove('input-focused');
            });
        });

        // 添加按钮点击波纹效果
        const cyberBtns = document.querySelectorAll('.cyber-btn, .cyber-btn-primary');
        cyberBtns.forEach(btn => {
            btn.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.classList.add('btn-ripple');
                ripple.style.width = ripple.style.height = `${size}px`;
                ripple.style.left = `${x}px`;
                ripple.style.top = `${y}px`;
                
                this.appendChild(ripple);
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
        });

        // 表单提交验证和动画
        const profileForm = document.querySelector('.edit-profile-form');
        const saveProfileBtn = document.querySelector('.save-profile-btn');
        
        if (profileForm && saveProfileBtn) {
            profileForm.addEventListener('submit', function(e) {
                const username = document.getElementById('username').value.trim();
                const email = document.getElementById('email').value.trim();
                const currentPassword = document.getElementById('current_password').value;
                const newPassword = document.getElementById('new_password').value;
                const confirmPassword = document.getElementById('confirm_password').value;
                
                // 基本验证
                if (!username) {
                    showCyberAlert('请输入用户名');
                    e.preventDefault();
                    return;
                }
                
                if (!email) {
                    showCyberAlert('请输入邮箱');
                    e.preventDefault();
                    return;
                }
                
                // 邮箱格式验证
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email)) {
                    showCyberAlert('请输入有效的邮箱地址');
                    e.preventDefault();
                    return;
                }
                
                // 密码验证
                if ((currentPassword || newPassword || confirmPassword) && 
                    (!currentPassword || !newPassword || !confirmPassword)) {
                    showCyberAlert('修改密码时，请填写所有密码字段');
                    e.preventDefault();
                    return;
                }
                
                if (newPassword && newPassword.length < 6) {
                    showCyberAlert('新密码长度至少为6个字符');
                    e.preventDefault();
                    return;
                }
                
                if (newPassword !== confirmPassword) {
                    showCyberAlert('两次输入的新密码不一致');
                    e.preventDefault();
                    return;
                }
                
                // 提交动画
                saveProfileBtn.disabled = true;
                saveProfileBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> 保存中...';
            });
        }

        // 赛博朋克风格的提示框
        function showCyberAlert(message) {
            // 创建提示框元素
            const alertBox = document.createElement('div');
            alertBox.className = 'cyber-alert fixed top-4 right-4 bg-black border border-red-600 text-red-400 px-4 py-3 rounded-lg shadow-glow-red z-50 animate-slide-in';
            alertBox.innerHTML = `<i class="fas fa-exclamation-triangle mr-2"></i>${message}`;
            
            // 添加到页面
            document.body.appendChild(alertBox);
            
            // 设置移除动画
            setTimeout(() => {
                alertBox.classList.add('animate-slide-out');
                setTimeout(() => {
                    alertBox.remove();
                }, 300);
            }, 3000);
        }

        // 添加标题故障效果
        const glitchTexts = document.querySelectorAll('.glitch-text');
        glitchTexts.forEach(text => {
            // 仅在用户交互时触发故障效果，避免性能问题
            text.addEventListener('mouseenter', function() {
                this.classList.add('glitch-active');
                setTimeout(() => {
                    this.classList.remove('glitch-active');
                }, 1000);
            });
        });

        // 数字滚动动画
        const pointCount = document.querySelector('.point-count');
        if (pointCount) {
            const targetPoints = parseInt(pointCount.textContent);
            let currentPoints = 0;
            const duration = 1500;
            const steps = 60;
            const increment = targetPoints / (duration / (1000 / steps));
            
            const interval = setInterval(() => {
                currentPoints += increment;
                if (currentPoints >= targetPoints) {
                    currentPoints = targetPoints;
                    clearInterval(interval);
                }
                pointCount.textContent = Math.floor(currentPoints);
            }, 1000 / steps);
        }
    });

    // 添加必要的 CSS 动画和样式
    const style = document.createElement('style');
    style.textContent = `
        /* 动态背景样式 */
        .cyberpunk-bg {
            background: radial-gradient(circle at center, #0a0a0a 0%, #000000 100%);
            overflow: hidden;
        }
        
        .grid-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
        }
        
        .grid-dot {
            position: absolute;
            width: 1px;
            height: 1px;
            background-color: rgba(6, 182, 212, 0.4);
            border-radius: 50%;
            opacity: 0;
            animation: pulse-dot 3s infinite;
        }
        
        @keyframes pulse-dot {
            0%, 100% { opacity: 0; }
            50% { opacity: 0.7; }
        }
        
        .scanline {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background-color: rgba(6, 182, 212, 0.3);
            box-shadow: 0 0 8px rgba(6, 182, 212, 0.5);
        }
        
        @keyframes scanline {
            0% { transform: translateY(-100%); }
            100% { transform: translateY(100vh); }
        }
        
        .cyber-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(100px);
            opacity: 0.1;
            z-index: -1;
        }
        
        .blob-1 {
            width: 500px;
            height: 500px;
            background: linear-gradient(135deg, #06b6d4, #3b82f6);
            top: -10%;
            left: -10%;
            animation: blob-move 20s infinite alternate;
        }
        
        .blob-2 {
            width: 400px;
            height: 400px;
            background: linear-gradient(135deg, #ec4899, #8b5cf6);
            bottom: -10%;
            right: -10%;
            animation: blob-move 25s infinite alternate-reverse;
        }
        
        .blob-3 {
            width: 300px;
            height: 300px;
            background: linear-gradient(135deg, #10b981, #3b82f6);
            top: 50%;
            right: 20%;
            animation: blob-move 15s infinite alternate;
        }
        
        @keyframes blob-move {
            0% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(50px, 50px) scale(1.1); }
            100% { transform: translate(-50px, -50px) scale(0.9); }
        }
        
        /* 霓虹边框效果 */
        .neon-border-cyan {
            position: relative;
            border: 1px solid rgba(6, 182, 212, 0.5);
            box-shadow: 0 0 10px rgba(6, 182, 212, 0.3), inset 0 0 10px rgba(6, 182, 212, 0.1);
        }
        
        .neon-border-cyan::before {
            content: '';
            position: absolute;
            top: -1px;
            left: -1px;
            right: -1px;
            bottom: -1px;
            border: 1px solid transparent;
            background: linear-gradient(45deg, #06b6d4, transparent, #06b6d4) border-box;
            border-radius: inherit;
            mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);
            mask-composite: exclude;
            pointer-events: none;
        }
        
        .neon-border-green {
            position: relative;
            border: 1px solid rgba(16, 185, 129, 0.5);
            box-shadow: 0 0 10px rgba(16, 185, 129, 0.3), inset 0 0 10px rgba(16, 185, 129, 0.1);
        }
        
        .neon-border-green::before {
            content: '';
            position: absolute;
            top: -1px;
            left: -1px;
            right: -1px;
            bottom: -1px;
            border: 1px solid transparent;
            background: linear-gradient(45deg, #10b981, transparent, #10b981) border-box;
            border-radius: inherit;
            mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);
            mask-composite: exclude;
            pointer-events: none;
        }
        
        .neon-border-purple {
            position: relative;
            border: 1px solid rgba(139, 92, 246, 0.5);
            box-shadow: 0 0 10px rgba(139, 92, 246, 0.3), inset 0 0 10px rgba(139, 92, 246, 0.1);
        }
        
        .neon-border-purple::before {
            content: '';
            position: absolute;
            top: -1px;
            left: -1px;
            right: -1px;
            bottom: -1px;
            border: 1px solid transparent;
            background: linear-gradient(45deg, #8b5cf6, transparent, #8b5cf6) border-box;
            border-radius: inherit;
            mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);
            mask-composite: exclude;
            pointer-events: none;
        }
        
        /* 卡片悬停效果 */
        .cyberpunk-card {
            transition: all 0.3s ease;
        }
        
        .cyberpunk-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(6, 182, 212, 0.2);
        }
        
        /* 动画效果 */
        .animate-fade-in {
            animation: fadeInUp 0.5s ease forwards;
            opacity: 0;
            transform: translateY(20px);
        }
        
        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* 输入框样式增强 */
        .cyber-input {
            transition: all 0.3s ease;
        }
        
        .cyber-input:focus {
            box-shadow: 0 0 10px rgba(6, 182, 212, 0.5);
            transform: translateY(-1px);
        }
        
        .cyber-input:focus + .toggle-password i {
            color: #22d3ee;
        }
        
        .cyber-label {
            transition: all 0.3s ease;
        }
        
        .cyber-input:focus ~ .cyber-label,
        .cyber-input:not(:placeholder-shown) ~ .cyber-label {
            color: #22d3ee;
            transform: translateY(-2px);
        }
        
        .input-focused {
            box-shadow: 0 0 15px rgba(6, 182, 212, 0.3);
        }
        
        /* 按钮样式增强 */
        .cyber-btn {
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .cyber-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(6, 182, 212, 0.3);
        }
        
        .cyber-btn-primary {
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .cyber-btn-primary:hover {
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 8px 25px rgba(6, 182, 212, 0.4);
        }
        
        /* 按钮点击波纹效果 */
        .btn-ripple {
            position: absolute;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.3);
            transform: scale(0);
            animation: ripple-animation 0.6s ease-out;
            pointer-events: none;
        }
        
        @keyframes ripple-animation {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        /* 徽章样式 */
        .cyber-badge {
            transition: all 0.3s ease;
        }
        
        .cyber-badge:hover {
            background-color: rgba(139, 92, 246, 0.4);
            box-shadow: 0 0 10px rgba(139, 92, 246, 0.5);
        }
        
        /* 提示框样式 */
        .cyber-alert {
            animation: slideInRight 0.3s ease-out;
        }
        
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        .animate-slide-out {
            animation: slideOutRight 0.3s ease-in;
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
        
        /* 故障文字效果 */
        .glitch-text {
            position: relative;
            display: inline-block;
        }
        
        .glitch-text.glitch-active {
            animation: glitch 1s infinite;
        }
        
        .glitch-text.glitch-active::before,
        .glitch-text.glitch-active::after {
            content: attr(data-text);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }
        
        .glitch-text.glitch-active::before {
            left: 2px;
            text-shadow: -1px 0 #ff00ff;
            animation: glitch-anim 0.5s infinite;
            clip: rect(44px, 450px, 56px, 0);
        }
        
        .glitch-text.glitch-active::after {
            left: -2px;
            text-shadow: 1px 0 #00ffff;
            animation: glitch-anim 0.5s infinite reverse;
            clip: rect(44px, 450px, 56px, 0);
        }
        
        @keyframes glitch {
            0% { transform: translate(0); }
            20% { transform: translate(-2px, 2px); }
            40% { transform: translate(-2px, -2px); }
            60% { transform: translate(2px, 2px); }
            80% { transform: translate(2px, -2px); }
            100% { transform: translate(0); }
        }
        
        @keyframes glitch-anim {
            0% { clip: rect(24px, 9999px, 30px, 0); }
            20% { clip: rect(8px, 9999px, 15px, 0); }
            40% { clip: rect(35px, 9999px, 42px, 0); }
            60% { clip: rect(12px, 9999px, 20px, 0); }
            80% { clip: rect(28px, 9999px, 36px, 0); }
            100% { clip: rect(24px, 9999px, 30px, 0); }
        }
        
        /* 图标脉动效果 */
        .pulse-icon {
            animation: pulse 2s infinite;
        }
        
        .pulse-icon-slow {
            animation: pulse 3s infinite;
        }
        
        @keyframes pulse {
            0% { opacity: 0.6; transform: scale(1); }
            50% { opacity: 1; transform: scale(1.1); }
            100% { opacity: 0.6; transform: scale(1); }
        }
        
        /* 积分显示效果 */
        .cyber-points {
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
        }
        
        .cyber-points:hover {
            transform: scale(1.1);
            text-shadow: 0 0 10px rgba(234, 179, 8, 0.8);
        }
    `;
    document.head.appendChild(style);
</script>

<?php include ROOT_PATH . '/app/views/layouts/footer.php'; ?>