<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $user['username']; ?>的个人资料 - 赛博朋克论坛</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        neon: {
                            blue: '#00f3ff',
                            pink: '#ff2a6d',
                            green: '#01f9c6',
                            purple: '#d000ff'
                        },
                        dark: '#0a0a0f',
                        darker: '#050508'
                    },
                    fontFamily: {
                        cyber: ['Rajdhani', 'sans-serif']
                    },
                    animation: {
                        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                        'glitch': 'glitch 1s infinite',
                        'scan': 'scan 6s linear infinite',
                        'float': 'float 6s ease-in-out infinite'
                    },
                    keyframes: {
                        glitch: {
                            '0%, 100%': { transform: 'translate(0)' },
                            '20%': { transform: 'translate(-2px, 2px)' },
                            '40%': { transform: 'translate(-2px, -2px)' },
                            '60%': { transform: 'translate(2px, 2px)' },
                            '80%': { transform: 'translate(2px, -2px)' }
                        },
                        scan: {
                            '0%': { top: '-100%' },
                            '100%': { top: '100%' }
                        },
                        float: {
                            '0%, 100%': { transform: 'translateY(0)' },
                            '50%': { transform: 'translateY(-10px)' }
                        }
                    }
                }
            }
        }
    </script>
    <style type="text/tailwindcss">
        @layer utilities {
            .content-auto { content-visibility: auto; }
            .text-shadow { text-shadow: 0 0 8px rgba(0, 243, 255, 0.7); }
            .text-shadow-pink { text-shadow: 0 0 8px rgba(255, 42, 109, 0.7); }
            .text-shadow-green { text-shadow: 0 0 8px rgba(1, 249, 198, 0.7); }
            .neon-border { position: relative; border: 1px solid rgba(0, 243, 255, 0.3); box-shadow: 0 0 15px rgba(0, 243, 255, 0.2); }
            .neon-border::before { content: ''; position: absolute; top: -1px; left: -1px; right: -1px; bottom: -1px; background: linear-gradient(45deg, #00f3ff, #ff2a6d, #01f9c6, #d000ff); z-index: -1; margin: -2px; opacity: 0; transition: opacity 0.3s; }
            .neon-border:hover::before { opacity: 1; }
            .neon-border-pink { position: relative; border: 1px solid rgba(255, 42, 109, 0.3); box-shadow: 0 0 15px rgba(255, 42, 109, 0.2); }
            .neon-border-pink::before { content: ''; position: absolute; top: -1px; left: -1px; right: -1px; bottom: -1px; background: linear-gradient(45deg, #ff2a6d, #00f3ff, #d000ff, #01f9c6); z-index: -1; margin: -2px; opacity: 0; transition: opacity 0.3s; }
            .neon-border-pink:hover::before { opacity: 1; }
            .neon-border-green { position: relative; border: 1px solid rgba(1, 249, 198, 0.3); box-shadow: 0 0 15px rgba(1, 249, 198, 0.2); }
            .neon-border-green::before { content: ''; position: absolute; top: -1px; left: -1px; right: -1px; bottom: -1px; background: linear-gradient(45deg, #01f9c6, #d000ff, #00f3ff, #ff2a6d); z-index: -1; margin: -2px; opacity: 0; transition: opacity 0.3s; }
            .neon-border-green:hover::before { opacity: 1; }
            .scanline { position: fixed; top: 0; left: 0; width: 100%; height: 4px; background: rgba(255, 255, 255, 0.1); z-index: 50; animation: scan 6s linear infinite; pointer-events: none; }
            .grid-bg { background-size: 40px 40px; background-image: linear-gradient(to right, rgba(0, 243, 255, 0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(0, 243, 255, 0.05) 1px, transparent 1px); }
            .animate-fade-in { animation: fadeInUp 1s ease-out forwards; opacity: 0; transform: translateY(20px); }
            @keyframes fadeInUp {
                to { opacity: 1; transform: translateY(0); }
            }
        }
    </style>
</head>
<body class="bg-dark text-white min-h-screen grid-bg">
    <!-- 动态背景装饰 -->
    <div class="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <!-- 动态网格背景 -->
        <div id="dynamicGrid" class="absolute inset-0 opacity-20"></div>
        
        <!-- 装饰性元素 -->
        <div class="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-neon-pink/10 blur-3xl animate-pulse-slow"></div>
        <div class="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-neon-blue/10 blur-3xl animate-pulse-slow" style="animation-delay: 1s;"></div>
        <div class="absolute top-3/4 left-1/3 w-48 h-48 rounded-full bg-neon-green/10 blur-3xl animate-pulse-slow" style="animation-delay: 2s;"></div>
        
        <!-- 装饰性网格线 -->
        <div class="absolute inset-0" style="background-image: radial-gradient(circle, rgba(0, 243, 255, 0.1) 1px, transparent 1px); background-size: 30px 30px;"></div>
    </div>
    
    <!-- 扫描线效果 -->
    <div class="scanline"></div>
    
    <!-- 页面内容 -->
    <div class="relative z-10">
        <!-- 顶部导航（已加载） -->
        <?php include_once __DIR__ . '/../layouts/header.php'; ?>
        
        <!-- 主要内容区域 -->
        <main class="container mx-auto px-4 py-8">
            <!-- 面包屑导航 -->
            <nav class="flex text-sm mb-6 animate-fade-in">
                <a href="/" class="text-gray-500 hover:text-neon-blue transition-colors">首页</a>
                <span class="mx-2 text-gray-600">/</span>
                <span class="text-neon-blue">个人资料</span>
            </nav>
            
            <!-- 用户资料头部 -->
            <section class="relative mb-8 rounded-xl overflow-hidden bg-darker/70 backdrop-blur-sm neon-border animate-fade-in" style="animation-delay: 0.1s;">
                <!-- 背景横幅 -->
                <div class="h-40 w-full bg-gradient-to-r from-neon-blue/20 to-neon-purple/20 relative overflow-hidden">
                    <div class="absolute inset-0" style="background-image: url('data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%2300f3ff' fill-opacity='0.1' fill-rule='evenodd'/%3E%3C/svg%3E');
                </div>
                
                <!-- 头像区域 -->
                <div class="relative -mt-16 mb-6 flex flex-wrap items-center">
                    <div class="ml-6 lg:ml-10 p-1 bg-dark border-2 border-neon-blue rounded-full shadow-lg shadow-neon-blue/20 animate-float">
                        <img src="https://picsum.photos/id/<?php echo $user['id']; ?>/200" alt="<?php echo $user['username']; ?>的头像" class="w-32 h-32 object-cover rounded-full">
                    </div>
                    
                    <!-- 用户基本信息 -->
                    <div class="ml-6 mt-2 flex-1 min-w-[300px]">
                        <div class="flex flex-wrap items-center gap-3 mb-2">
                            <h1 class="text-2xl lg:text-3xl font-bold text-white flex items-center">
                                <span class="mr-2 glitch-text"><?php echo $user['username']; ?></span>
                                <span class="inline-block text-xs px-2 py-0.5 bg-neon-blue/20 text-neon-blue rounded-md border border-neon-blue/30">V2.0</span>
                            </h1>
                            <?php if ($current_user && $current_user['id'] === $user['id']): ?>
                                <a href="/auth/edit_profile" class="text-sm px-4 py-1.5 bg-dark border border-neon-green rounded-md text-neon-green hover:bg-neon-green/10 transition-colors flex items-center">
                                    <i class="fa fa-pen mr-1"></i> 编辑资料
                                </a>
                            <?php endif; ?>
                        </div>
                        <p class="text-gray-400 text-sm mb-2">
                            <i class="fa fa-id-card text-neon-pink mr-1"></i>
                            <span data-user-id="<?php echo $user['id']; ?>" class="text-neon-pink cursor-pointer hover:underline">ID: <?php echo $user['id']; ?></span>
                        </p>
                        <p class="text-gray-400 text-sm">
                            <i class="fa fa-calendar-alt text-neon-green mr-1"></i>
                            加入时间: <?php echo date('Y年m月d日', strtotime($user['created_at'])); ?>
                        </p>
                    </div>
                </div>
                
                <!-- 用户统计数据 -->
                <div class="bg-dark/50 backdrop-blur-sm border-t border-gray-800">
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 text-center">
                        <div class="animate-fade-in" style="animation-delay: 0.2s;">
                            <p class="text-2xl font-bold text-neon-blue counter"><?php echo number_format($user['thread_count']); ?></p>
                            <p class="text-gray-500 text-sm">发表主题</p>
                        </div>
                        <div class="animate-fade-in" style="animation-delay: 0.3s;">
                            <p class="text-2xl font-bold text-neon-pink counter"><?php echo number_format($user['reply_count']); ?></p>
                            <p class="text-gray-500 text-sm">回复数量</p>
                        </div>
                        <div class="animate-fade-in" style="animation-delay: 0.4s;">
                            <p class="text-2xl font-bold text-neon-green counter"><?php echo number_format($user['reputation']); ?></p>
                            <p class="text-gray-500 text-sm">声誉值</p>
                        </div>
                        <div class="animate-fade-in" style="animation-delay: 0.5s;">
                            <p class="text-2xl font-bold text-neon-purple counter"><?php echo number_format($user['view_count']); ?></p>
                            <p class="text-gray-500 text-sm">资料访问</p>
                        </div>
                    </div>
                </div>
            </section>
            
            <!-- 内容网格布局 -->
            <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
                <!-- 左侧信息区域 -->
                <div class="lg:col-span-1 space-y-8">
                    <!-- 个人信息卡片 -->
                    <div class="cyberpunk-card bg-dark/70 backdrop-blur-sm p-6 rounded-lg neon-border animate-fade-in" style="animation-delay: 0.6s;">
                        <h2 class="text-lg font-bold text-white mb-4 flex items-center border-b border-gray-800 pb-2">
                            <i class="fa fa-user-circle text-neon-blue mr-2"></i>个人信息
                        </h2>
                        
                        <div class="space-y-4">
                            <div>
                                <p class="text-gray-500 text-xs mb-1">个人简介</p>
                                <p class="text-gray-300">
                                    <?php echo $user['bio'] ? $user['bio'] : '这个人很懒，还没有填写个人简介'; ?>
                                </p>
                            </div>
                            
                            <div>
                                <p class="text-gray-500 text-xs mb-1">电子邮箱</p>
                                <p class="text-neon-blue hover:underline cursor-pointer flex items-center">
                                    <i class="fa fa-envelope mr-1"></i>
                                    <?php echo $user['email']; ?>
                                </p>
                            </div>
                            
                            <div>
                                <p class="text-gray-500 text-xs mb-1">所在地区</p>
                                <p class="text-gray-300 flex items-center">
                                    <i class="fa fa-map-marker-alt text-neon-pink mr-1"></i>
                                    <?php echo $user['location'] ? $user['location'] : '未知'; ?>
                                </p>
                            </div>
                            
                            <div>
                                <p class="text-gray-500 text-xs mb-1">最后活跃</p>
                                <p class="text-gray-300 flex items-center">
                                    <i class="fa fa-clock text-neon-green mr-1"></i>
                                    <?php echo date('Y-m-d H:i', strtotime($user['last_active'])); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 社交链接 -->
                    <div class="cyberpunk-card bg-dark/70 backdrop-blur-sm p-6 rounded-lg neon-border-pink animate-fade-in" style="animation-delay: 0.7s;">
                        <h2 class="text-lg font-bold text-white mb-4 flex items-center border-b border-gray-800 pb-2">
                            <i class="fa fa-link text-neon-pink mr-2"></i>社交链接
                        </h2>
                        
                        <div class="grid grid-cols-2 gap-3">
                            <a href="#" class="flex items-center gap-2 px-3 py-2 bg-dark border border-gray-800 rounded-md hover:border-neon-blue hover:text-neon-blue transition-colors">
                                <i class="fab fa-github"></i>
                                <span class="text-sm">GitHub</span>
                            </a>
                            <a href="#" class="flex items-center gap-2 px-3 py-2 bg-dark border border-gray-800 rounded-md hover:border-neon-blue hover:text-neon-blue transition-colors">
                                <i class="fab fa-twitter"></i>
                                <span class="text-sm">Twitter</span>
                            </a>
                            <a href="#" class="flex items-center gap-2 px-3 py-2 bg-dark border border-gray-800 rounded-md hover:border-neon-blue hover:text-neon-blue transition-colors">
                                <i class="fab fa-linkedin"></i>
                                <span class="text-sm">LinkedIn</span>
                            </a>
                            <a href="#" class="flex items-center gap-2 px-3 py-2 bg-dark border border-gray-800 rounded-md hover:border-neon-blue hover:text-neon-blue transition-colors">
                                <i class="fab fa-weibo"></i>
                                <span class="text-sm">微博</span>
                            </a>
                        </div>
                    </div>
                    
                    <!-- 技能标签 -->
                    <div class="cyberpunk-card bg-dark/70 backdrop-blur-sm p-6 rounded-lg neon-border-green animate-fade-in" style="animation-delay: 0.8s;">
                        <h2 class="text-lg font-bold text-white mb-4 flex items-center border-b border-gray-800 pb-2">
                            <i class="fa fa-code text-neon-green mr-2"></i>技术栈
                        </h2>
                        
                        <div class="space-y-3">
                            <div>
                                <div class="flex justify-between text-xs mb-1">
                                    <span class="text-gray-300">PHP</span>
                                    <span class="text-neon-blue">85%</span>
                                </div>
                                <div class="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
                                    <div class="progress-bar h-full bg-gradient-to-r from-neon-blue to-neon-purple" data-width="85%"></div>
                                </div>
                            </div>
                            
                            <div>
                                <div class="flex justify-between text-xs mb-1">
                                    <span class="text-gray-300">JavaScript</span>
                                    <span class="text-neon-pink">78%</span>
                                </div>
                                <div class="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
                                    <div class="progress-bar h-full bg-gradient-to-r from-neon-pink to-neon-blue" data-width="78%"></div>
                                </div>
                            </div>
                            
                            <div>
                                <div class="flex justify-between text-xs mb-1">
                                    <span class="text-gray-300">HTML/CSS</span>
                                    <span class="text-neon-green">92%</span>
                                </div>
                                <div class="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
                                    <div class="progress-bar h-full bg-gradient-to-r from-neon-green to-neon-pink" data-width="92%"></div>
                                </div>
                            </div>
                            
                            <div>
                                <div class="flex justify-between text-xs mb-1">
                                    <span class="text-gray-300">MySQL</span>
                                    <span class="text-neon-purple">80%</span>
                                </div>
                                <div class="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
                                    <div class="progress-bar h-full bg-gradient-to-r from-neon-purple to-neon-green" data-width="80%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 标签云 -->
                    <div class="cyberpunk-card bg-dark/70 backdrop-blur-sm p-6 rounded-lg neon-border animate-fade-in" style="animation-delay: 0.9s;">
                        <h2 class="text-lg font-bold text-white mb-4 flex items-center border-b border-gray-800 pb-2">
                            <i class="fa fa-tags text-neon-green mr-2"></i>兴趣标签
                        </h2>
                        <div class="flex flex-wrap gap-2">
                            <a href="#" class="px-3 py-1 bg-dark border border-neon-blue/30 rounded-md text-neon-blue text-xs hover:bg-neon-blue/10 transition-colors hover:shadow-lg hover:shadow-neon-blue/20">PHP</a>
                            <a href="#" class="px-3 py-1 bg-dark border border-neon-pink/30 rounded-md text-neon-pink text-xs hover:bg-neon-pink/10 transition-colors hover:shadow-lg hover:shadow-neon-pink/20">JavaScript</a>
                            <a href="#" class="px-3 py-1 bg-dark border border-neon-green/30 rounded-md text-neon-green text-xs hover:bg-neon-green/10 transition-colors hover:shadow-lg hover:shadow-neon-green/20">赛博朋克</a>
                            <a href="#" class="px-3 py-1 bg-dark border border-neon-purple/30 rounded-md text-neon-purple text-xs hover:bg-neon-purple/10 transition-colors hover:shadow-lg hover:shadow-neon-purple/20">游戏</a>
                            <a href="#" class="px-3 py-1 bg-dark border border-cyan-500/30 rounded-md text-cyan-500 text-xs hover:bg-cyan-500/10 transition-colors hover:shadow-lg hover:shadow-cyan-500/20">UI设计</a>
                            <a href="#" class="px-3 py-1 bg-dark border border-pink-500/30 rounded-md text-pink-500 text-xs hover:bg-pink-500/10 transition-colors hover:shadow-lg hover:shadow-pink-500/20">音乐</a>
                            <a href="#" class="px-3 py-1 bg-dark border border-yellow-500/30 rounded-md text-yellow-500 text-xs hover:bg-yellow-500/10 transition-colors hover:shadow-lg hover:shadow-yellow-500/20">电影</a>
                        </div>
                    </div>
                </div>
                
                <!-- 右侧内容区域 -->
                <div class="lg:col-span-3 space-y-8">
                    <!-- 用户主题列表 -->
                    <div class="cyberpunk-card bg-dark/70 backdrop-blur-sm p-6 rounded-lg neon-border-blue animate-fade-in" style="animation-delay: 1.0s;">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-lg font-bold text-white border-l-4 border-neon-blue pl-3">
                                <i class="fa fa-comments text-neon-blue mr-2"></i>发表的主题
                            </h2>
                            <a href="/user/<?php echo $user['id']; ?>/threads" class="text-neon-blue hover:text-white transition-colors text-sm group inline-flex items-center">
                                查看全部 
                                <i class="fa fa-angle-right ml-1 group-hover:ml-2 transition-all"></i>
                            </a>
                        </div>
                        
                        <!-- 主题列表 -->
                        <div class="space-y-4">
                            <!-- 主题项目 -->
                            <div class="border-b border-gray-800 pb-4 hover:border-neon-blue/30 transition-all animate-fadeInUp">
                                <div class="flex items-start gap-4 group cursor-pointer">
                                    <div class="w-10 h-10 rounded bg-neon-blue/20 flex items-center justify-center flex-shrink-0 group-hover:bg-neon-blue/30 transition-colors">
                                        <i class="fa fa-code text-neon-blue"></i>
                                    </div>
                                    <div class="flex-1">
                                        <h3 class="font-bold text-white hover:text-neon-blue transition-colors mb-1">
                                            <a href="/thread/1" class="hover:underline">PHP 8.0 新特性详解</a>
                                        </h3>
                                        <div class="flex flex-wrap items-center text-xs text-gray-500 gap-3 mb-2">
                                            <span class="px-2 py-0.5 rounded bg-neon-blue/10 text-neon-blue border border-neon-blue/30">技术讨论</span>
                                            <span><i class="fa fa-clock-o mr-1"></i>2小时前</span>
                                            <span><i class="fa fa-eye mr-1"></i>2456 次浏览</span>
                                            <span><i class="fa fa-reply mr-1"></i>128 条回复</span>
                                        </div>
                                        <p class="text-gray-400 text-sm line-clamp-2">
                                            PHP 8.0 带来了许多令人兴奋的新特性，包括命名参数、联合类型、注解、构造器属性提升等。本文将详细介绍这些新特性及其用法...
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="border-b border-gray-800 pb-4 hover:border-neon-pink/30 transition-all animate-fadeInUp" style="animation-delay: 0.1s">
                                <div class="flex items-start gap-4 group cursor-pointer">
                                    <div class="w-10 h-10 rounded bg-neon-pink/20 flex items-center justify-center flex-shrink-0 group-hover:bg-neon-pink/30 transition-colors">
                                        <i class="fa fa-gamepad text-neon-pink"></i>
                                    </div>
                                    <div class="flex-1">
                                        <h3 class="font-bold text-white hover:text-neon-blue transition-colors mb-1">
                                            <a href="/thread/2" class="hover:underline">赛博朋克2077最新更新内容</a>
                                        </h3>
                                        <div class="flex flex-wrap items-center text-xs text-gray-500 gap-3 mb-2">
                                            <span class="px-2 py-0.5 rounded bg-neon-pink/10 text-neon-pink border border-neon-pink/30">游戏世界</span>
                                            <span><i class="fa fa-clock-o mr-1"></i>4小时前</span>
                                            <span><i class="fa fa-eye mr-1"></i>3241 次浏览</span>
                                            <span><i class="fa fa-reply mr-1"></i>235 条回复</span>
                                        </div>
                                        <p class="text-gray-400 text-sm line-clamp-2">
                                            CD Projekt Red 发布了赛博朋克2077的最新更新，修复了大量bug并添加了新内容。本文将详细介绍此次更新的主要内容和游戏体验改进...
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="border-b border-gray-800 pb-4 hover:border-neon-green/30 transition-all animate-fadeInUp" style="animation-delay: 0.2s">
                                <div class="flex items-start gap-4 group cursor-pointer">
                                    <div class="w-10 h-10 rounded bg-neon-green/20 flex items-center justify-center flex-shrink-0 group-hover:bg-neon-green/30 transition-colors">
                                        <i class="fa fa-paint-brush text-neon-green"></i>
                                    </div>
                                    <div class="flex-1">
                                        <h3 class="font-bold text-white hover:text-neon-blue transition-colors mb-1">
                                            <a href="/thread/3" class="hover:underline">如何创建赛博朋克风格的UI设计</a>
                                        </h3>
                                        <div class="flex flex-wrap items-center text-xs text-gray-500 gap-3 mb-2">
                                            <span class="px-2 py-0.5 rounded bg-neon-green/10 text-neon-green border border-neon-green/30">创意设计</span>
                                            <span><i class="fa fa-clock-o mr-1"></i>昨天</span>
                                            <span><i class="fa fa-eye mr-1"></i>1567 次浏览</span>
                                            <span><i class="fa fa-reply mr-1"></i>89 条回复</span>
                                        </div>
                                        <p class="text-gray-400 text-sm line-clamp-2">
                                            赛博朋克风格的UI设计近年来越来越受欢迎，本文将分享一些创建赛博朋克风格UI的技巧和灵感，包括色彩搭配、字体选择、元素设计等...
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 最近回复 -->
                    <div class="cyberpunk-card bg-dark/70 backdrop-blur-sm p-6 rounded-lg neon-border-pink animate-fade-in" style="animation-delay: 1.1s;">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-lg font-bold text-white border-l-4 border-neon-pink pl-3">
                                <i class="fa fa-reply text-neon-pink mr-2"></i>最近回复
                            </h2>
                            <a href="/user/<?php echo $user['id']; ?>/replies" class="text-neon-pink hover:text-white transition-colors text-sm group inline-flex items-center">
                                查看全部 
                                <i class="fa fa-angle-right ml-1 group-hover:ml-2 transition-all"></i>
                            </a>
                        </div>
                        
                        <!-- 回复列表 -->
                        <div class="space-y-6">
                            <!-- 回复项目 -->
                            <div class="bg-dark/50 rounded-lg p-4 border border-gray-800 hover:border-neon-pink/50 transition-all animate-fadeInUp transform hover:-translate-y-1">
                                <div class="flex items-center justify-between mb-2">
                                    <h3 class="text-sm font-medium text-white">
                                        <a href="/thread/1" class="hover:text-neon-blue transition-colors">
                                            回复了: PHP 8.0 新特性详解
                                        </a>
                                    </h3>
                                    <span class="text-xs text-gray-500">1小时前</span>
                                </div>
                                <p class="text-gray-400 text-sm mb-3 border-l-2 border-neon-pink pl-3">
                                    非常详细的总结！命名参数确实是一个很棒的特性，让代码更加可读和易于维护。我已经在我的项目中开始使用了。
                                </p>
                                <div class="flex items-center gap-3 text-xs text-gray-500">
                                    <span class="text-neon-blue px-2 py-0.5 rounded bg-neon-blue/10 border border-neon-blue/30">技术讨论</span>
                                    <span><i class="fa fa-eye mr-1"></i>2456</span>
                                    <a href="/thread/1#reply-10" class="text-neon-pink hover:text-white transition-colors flex items-center group">
                                        查看回复 <i class="fa fa-external-link ml-1 group-hover:ml-2 transition-all"></i>
                                    </a>
                                </div>
                            </div>
                            
                            <div class="bg-dark/50 rounded-lg p-4 border border-gray-800 hover:border-neon-blue/50 transition-all animate-fadeInUp transform hover:-translate-y-1" style="animation-delay: 0.1s">
                                <div class="flex items-center justify-between mb-2">
                                    <h3 class="text-sm font-medium text-white">
                                        <a href="/thread/2" class="hover:text-neon-blue transition-colors">
                                            回复了: 赛博朋克2077最新更新内容
                                        </a>
                                    </h3>
                                    <span class="text-xs text-gray-500">3小时前</span>
                                </div>
                                <p class="text-gray-400 text-sm mb-3 border-l-2 border-neon-blue pl-3">
                                    游戏性能确实有很大提升，尤其是在光追模式下。不过我还是遇到了一些小bug，希望后续更新能够解决。
                                </p>
                                <div class="flex items-center gap-3 text-xs text-gray-500">
                                    <span class="text-neon-pink px-2 py-0.5 rounded bg-neon-pink/10 border border-neon-pink/30">游戏世界</span>
                                    <span><i class="fa fa-eye mr-1"></i>3241</span>
                                    <a href="/thread/2#reply-56" class="text-neon-pink hover:text-white transition-colors flex items-center group">
                                        查看回复 <i class="fa fa-external-link ml-1 group-hover:ml-2 transition-all"></i>
                                    </a>
                                </div>
                            </div>
                            
                            <!-- 动态时间线 -->
                            <div class="mt-8 pt-6 border-t border-gray-800 animate-fade-in" style="animation-delay: 1.2s;">
                                <h3 class="text-md font-bold text-white mb-4 flex items-center">
                                    <i class="fa fa-history text-neon-green mr-2"></i>最近活动
                                </h3>
                                <div class="space-y-4">
                                    <div class="flex gap-3 items-start animate-fadeInUp">
                                        <div class="w-8 h-8 rounded-full bg-neon-green/20 flex items-center justify-center flex-shrink-0 mt-1 pulse-icon">
                                            <i class="fa fa-comment text-neon-green text-xs"></i>
                                        </div>
                                        <div>
                                            <p class="text-gray-300 text-sm">
                                                <span class="text-neon-green font-medium">发表了回复</span> 在 <a href="/thread/4" class="text-neon-blue hover:underline">CSS Grid 布局完全指南</a>
                                            </p>
                                            <p class="text-gray-500 text-xs mt-1">15分钟前</p>
                                        </div>
                                    </div>
                                    <div class="flex gap-3 items-start animate-fadeInUp" style="animation-delay: 0.1s">
                                        <div class="w-8 h-8 rounded-full bg-neon-purple/20 flex items-center justify-center flex-shrink-0 mt-1 pulse-icon">
                                            <i class="fa fa-star text-neon-purple text-xs"></i>
                                        </div>
                                        <div>
                                            <p class="text-gray-300 text-sm">
                                                <span class="text-neon-purple font-medium">点赞了话题</span> <a href="/thread/5" class="text-neon-blue hover:underline">Web3.0时代的前端开发</a>
                                            </p>
                                            <p class="text-gray-500 text-xs mt-1">1小时前</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        
        <!-- 页脚（已加载） -->
        <?php include_once __DIR__ . '/../layouts/footer.php'; ?>
    </div>
    
    <!-- JavaScript交互 -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 动态背景网格
            const dynamicGrid = document.getElementById('dynamicGrid');
            for (let i = 0; i < 50; i++) {
                const line = document.createElement('div');
                line.className = 'absolute bg-neon-blue/5';
                
                // 随机生成水平线或垂直线
                if (Math.random() > 0.5) {
                    line.style.height = '1px';
                    line.style.width = `${Math.random() * 30 + 10}%`;
                    line.style.top = `${Math.random() * 100}%`;
                    line.style.left = `${Math.random() * 100}%`;
                } else {
                    line.style.width = '1px';
                    line.style.height = `${Math.random() * 30 + 10}%`;
                    line.style.left = `${Math.random() * 100}%`;
                    line.style.top = `${Math.random() * 100}%`;
                }
                
                dynamicGrid.appendChild(line);
                
                // 添加闪烁动画
                setTimeout(() => {
                    line.style.opacity = Math.random() * 0.5 + 0.1;
                    setInterval(() => {
                        line.style.opacity = Math.random() * 0.5 + 0.1;
                        line.style.transition = 'opacity 1s ease';
                    }, Math.random() * 3000 + 2000);
                }, Math.random() * 2000);
            }
            
            // 标题故障效果
            const glitchTexts = document.querySelectorAll('.glitch-text');
            glitchTexts.forEach(text => {
                text.addEventListener('mouseover', () => {
                    text.classList.add('animate-glitch');
                });
                text.addEventListener('mouseout', () => {
                    text.classList.remove('animate-glitch');
                });
            });
            
            // 滚动渐入效果
            const fadeElements = document.querySelectorAll('.animate-fadeInUp');
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('opacity-100', 'translate-y-0');
                        entry.target.classList.remove('opacity-0', 'translate-y-4');
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.1
            });
            
            fadeElements.forEach(el => {
                el.classList.add('opacity-0', 'translate-y-4', 'transition-all', 'duration-700');
                observer.observe(el);
            });
            
            // 进度条动画
            const progressBars = document.querySelectorAll('.progress-bar');
            
            const progressObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const width = entry.target.getAttribute('data-width');
                        entry.target.style.width = '0';
                        setTimeout(() => {
                            entry.target.style.transition = 'width 1s ease-out';
                            entry.target.style.width = width;
                        }, 100);
                        progressObserver.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.1
            });
            
            progressBars.forEach(bar => {
                progressObserver.observe(bar);
            });
            
            // 数字计数器动画
            const counters = document.querySelectorAll('.counter');
            
            const counterObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const target = parseInt(entry.target.innerText.replace(/,/g, ''));
                        let count = 0;
                        const duration = 2000; // 2秒
                        const step = target / (duration / 16); // 60fps
                        
                        const updateCounter = () => {
                            count += step;
                            if (count < target) {
                                entry.target.innerText = Math.floor(count).toLocaleString();
                                requestAnimationFrame(updateCounter);
                            } else {
                                entry.target.innerText = target.toLocaleString();
                            }
                        };
                        
                        updateCounter();
                        counterObserver.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.1
            });
            
            counters.forEach(counter => {
                counterObserver.observe(counter);
            });
            
            // 卡片悬停效果增强
            const cards = document.querySelectorAll('.cyberpunk-card');
            cards.forEach(card => {
                card.addEventListener('mouseenter', () => {
                    card.style.boxShadow = '0 0 20px rgba(6, 182, 212, 0.3)';
                    card.style.transform = 'translateY(-3px)';
                    card.style.transition = 'all 0.3s ease';
                });
                
                card.addEventListener('mouseleave', () => {
                    card.style.boxShadow = 'none';
                    card.style.transform = 'translateY(0)';
                });
            });
            
            // 用户ID复制功能
            const userIdElements = document.querySelectorAll('[data-user-id]');
            userIdElements.forEach(el => {
                el.style.cursor = 'pointer';
                el.addEventListener('click', () => {
                    const userId = el.getAttribute('data-user-id');
                    navigator.clipboard.writeText(userId).then(() => {
                        const originalText = el.innerText;
                        el.innerText = '已复制!';
                        el.classList.add('text-neon-green');
                        setTimeout(() => {
                            el.innerText = originalText;
                            el.classList.remove('text-neon-green');
                        }, 2000);
                    });
                });
            });
            
            // 图标脉动效果
            const pulseIcons = document.querySelectorAll('.pulse-icon');
            pulseIcons.forEach(icon => {
                setInterval(() => {
                    icon.style.boxShadow = '0 0 0 0 rgba(1, 249, 198, 0.7)';
                    setTimeout(() => {
                        icon.style.boxShadow = '0 0 0 8px rgba(1, 249, 198, 0)';
                    }, 100);
                }, Math.random() * 3000 + 2000);
            });
            
            // 按钮点击波纹效果
            const buttons = document.querySelectorAll('a, button');
            buttons.forEach(button => {
                button.addEventListener('click', function(e) {
                    const isLink = this.tagName === 'A';
                    const isInternal = isLink && (this.getAttribute('href').startsWith('#') || this.getAttribute('href') === 'javascript:void(0)');
                    
                    if (isInternal || !isLink) {
                        e.preventDefault();
                    }
                    
                    const circle = document.createElement('span');
                    const diameter = Math.max(button.clientWidth, button.clientHeight);
                    const radius = diameter / 2;
                    
                    circle.style.width = circle.style.height = `${diameter}px`;
                    circle.style.left = `${e.clientX - button.getBoundingClientRect().left - radius}px`;
                    circle.style.top = `${e.clientY - button.getBoundingClientRect().top - radius}px`;
                    circle.classList.add('ripple');
                    
                    const ripple = button.getElementsByClassName('ripple')[0];
                    if (ripple) {
                        ripple.remove();
                    }
                    
                    button.appendChild(circle);
                    
                    setTimeout(() => {
                        circle.remove();
                    }, 600);
                });
            });
        });
    </script>
    
    <style>
        /* 波纹效果样式 */
        .ripple {
            position: absolute;
            border-radius: 50%;
            background-color: rgba(0, 243, 255, 0.5);
            transform: scale(0);
            animation: ripple 0.6s linear;
            pointer-events: none;
        }
        
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        /* 卡片悬停效果 */
        .neon-border,
        .neon-border-pink,
        .neon-border-green,
        .neon-border-blue {
            transition: all 0.3s ease;
        }
        
        /* 文本渐变效果 */
        .glitch-text {
            background: linear-gradient(90deg, #ffffff, #00f3ff, #ffffff);
            background-size: 200% auto;
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            animation: textGlow 3s linear infinite;
        }
        
        @keyframes textGlow {
            to {
                background-position: 200% center;
            }
        }
    </style>
</body>
</html>