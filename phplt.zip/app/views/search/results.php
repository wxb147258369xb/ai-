<?php include ROOT_PATH . '/app/views/layouts/header.php'; ?>

<section class="container mx-auto py-8 px-4">
    <!-- 面包屑导航 -->
    <nav class="flex mb-6 text-sm text-gray-500 cyber-breadcrumb" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-3">
            <li class="inline-flex items-center">
                <a href="/" class="hover:text-cyan-400 transition-colors">
                    <i class="fas fa-home mr-1"></i>首页
                </a>
            </li>
            <li>
                <div class="flex items-center">
                    <i class="fas fa-chevron-right text-gray-700 mx-1"></i>
                    <span class="text-cyan-400 font-medium">搜索结果</span>
                </div>
            </li>
        </ol>
    </nav>
    
    <h1 class="text-3xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500 cyber-glitch-text">
        搜索结果: <span class="text-white">&ldquo;<?php echo htmlspecialchars($query); ?>&rdquo;</span>
    </h1>
    
    <p class="text-gray-400 mb-8 cyber-scan-text">
        找到 <span class="text-cyan-400 font-bold"><?php echo $totalResults; ?></span> 个结果
    </p>
    
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <!-- 主内容区域 -->
        <div class="lg:col-span-8">
            <!-- 搜索表单 -->
            <div class="mb-8 p-6 bg-black bg-opacity-80 rounded-lg border border-cyan-800 shadow-glow-cyan cyberpunk-card">
                <form action="/search" method="GET" class="relative">
                    <div class="flex items-center">
                        <input 
                            type="text" 
                            name="q" 
                            value="<?php echo htmlspecialchars($query); ?>" 
                            placeholder="输入搜索关键词..." 
                            class="flex-1 w-full px-4 py-3 bg-gray-900 border border-cyan-700 rounded-lg text-gray-300 placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent cyber-input"
                        >
                        <button type="submit" class="ml-2 px-6 py-3 bg-gradient-to-r from-cyan-600 to-blue-700 text-black font-bold rounded-lg hover:from-cyan-500 hover:to-blue-600 transition-all duration-300 transform hover:scale-105 shadow-glow-cyan cyber-button">
                            <i class="fas fa-search mr-2"></i>搜索
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- 搜索类型切换 -->
            <div class="mb-8 cyberpunk-tabs">
                <div class="inline-flex p-1 bg-gray-900 rounded-lg border border-gray-800">
                    <a href="/search?q=<?php echo urlencode($query); ?>&type=thread" 
                       class="px-5 py-2 rounded-md text-sm font-medium transition-all duration-300
                       <?php echo $type === 'thread' ? 'bg-cyan-600 text-black shadow-glow-cyan' : 'text-gray-400 hover:text-cyan-400'; ?>">
                        话题
                    </a>
                    <a href="/search?q=<?php echo urlencode($query); ?>&type=reply" 
                       class="px-5 py-2 rounded-md text-sm font-medium transition-all duration-300
                       <?php echo $type === 'reply' ? 'bg-cyan-600 text-black shadow-glow-cyan' : 'text-gray-400 hover:text-cyan-400'; ?>">
                        回复
                    </a>
                    <a href="/search?q=<?php echo urlencode($query); ?>&type=user" 
                       class="px-5 py-2 rounded-md text-sm font-medium transition-all duration-300
                       <?php echo $type === 'user' ? 'bg-cyan-600 text-black shadow-glow-cyan' : 'text-gray-400 hover:text-cyan-400'; ?>">
                        用户
                    </a>
                </div>
            </div>
            
            <!-- 搜索结果 -->
            <?php if ($results): ?>
                <div class="space-y-6">
                    <?php if ($type === 'thread'): ?>
                        <!-- 话题结果 -->
                        <?php foreach ($results as $result): ?>
                            <div class="bg-black bg-opacity-80 border border-cyan-800 rounded-lg p-6 hover:border-cyan-500 transition-all duration-300 transform hover:-translate-y-1 shadow-glow-cyan cyberpunk-card">
                                <div class="flex items-start justify-between">
                                    <div class="flex-1 min-w-0">
                                        <div class="flex items-center mb-3">
                                            <span class="bg-cyan-900/50 text-cyan-400 text-xs font-semibold px-2.5 py-0.5 rounded-full mr-2">
                                                话题
                                            </span>
                                            <a href="/forum/<?php echo $result['forum_id']; ?>" class="text-xs text-gray-500 hover:text-cyan-400 transition-colors">
                                                <?php echo htmlspecialchars($result['forum_name']); ?>
                                            </a>
                                        </div>
                                        <h3 class="text-xl font-bold mb-2">
                                            <a href="/thread/<?php echo $result['id']; ?>" class="text-white hover:text-cyan-400 transition-colors cyber-link">
                                                <?php echo highlightText($result['title'], $query); ?>
                                            </a>
                                        </h3>
                                        <p class="text-gray-400 mb-4 line-clamp-2">
                                            <?php echo highlightText($result['content'], $query); ?>
                                        </p>
                                        <div class="flex items-center justify-between text-sm text-gray-500">
                                            <div class="flex items-center">
                                                <img src="<?php echo $result['avatar']; ?>" alt="用户头像" class="w-8 h-8 rounded-full mr-2 border border-cyan-700">
                                                <a href="/user/profile/<?php echo $result['user_id']; ?>" class="hover:text-cyan-400 transition-colors">
                                                    <?php echo htmlspecialchars($result['username']); ?>
                                                </a>
                                                <span class="mx-2">•</span>
                                                <span><?php echo formatTime($result['created_at']); ?></span>
                                            </div>
                                            <div class="flex items-center space-x-4">
                                                <span class="flex items-center"><i class="far fa-comment mr-1"></i> <?php echo $result['replies_count']; ?></span>
                                                <span class="flex items-center"><i class="far fa-eye mr-1"></i> <?php echo $result['views_count']; ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    
                    <?php elseif ($type === 'reply'): ?>
                        <!-- 回复结果 -->
                        <?php foreach ($results as $result): ?>
                            <div class="bg-black bg-opacity-80 border border-cyan-800 rounded-lg p-6 hover:border-cyan-500 transition-all duration-300 transform hover:-translate-y-1 shadow-glow-cyan cyberpunk-card">
                                <div class="flex items-start justify-between">
                                    <div class="flex-1 min-w-0">
                                        <div class="flex items-center mb-3">
                                            <span class="bg-purple-900/50 text-purple-400 text-xs font-semibold px-2.5 py-0.5 rounded-full mr-2">
                                                回复
                                            </span>
                                            <a href="/thread/<?php echo $result['thread_id']; ?>" class="text-xs text-gray-500 hover:text-cyan-400 transition-colors">
                                                回复于: <?php echo htmlspecialchars($result['thread_title']); ?>
                                            </a>
                                        </div>
                                        <div class="bg-gray-900/50 p-4 rounded-lg border border-gray-800 mb-4 cyber-quote">
                                            <p class="text-gray-300">
                                                <?php echo highlightText($result['content'], $query); ?>
                                            </p>
                                        </div>
                                        <div class="flex items-center justify-between text-sm text-gray-500">
                                            <div class="flex items-center">
                                                <img src="<?php echo $result['avatar']; ?>" alt="用户头像" class="w-8 h-8 rounded-full mr-2 border border-cyan-700">
                                                <a href="/user/profile/<?php echo $result['user_id']; ?>" class="hover:text-cyan-400 transition-colors">
                                                    <?php echo htmlspecialchars($result['username']); ?>
                                                </a>
                                                <span class="mx-2">•</span>
                                                <span><?php echo formatTime($result['created_at']); ?></span>
                                            </div>
                                            <a href="/thread/<?php echo $result['thread_id']; ?>?reply=<?php echo $result['id']; ?>#reply-<?php echo $result['id']; ?>" 
                                               class="px-3 py-1 bg-gray-900 hover:bg-gray-800 text-cyan-400 rounded-full text-xs transition-colors">
                                                查看上下文
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    
                    <?php elseif ($type === 'user'): ?>
                        <!-- 用户结果 -->
                        <?php foreach ($results as $result): ?>
                            <div class="bg-black bg-opacity-80 border border-cyan-800 rounded-lg p-6 hover:border-cyan-500 transition-all duration-300 transform hover:-translate-y-1 shadow-glow-cyan cyberpunk-card">
                                <div class="flex items-center">
                                    <img src="<?php echo $result['avatar']; ?>" alt="用户头像" class="w-16 h-16 rounded-full mr-4 border-2 border-cyan-700 cyber-avatar">
                                    <div class="flex-1">
                                        <h3 class="text-xl font-bold text-white mb-1">
                                            <?php echo highlightText(htmlspecialchars($result['username']), $query); ?>
                                        </h3>
                                        <p class="text-gray-400 text-sm mb-2">
                                            <?php echo htmlspecialchars($result['bio'] ? $result['bio'] : '暂无个人简介'); ?>
                                        </p>
                                        <div class="flex items-center text-xs text-gray-500 space-x-4">
                                            <span>话题: <?php echo $result['threads_count']; ?></span>
                                            <span>回复: <?php echo $result['replies_count']; ?></span>
                                            <span>注册: <?php echo formatDate($result['created_at']); ?></span>
                                        </div>
                                    </div>
                                    <a href="/user/profile/<?php echo $result['id']; ?>" class="bg-gradient-to-r from-cyan-600 to-blue-700 text-black font-bold py-2 px-4 rounded-full hover:from-cyan-500 hover:to-blue-600 transition-all duration-300 shadow-glow-cyan cyber-button">
                                        查看主页
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <!-- 分页导航 -->
                <?php if ($pages > 1): ?>
                    <div class="mt-8 flex justify-center">
                        <div class="inline-flex rounded-md shadow-sm cyber-pagination" role="group">
                            <?php if ($page > 1): ?>
                                <a href="/search?q=<?php echo urlencode($query); ?>&type=<?php echo $type; ?>&page=<?php echo $page - 1; ?>" 
                                   class="px-4 py-2 text-sm font-medium text-gray-300 bg-gray-900 border border-gray-800 rounded-l-lg hover:bg-gray-800 hover:text-cyan-400 transition-all duration-300 cyber-pagination-item">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                            <?php endif; ?>
                            
                            <?php 
                            $startPage = max(1, $page - 2);
                            $endPage = min($pages, $startPage + 4);
                            if ($endPage - $startPage < 4) {
                                $startPage = max(1, $endPage - 4);
                            }
                            
                            for ($i = $startPage; $i <= $endPage; $i++):
                            ?>
                                <a href="/search?q=<?php echo urlencode($query); ?>&type=<?php echo $type; ?>&page=<?php echo $i; ?>" 
                                   class="px-4 py-2 text-sm font-medium <?php echo $i === $page ? 'bg-cyan-600 text-black shadow-glow-cyan' : 'text-gray-300 bg-gray-900 hover:bg-gray-800 hover:text-cyan-400'; ?> border border-gray-800 transition-all duration-300 cyber-pagination-item">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $pages): ?>
                                <a href="/search?q=<?php echo urlencode($query); ?>&type=<?php echo $type; ?>&page=<?php echo $page + 1; ?>" 
                                   class="px-4 py-2 text-sm font-medium text-gray-300 bg-gray-900 border border-gray-800 rounded-r-lg hover:bg-gray-800 hover:text-cyan-400 transition-all duration-300 cyber-pagination-item">
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <!-- 无结果 -->
                <div class="text-center py-16 bg-black bg-opacity-60 border border-cyan-800 rounded-lg cyberpunk-card">
                    <div class="inline-flex items-center justify-center w-20 h-20 bg-gray-900 rounded-full mb-4 border border-cyan-900">
                        <i class="fas fa-search text-3xl text-cyan-700"></i>
                    </div>
                    <h3 class="text-xl font-bold text-cyan-400 mb-2 cyber-glitch-text">未找到相关结果</h3>
                    <p class="text-gray-500 max-w-md mx-auto">
                        尝试使用其他关键词，或检查拼写是否正确。您也可以浏览论坛的热门话题或版块。
                    </p>
                    <div class="mt-6">
                        <a href="/" class="inline-flex items-center px-6 py-3 bg-gradient-to-r from-cyan-600 to-blue-700 text-black font-bold rounded-lg hover:from-cyan-500 hover:to-blue-600 transition-all duration-300 shadow-glow-cyan cyber-button">
                            <i class="fas fa-home mr-2"></i>返回首页
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- 侧边栏 -->
        <div class="lg:col-span-4">
            <!-- 热门搜索 -->
            <div class="bg-black bg-opacity-80 border border-cyan-800 rounded-lg p-6 mb-8 shadow-glow-cyan cyberpunk-card">
                <h3 class="text-xl font-bold text-cyan-400 mb-4 cyber-scan-text">热门搜索</h3>
                <div class="flex flex-wrap gap-2">
                    <?php if (!empty($hotSearches)): ?>
                        <?php foreach ($hotSearches as $search): ?>
                            <a href="/search?q=<?php echo urlencode($search['query']); ?>" 
                               class="inline-flex items-center px-3 py-1 bg-gray-900 border border-gray-800 rounded-full text-sm text-gray-400 hover:text-cyan-400 hover:border-cyan-700 transition-all duration-300 cyber-tag">
                                <span class="mr-1"><?php echo htmlspecialchars($search['query']); ?></span>
                                <span class="text-xs text-gray-600">(<?php echo $search['count']; ?>)</span>
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-gray-500 text-sm w-full text-center">暂无热门搜索</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- 相关搜索 -->
            <?php if (!empty($relatedSearches)): ?>
                <div class="bg-black bg-opacity-80 border border-cyan-800 rounded-lg p-6 mb-8 shadow-glow-cyan cyberpunk-card">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4 cyber-scan-text">相关搜索</h3>
                    <div class="space-y-2">
                        <?php foreach ($relatedSearches as $related): ?>
                            <a href="/search?q=<?php echo urlencode($related); ?>&type=<?php echo $type; ?>" 
                               class="flex items-center p-3 bg-gray-900 bg-opacity-50 hover:bg-gray-800 rounded-lg transition-colors cyber-related-search">
                                <i class="fas fa-search text-cyan-500 mr-3"></i>
                                <span class="text-gray-400 hover:text-cyan-400 transition-colors">
                                    <?php echo htmlspecialchars($related); ?>
                                </span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- 搜索建议 -->
            <div class="bg-black bg-opacity-80 border border-cyan-800 rounded-lg p-6 shadow-glow-cyan cyberpunk-card">
                <h3 class="text-xl font-bold text-cyan-400 mb-4 cyber-scan-text">搜索技巧</h3>
                <ul class="space-y-4 text-sm text-gray-400">
                    <li class="flex items-start cyber-tip">
                        <i class="fas fa-lightbulb text-yellow-500 mt-1 mr-3 flex-shrink-0"></i>
                        <span>使用更精确的关键词可以获得更相关的结果</span>
                    </li>
                    <li class="flex items-start cyber-tip">
                        <i class="fas fa-lightbulb text-yellow-500 mt-1 mr-3 flex-shrink-0"></i>
                        <span>尝试使用不同的搜索类型（话题、回复、用户）</span>
                    </li>
                    <li class="flex items-start cyber-tip">
                        <i class="fas fa-lightbulb text-yellow-500 mt-1 mr-3 flex-shrink-0"></i>
                        <span>检查关键词的拼写是否正确</span>
                    </li>
                    <li class="flex items-start cyber-tip">
                        <i class="fas fa-lightbulb text-yellow-500 mt-1 mr-3 flex-shrink-0"></i>
                        <span>如果找不到结果，可以尝试更一般化的术语</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 搜索输入框交互
        const searchInput = document.querySelector('input[name="q"]');
        const searchForm = document.querySelector('form[action="/search"]');
        
        // 添加输入框焦点动画效果
        searchInput.addEventListener('focus', function() {
            this.classList.add('animate-pulse');
            setTimeout(() => {
                this.classList.remove('animate-pulse');
            }, 1000);
        });
        
        // 搜索自动完成功能
        let autocompleteTimer;
        let autocompleteDropdown;
        
        searchInput.addEventListener('input', function() {
            clearTimeout(autocompleteTimer);
            
            const query = this.value.trim();
            
            if (query.length >= 2) {
                autocompleteTimer = setTimeout(() => {
                    fetch(`/search/autocomplete?q=${encodeURIComponent(query)}`)
                        .then(response => response.json())
                        .then(suggestions => {
                            renderAutocompleteSuggestions(suggestions);
                        })
                        .catch(error => {
                            console.error('自动完成错误:', error);
                        });
                }, 300);
            } else {
                hideAutocompleteDropdown();
            }
        });
        
        // 点击其他区域隐藏自动完成下拉框
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && autocompleteDropdown && !autocompleteDropdown.contains(e.target)) {
                hideAutocompleteDropdown();
            }
        });
        
        function renderAutocompleteSuggestions(suggestions) {
            // 移除已有的下拉框
            hideAutocompleteDropdown();
            
            if (suggestions.length === 0) {
                return;
            }
            
            // 创建下拉框
            autocompleteDropdown = document.createElement('div');
            autocompleteDropdown.className = 'absolute left-0 right-0 top-full mt-1 bg-gray-900 border border-cyan-700 rounded-lg shadow-lg z-50 max-h-60 overflow-y-auto cyber-autocomplete';
            
            // 添加建议项
            suggestions.forEach(suggestion => {
                const item = document.createElement('a');
                item.href = '#';
                item.className = 'flex items-center px-4 py-3 hover:bg-gray-800 hover:text-cyan-400 transition-colors border-b border-gray-800 last:border-b-0 cyber-autocomplete-item';
                
                let typeIcon = 'fa-search';
                let typeText = '';
                
                if (suggestion.type === 'thread') {
                    typeIcon = 'fa-file-alt';
                    typeText = '话题';
                } else if (suggestion.type === 'user') {
                    typeIcon = 'fa-user';
                    typeText = '用户';
                }
                
                item.innerHTML = `
                    <i class="fas ${typeIcon} text-cyan-500 mr-3"></i>
                    <span class="flex-1 text-sm text-gray-300">${highlightText(suggestion.suggestion, searchInput.value)}</span>
                    <span class="text-xs text-gray-500 bg-gray-800 px-2 py-0.5 rounded">${typeText}</span>
                `;
                
                item.addEventListener('click', function(e) {
                    e.preventDefault();
                    searchInput.value = suggestion.suggestion;
                    hideAutocompleteDropdown();
                    
                    // 添加选择动画
                    searchInput.classList.add('border-green-500');
                    setTimeout(() => {
                        searchInput.classList.remove('border-green-500');
                    }, 500);
                });
                
                // 添加悬停效果
                item.addEventListener('mouseenter', function() {
                    this.classList.add('cyber-glow');
                });
                
                item.addEventListener('mouseleave', function() {
                    this.classList.remove('cyber-glow');
                });
                
                autocompleteDropdown.appendChild(item);
            });
            
            // 添加到DOM
            searchForm.appendChild(autocompleteDropdown);
        }
        
        function hideAutocompleteDropdown() {
            if (autocompleteDropdown) {
                // 添加淡出动画
                autocompleteDropdown.classList.add('opacity-0');
                setTimeout(() => {
                    autocompleteDropdown.remove();
                    autocompleteDropdown = null;
                }, 200);
            }
        }
        
        function highlightText(text, query) {
            if (!query) return text;
            
            const regex = new RegExp(`(${RegExp.escape(query)})`, 'gi');
            return text.replace(regex, '<span class="bg-cyan-900/50 text-cyan-400 cyber-highlight">$1</span>');
        }
        
        // RegExp.escape polyfill
        if (!RegExp.escape) {
            RegExp.escape = function(string) {
                return string.replace(/[.*+?^${}()|\[\]\\]/g, '\\$&');
            };
        }
        
        // 添加滚动渐入动画
        const animateOnScroll = () => {
            const elements = document.querySelectorAll('.cyberpunk-card');
            
            elements.forEach(element => {
                const elementPosition = element.getBoundingClientRect().top;
                const screenPosition = window.innerHeight / 1.3;
                
                if (elementPosition < screenPosition) {
                    element.classList.add('cyber-fade-in');
                }
            });
        };
        
        // 初始加载和滚动时执行动画
        window.addEventListener('scroll', animateOnScroll);
        window.addEventListener('load', animateOnScroll);
        
        // 为卡片添加悬停效果
        const cards = document.querySelectorAll('.cyberpunk-card');
        cards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-4px)';
                this.style.boxShadow = '0 0 15px rgba(6, 182, 212, 0.5)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(-1px)';
                this.style.boxShadow = '0 0 10px rgba(6, 182, 212, 0.3)';
            });
        });
    });
</script>

<?php include ROOT_PATH . '/app/views/layouts/footer.php'; ?>