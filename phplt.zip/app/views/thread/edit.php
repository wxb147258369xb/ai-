<?php include ROOT_PATH . '/app/views/layouts/header.php'; ?>

<section class="py-8">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <!-- 主要内容区 -->
            <div class="lg:col-span-8">
                <!-- 编辑话题表单 -->
                <div class="bg-black bg-opacity-60 border border-cyan-500 rounded-lg p-6 mb-8 shadow-glow-cyan">
                    <div class="flex items-center justify-between mb-6">
                        <h1 class="text-2xl font-bold text-cyan-400">编辑话题</h1>
                        <a href="/thread/show/<?php echo $thread['id']; ?>" class="px-4 py-2 bg-gray-800 border border-cyan-700 rounded-lg text-gray-300 hover:bg-gray-700 transition-colors">
                            <i class="fas fa-arrow-left mr-2"></i> 返回话题
                        </a>
                    </div>
                    
                    <!-- 错误/成功消息 -->
                    <?php if (isset($error)): ?>
                        <div class="bg-red-900 bg-opacity-50 border border-red-700 rounded-lg p-4 mb-6">
                            <p class="text-red-300"><i class="fas fa-exclamation-circle mr-2"></i> <?php echo htmlspecialchars($error); ?></p>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($success)): ?>
                        <div class="bg-green-900 bg-opacity-50 border border-green-700 rounded-lg p-4 mb-6">
                            <p class="text-green-300"><i class="fas fa-check-circle mr-2"></i> <?php echo htmlspecialchars($success); ?></p>
                        </div>
                    <?php endif; ?>
                    
                    <form action="/thread/doEdit/<?php echo $thread['id']; ?>" method="post" class="edit-thread-form">
                        <div class="mb-6">
                            <label for="title" class="block text-gray-300 font-medium mb-2">话题标题</label>
                            <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($thread['title']); ?>" 
                                   class="w-full bg-gray-900 border border-cyan-700 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all duration-300" 
                                   placeholder="请输入话题标题（5-100个字符）" required>
                        </div>
                        
                        <div class="mb-6">
                            <label for="content" class="block text-gray-300 font-medium mb-2">话题内容</label>
                            <textarea id="content" name="content" rows="10" 
                                      class="w-full bg-gray-900 border border-cyan-700 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all duration-300 resize-none" 
                                      placeholder="请输入话题内容（至少10个字符）" required><?php echo htmlspecialchars($thread['content']); ?></textarea>
                        </div>
                        
                        <div class="flex justify-between">
                            <button type="button" class="px-6 py-3 bg-gray-800 border border-cyan-700 rounded-lg text-gray-300 hover:bg-gray-700 transition-all duration-300" onclick="window.history.back()">
                                <i class="fas fa-times mr-2"></i> 取消
                            </button>
                            <button type="submit" class="px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-bold rounded-lg hover:from-cyan-400 hover:to-blue-500 transition-all duration-300 transform hover:-translate-y-1 shadow-glow-cyan edit-submit-btn">
                                <i class="fas fa-save mr-2"></i> 保存修改
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- 侧边栏 -->
            <div class="lg:col-span-4">
                <!-- 编辑提示 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 mb-8 shadow-glow-cyan">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4 flex items-center">
                        <i class="fas fa-info-circle text-cyan-500 mr-2"></i> 编辑提示
                    </h3>
                    <ul class="space-y-3 text-gray-300">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-green-500 mt-1 mr-2 flex-shrink-0"></i>
                            <span>标题长度应在5-100个字符之间</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-green-500 mt-1 mr-2 flex-shrink-0"></i>
                            <span>内容长度至少为10个字符</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-exclamation-circle text-yellow-500 mt-1 mr-2 flex-shrink-0"></i>
                            <span>修改会记录最后更新时间</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-exclamation-circle text-yellow-500 mt-1 mr-2 flex-shrink-0"></i>
                            <span>请确保内容符合社区规范</span>
                        </li>
                    </ul>
                </div>

                <!-- 话题统计 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 shadow-glow-cyan">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4">话题统计</h3>
                    <div class="space-y-4">
                        <div class="flex justify-between items-center">
                            <span class="text-gray-400">创建时间</span>
                            <span class="text-gray-300"><?php echo date('Y-m-d H:i', strtotime($thread['created_at'])); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-400">最后更新</span>
                            <span class="text-gray-300"><?php echo date('Y-m-d H:i', strtotime($thread['updated_at'])); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-400">浏览次数</span>
                            <span class="text-gray-300"><?php echo $thread['view_count']; ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-400">回复数量</span>
                            <span class="text-gray-300"><?php echo $thread['reply_count']; ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 表单提交验证和动画
        const editForm = document.querySelector('.edit-thread-form');
        const editSubmitBtn = document.querySelector('.edit-submit-btn');
        
        editForm.addEventListener('submit', function(e) {
            const title = document.getElementById('title').value.trim();
            const content = document.getElementById('content').value.trim();
            
            // 表单验证
            if (!title || title.length < 5 || title.length > 100) {
                alert('标题长度应在5-100个字符之间');
                e.preventDefault();
                return;
            }
            
            if (!content || content.length < 10) {
                alert('内容长度至少为10个字符');
                e.preventDefault();
                return;
            }
            
            // 提交动画
            editSubmitBtn.disabled = true;
            editSubmitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> 保存中...';
        });
    });
</script>

<?php include ROOT_PATH . '/app/views/layouts/footer.php'; ?>