<?php include ROOT_PATH . '/app/views/layouts/header.php'; ?>

<!-- 动态背景效果 - 网格和扫描线 -->
<div class="fixed inset-0 z-[-1] bg-black">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-cyan-900/20 via-black to-black"></div>
    <div class="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMtMS4zNiAwLTIuNDgtMS4xMi0yLjQ4LTIuNDhWMThjMC0xLjM2IDEuMTItMi40OCAyLjQ4LTIuNDhIMThWMTRIMzZjMS4zNiAwIDIuNDggMS4xMiAyLjQ4IDIuNDhWMTguMDh6bTE0LjQyIDcuNTJMMzYgMjYuMjFWMTguMjVjMC0uMzguMzItLjcuNzEtLjdsMi40OCAyLjQ4Yy4zOC4zOC4zOC43MiAwIC43MUwzNiAyMTh2My42MWMuMzguMzguNzEuNjIgMS4wOS42MmgxLjg3M2MtLjA4LjQ4LS4zNi45Mi0uNzcgMS4xN2wtMi40OCAxLjI0Yy0uNDUuMjMtLjk5LjA1LTEuMy0uNDVMMzYgMjYuNTh2NS42MWMzLjY1LjAzIDYuNTgtMy4wMiA2LjYyLTYuNjd6IiBzdHJva2U9IiMwYjc4YmEiIHN0cm9rZS1vcGFjaXR5PSIuMSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9nPjwvc3ZnPg==')] opacity-30"></div>
    <div class="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-900/5 to-transparent pointer-events-none"></div>
    <!-- 扫描线效果 -->
    <div class="scanline absolute inset-0 pointer-events-none"></div>
</div>

<style>
    .scanline {
        background: linear-gradient(
            to bottom,
            transparent 0%,
            rgba(0, 255, 255, 0.1) 50%,
            transparent 100%
        );
        background-size: 100% 4px;
        animation: scanline 6s linear infinite;
    }
    
    @keyframes scanline {
        0% { transform: translateY(-100%); }
        100% { transform: translateY(100%); }
    }
    
    .glow-cyan {
        box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
    }
    
    .glow-purple {
        box-shadow: 0 0 10px rgba(128, 0, 255, 0.5);
    }
    
    .thread-card:hover {
        border-color: rgba(0, 255, 255, 0.8);
        box-shadow: 0 0 15px rgba(0, 255, 255, 0.6);
    }
    
    .reply-card:hover {
        border-color: rgba(0, 255, 255, 0.5);
        background-color: rgba(10, 10, 30, 0.6);
    }
    
    .btn-hover-effect {
        position: relative;
        overflow: hidden;
        transition: all 0.3s ease;
    }
    
    .btn-hover-effect::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 0;
        height: 0;
        background: rgba(0, 255, 255, 0.3);
        border-radius: 50%;
        transform: translate(-50%, -50%);
        transition: width 0.6s, height 0.6s;
    }
    
    .btn-hover-effect:hover::before {
        width: 300px;
        height: 300px;
    }
    
    .user-avatar {
        transition: transform 0.3s ease;
    }
    
    .user-avatar:hover {
        transform: scale(1.05);
        border-color: #00ffff !important;
    }
    
    .highlight-text {
        background: linear-gradient(transparent 70%, rgba(0, 255, 255, 0.3) 0);
        padding: 0 2px;
    }
    
    .progress-bar {
        position: fixed;
        top: 0;
        left: 0;
        height: 2px;
        background: linear-gradient(90deg, #00ffff, #8000ff);
        z-index: 1000;
        width: 0;
        transition: width 0.1s ease;
    }
    
    .neon-border {
        position: relative;
    }
    
    .neon-border::after {
        content: '';
        position: absolute;
        top: -1px;
        left: -1px;
        right: -1px;
        bottom: -1px;
        border: 1px solid transparent;
        border-image: linear-gradient(45deg, #00ffff, #8000ff, #ff00ff) 1;
        border-radius: inherit;
        pointer-events: none;
        opacity: 0.7;
    }
</style>

<!-- 滚动进度条 -->
<div class="progress-bar" id="progressBar"></div>

<!-- 话题详情页 -->
<section class="py-8">
    <div class="container mx-auto px-4">
        <!-- 话题面包屑 -->
        <div class="mb-6 animate-fade-in">
            <nav class="flex text-sm" aria-label="Breadcrumb">
                <ol class="inline-flex items-center space-x-1 md:space-x-3">
                    <li class="inline-flex items-center">
                        <a href="/" class="text-gray-400 hover:text-cyan-400 transition-colors">
                            <i class="fas fa-home mr-2"></i>首页
                        </a>
                    </li>
                    <li class="inline-flex items-center">
                        <a href="/forum/show/<?php echo !empty($thread['forum_id']) ? $thread['forum_id'] : ''; ?>" class="text-gray-400 hover:text-cyan-400 transition-colors">
                            <i class="fas fa-chevron-right text-gray-600 mx-2 text-xs"></i>
                            <span><?php echo !empty($thread['forum_name']) ? htmlspecialchars($thread['forum_name']) : '未知版块'; ?></span>
                        </a>
                    </li>
                    <li>
                        <div class="flex items-center">
                            <i class="fas fa-chevron-right text-gray-600 mx-2 text-xs"></i>
                            <span class="text-cyan-400 font-medium truncate max-w-[200px] md:max-w-[400px]" style="text-shadow: 0 0 5px rgba(0, 255, 255, 0.7);">
                                <?php echo htmlspecialchars($thread['title']); ?>
                            </span>
                        </div>
                    </li>
                </ol>
            </nav>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <!-- 主要内容区 -->
            <div class="lg:col-span-8">
                <!-- 话题详情卡片 -->
                <div class="thread-card bg-black bg-opacity-70 border border-cyan-800 rounded-lg mb-6 shadow-glow-cyan p-0 overflow-hidden neon-border" style="transition: all 0.3s ease;">
                    <!-- 话题头部 -->
                    <div class="px-6 py-5 border-b border-cyan-800 bg-gradient-to-r from-gray-900/80 to-black/80">
                        <div class="flex items-center justify-between mb-3">
                            <h1 class="text-2xl font-bold text-white">
                                <?php if (!empty($thread['is_pinned']) && $thread['is_pinned']): ?>
                                    <span class="text-yellow-500 mr-2"><i class="fas fa-thumbtack"></i></span>
                                <?php endif; ?>
                                <?php if (!empty($thread['is_locked']) && $thread['is_locked']): ?>
                                    <span class="text-gray-500 mr-2"><i class="fas fa-lock"></i></span>
                                <?php endif; ?>
                                <span class="glitch">
                                    <?php echo htmlspecialchars($thread['title']); ?>
                                </span>
                            </h1>
                            <div class="flex items-center gap-2">
                                <button class="text-gray-400 hover:text-white p-2 rounded-full hover:bg-gray-800 transition-colors">
                                    <i class="fas fa-share-alt"></i>
                                </button>
                                <button class="text-gray-400 hover:text-white p-2 rounded-full hover:bg-gray-800 transition-colors">
                                    <i class="fas fa-bookmark"></i>
                                </button>
                            </div>
                        </div>
                        <div class="flex flex-wrap items-center gap-4 text-sm">
                            <div class="flex items-center">
                                <img src="https://picsum.photos/id/<?php echo !empty($thread['author_id']) ? $thread['author_id'] : '1'; ?>/50/50" 
                                     alt="<?php echo !empty($thread['author']) ? htmlspecialchars($thread['author']) : '未知用户'; ?>" 
                                     class="user-avatar w-10 h-10 rounded-full mr-3 object-cover border border-gray-700">
                                <div>
                                    <a href="#" class="text-cyan-400 hover:underline font-medium" style="text-shadow: 0 0 5px rgba(0, 255, 255, 0.5);">
                                        <?php echo !empty($thread['author']) ? htmlspecialchars($thread['author']) : '未知用户'; ?>
                                    </a>
                                    <div class="text-gray-500 text-xs">发布于 <?php echo !empty($thread['created_at']) ? format_relative_time($thread['created_at']) : '未知时间'; ?></div>
                                </div>
                            </div>
                            <div class="flex items-center ml-auto space-x-6">
                                <div class="flex items-center text-gray-400">
                                    <i class="far fa-eye mr-1"></i> 
                                    <span><?php echo !empty($thread['view_count']) ? number_format($thread['view_count']) : '0'; ?></span>
                                </div>
                                <div class="flex items-center text-gray-400">
                                    <i class="far fa-comment mr-1"></i> 
                                    <span><?php echo !empty($thread['reply_count']) ? number_format($thread['reply_count']) : '0'; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 话题内容 -->
                    <div class="p-6">
                        <div class="thread-content text-gray-300 leading-relaxed">
                            <?php echo !empty($thread['content']) ? $thread['content'] : ''; ?>
                        </div>
                    </div>

                    <!-- 话题操作区 -->
                    <div class="px-6 py-4 border-t border-gray-800 bg-gradient-to-r from-black/80 to-gray-900/80 flex flex-wrap justify-between items-center gap-3">
                        <div class="flex items-center gap-3">
                            <button class="btn-hover-effect flex items-center gap-2 px-3 py-1.5 bg-gray-900 border border-gray-700 text-gray-300 rounded-lg hover:bg-gray-800 hover:border-cyan-700 transition-colors">
                                <i class="far fa-thumbs-up"></i>
                                <span>点赞</span>
                            </button>
                            <button class="btn-hover-effect flex items-center gap-2 px-3 py-1.5 bg-gray-900 border border-gray-700 text-gray-300 rounded-lg hover:bg-gray-800 hover:border-cyan-700 transition-colors">
                                <i class="far fa-thumbs-down"></i>
                                <span>踩</span>
                            </button>
                            <button class="btn-hover-effect flex items-center gap-2 px-3 py-1.5 bg-gray-900 border border-gray-700 text-gray-300 rounded-lg hover:bg-gray-800 hover:border-cyan-700 transition-colors">
                                <i class="far fa-flag"></i>
                                <span>举报</span>
                            </button>
                        </div>
                        <div>
                            <a href="/thread/edit/<?php echo !empty($thread['id']) ? $thread['id'] : ''; ?>" 
                               class="btn-hover-effect inline-flex items-center gap-2 px-3 py-1.5 bg-gray-900 border border-gray-700 text-gray-300 rounded-lg hover:bg-gray-800 hover:border-cyan-700 transition-colors">
                                <i class="far fa-edit"></i>
                                <span>编辑</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- 回复区域 -->
                <div class="thread-card bg-black bg-opacity-70 border border-cyan-800 rounded-lg mb-6 shadow-glow-cyan neon-border" style="transition: all 0.3s ease;">
                    <div class="px-6 py-4 border-b border-cyan-800 bg-gradient-to-r from-gray-900/80 to-black/80">
                        <h3 class="text-xl font-bold text-cyan-400" style="text-shadow: 0 0 5px rgba(0, 255, 255, 0.7);">
                            <i class="far fa-comment-dots mr-2"></i>回复 <span class="text-white">(<?php echo !empty($thread['reply_count']) ? number_format($thread['reply_count']) : '0'; ?>)</span>
                        </h3>
                    </div>

                    <!-- 回复列表 -->
                    <div class="divide-y divide-gray-800">
                        <?php if (empty($replies['data'])): ?>
                            <!-- 空回复状态 -->
                            <div class="px-6 py-12 text-center">
                                <i class="far fa-comment-alt text-gray-700 text-5xl mb-4"></i>
                                <h3 class="text-xl font-semibold text-gray-400 mb-2">暂无回复</h3>
                                <p class="text-gray-500 mb-6">成为第一个回复此话题的用户！</p>
                                <a href="#reply-form" class="inline-block px-6 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 text-black font-bold rounded-lg shadow-glow-cyan hover:from-cyan-500 hover:to-blue-500 transition-colors">
                                    发表第一条回复
                                </a>
                            </div>
                        <?php else: ?>
                            <?php foreach ($replies['data'] as $reply): ?>
                                <div class="reply-card px-6 py-5 hover:bg-gray-900/30 transition-colors">
                                    <div class="flex flex-col md:flex-row gap-4">
                                        <!-- 用户头像 -->
                                        <div class="flex-shrink-0">
                                            <img src="https://picsum.photos/id/<?php echo !empty($reply['author_id']) ? $reply['author_id'] : '1'; ?>/50/50" 
                                                 alt="<?php echo !empty($reply['author']) ? htmlspecialchars($reply['author']) : '未知用户'; ?>" 
                                                 class="user-avatar w-12 h-12 rounded-full object-cover border border-gray-700">
                                        </div>

                                        <!-- 回复内容 -->
                                        <div class="flex-1">
                                            <div class="flex flex-wrap items-center justify-between mb-2 gap-2">
                                                <div class="flex items-center gap-2">
                                                    <a href="#" class="text-cyan-400 hover:underline font-medium" style="text-shadow: 0 0 5px rgba(0, 255, 255, 0.5);">
                                                        <?php echo !empty($reply['author']) ? htmlspecialchars($reply['author']) : '未知用户'; ?>
                                                    </a>
                                                    <span class="text-gray-500 text-xs"><?php echo !empty($reply['created_at']) ? format_relative_time($reply['created_at']) : '未知时间'; ?></span>
                                                </div>
                                                <div class="flex items-center gap-2">
                                                    <button class="btn-hover-effect text-gray-500 hover:text-gray-300 text-sm flex items-center gap-1 p-1 rounded">
                                                        <i class="far fa-thumbs-up"></i> 点赞
                                                    </button>
                                                    <button class="btn-hover-effect text-gray-500 hover:text-gray-300 text-sm flex items-center gap-1 p-1 rounded">
                                                        <i class="far fa-thumbs-down"></i> 踩
                                                    </button>
                                                    <button class="btn-hover-effect text-gray-500 hover:text-gray-300 text-sm flex items-center gap-1 p-1 rounded">
                                                        <i class="far fa-comment"></i> 回复
                                                    </button>
                                                    <button class="btn-hover-effect text-gray-500 hover:text-gray-300 text-sm flex items-center gap-1 p-1 rounded">
                                                        <i class="far fa-flag"></i> 举报
                                                    </button>
                                                </div>
                                            </div>

                                            <div class="reply-content text-gray-300 leading-relaxed mb-3">
                                                <?php echo !empty($reply['content']) ? $reply['content'] : ''; ?>
                                            </div>

                                            <!-- 引用回复 -->
                                            <?php if (!empty($reply['quote'])): ?>
                                                <div class="bg-gray-900/60 border border-gray-800 rounded-lg p-3 mb-3 hover:border-cyan-700 transition-colors">
                                                    <div class="text-xs text-gray-500 mb-1">
                                                        引用自 <span class="text-cyan-400">
                                                            <?php echo !empty($reply['quote']['author']) ? htmlspecialchars($reply['quote']['author']) : '未知用户'; ?>
                                                        </span>
                                                    </div>
                                                    <div class="text-sm text-gray-400 line-clamp-3">
                                                        <?php echo !empty($reply['quote']['content']) ? strip_tags($reply['quote']['content']) : ''; ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                            <!-- 回复操作 -->
                                            <div class="flex items-center text-xs text-gray-500">
                                                <a href="#" class="hover:text-cyan-400 transition-colors">
                                                    <i class="far fa-edit mr-1"></i>编辑
                                                </a>
                                                <span class="mx-2">•</span>
                                                <span>
                                                    <i class="far fa-clock mr-1"></i>
                                                    <?php echo !empty($reply['created_at']) ? date('Y-m-d H:i', strtotime($reply['created_at'])) : '未知时间'; ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <!-- 回复分页 -->
                    <?php if (!empty($replies['pages']) && $replies['pages'] > 1): ?>
                    <div class="px-6 py-4 border-t border-cyan-800 bg-gradient-to-r from-black/80 to-gray-900/80">
                        <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                            <div class="text-sm text-gray-400">
                                显示 <span class="text-cyan-400 highlight-text"><?php echo isset($replies['start_item']) ? $replies['start_item'] : '1'; ?>-<?php echo isset($replies['end_item']) ? $replies['end_item'] : $replies['pages']; ?></span> 条，共 <span class="text-cyan-400 highlight-text"><?php echo isset($replies['total_items']) ? $replies['total_items'] : ($replies['pages'] * 20); ?></span> 条
                            </div>
                            <div class="flex items-center space-x-1">
                                <a href="/thread/show/<?php echo !empty($thread['id']) ? $thread['id'] : ''; ?>?page=<?php echo $page - 1; ?>" 
                                   class="btn-hover-effect px-3 py-1 rounded-md text-sm transition-colors duration-200
                                          <?php if ($page == 1): ?>
                                          text-gray-700 cursor-not-allowed
                                          <?php else: ?>
                                          text-gray-400 hover:text-white hover:bg-gray-800 hover:border-cyan-700
                                          <?php endif; ?>">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                                
                                <?php for ($i = 1; $i <= $replies['pages']; $i++): ?>
                                    <a href="/thread/show/<?php echo !empty($thread['id']) ? $thread['id'] : ''; ?>?page=<?php echo $i; ?>" 
                                       class="btn-hover-effect px-3 py-1 rounded-md text-sm transition-colors duration-200
                                              <?php if ($i == $page): ?>
                                              bg-cyan-800/50 text-cyan-400 font-medium shadow-glow-cyan
                                              <?php else: ?>
                                              text-gray-400 hover:text-white hover:bg-gray-800 hover:border-cyan-700
                                              <?php endif; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                <?php endfor; ?>
                                
                                <a href="/thread/show/<?php echo !empty($thread['id']) ? $thread['id'] : ''; ?>?page=<?php echo $page + 1; ?>" 
                                   class="btn-hover-effect px-3 py-1 rounded-md text-sm transition-colors duration-200
                                          <?php if ($page == $replies['pages']): ?>
                                          text-gray-700 cursor-not-allowed
                                          <?php else: ?>
                                          text-gray-400 hover:text-white hover:bg-gray-800 hover:border-cyan-700
                                          <?php endif; ?>">
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- 发表回复 -->
                <div id="reply-form" class="thread-card bg-black bg-opacity-70 border border-cyan-800 rounded-lg shadow-glow-cyan neon-border" style="transition: all 0.3s ease;">
                    <div class="px-6 py-4 border-b border-cyan-800 bg-gradient-to-r from-gray-900/80 to-black/80">
                        <h3 class="text-xl font-bold text-cyan-400" style="text-shadow: 0 0 5px rgba(0, 255, 255, 0.7);">
                            <i class="far fa-edit mr-2"></i>发表回复
                        </h3>
                    </div>
                    <div class="p-6">
                        <form action="/thread/reply/<?php echo !empty($thread['id']) ? $thread['id'] : ''; ?>" method="post">
                            <!-- 回复内容 -->
                            <div class="mb-4">
                                <textarea name="content" id="reply-content" rows="6" 
                                          class="w-full bg-gray-900 border border-gray-700 text-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-1 focus:ring-cyan-400 focus:border-cyan-400 resize-none transition-all duration-300 hover:border-cyan-700" 
                                          placeholder="写下你的回复..."></textarea>
                                <div class="flex justify-end mt-1">
                                    <span id="char-count" class="text-xs text-gray-500">0 字符</span>
                                </div>
                            </div>

                            <!-- 操作按钮 -->
                            <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                                <div class="flex items-center gap-3">
                                    <button type="button" class="btn-hover-effect text-gray-400 hover:text-white p-2 rounded-full hover:bg-gray-800 transition-colors">
                                        <i class="far fa-image"></i>
                                    </button>
                                    <button type="button" class="btn-hover-effect text-gray-400 hover:text-white p-2 rounded-full hover:bg-gray-800 transition-colors">
                                        <i class="fas fa-code"></i>
                                    </button>
                                    <button type="button" class="btn-hover-effect text-gray-400 hover:text-white p-2 rounded-full hover:bg-gray-800 transition-colors">
                                        <i class="far fa-smile"></i>
                                    </button>
                                </div>
                                <button type="submit" 
                                        class="btn-hover-effect px-6 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 text-black font-bold rounded-lg shadow-glow-cyan hover:from-cyan-500 hover:to-blue-500 transition-all duration-300 transform hover:scale-105">
                                    发表回复
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- 侧边栏 -->
            <div class="lg:col-span-4">
                <!-- 话题统计 -->
                <div class="thread-card bg-black bg-opacity-70 border border-cyan-800 rounded-lg p-6 mb-6 shadow-glow-cyan neon-border" style="transition: all 0.3s ease;">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4" style="text-shadow: 0 0 5px rgba(0, 255, 255, 0.7);">话题统计</h3>
                    <div class="space-y-4">
                        <div class="flex items-center justify-between pb-3 border-b border-gray-800">
                            <span class="text-gray-400">发布时间</span>
                            <span class="text-white font-medium">
                                <?php echo !empty($thread['created_at']) ? date('Y-m-d', strtotime($thread['created_at'])) : '未知'; ?>
                            </span>
                        </div>
                        <div class="flex items-center justify-between pb-3 border-b border-gray-800">
                            <span class="text-gray-400">浏览次数</span>
                            <span class="text-cyan-400 font-medium counter" data-target="<?php echo !empty($thread['view_count']) ? $thread['view_count'] : '0'; ?>">
                                <?php echo !empty($thread['view_count']) ? number_format($thread['view_count']) : '0'; ?>
                            </span>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-gray-400">回复次数</span>
                            <span class="text-cyan-400 font-medium counter" data-target="<?php echo !empty($thread['reply_count']) ? $thread['reply_count'] : '0'; ?>">
                                <?php echo !empty($thread['reply_count']) ? number_format($thread['reply_count']) : '0'; ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- 相关话题 -->
                <div class="thread-card bg-black bg-opacity-70 border border-cyan-800 rounded-lg p-6 mb-6 shadow-glow-cyan neon-border" style="transition: all 0.3s ease;">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4" style="text-shadow: 0 0 5px rgba(0, 255, 255, 0.7);">相关话题</h3>
                    <div class="space-y-4">
                        <?php if (empty($relatedThreads)): ?>
                            <div class="text-center py-4 text-gray-500">
                                暂无相关话题
                            </div>
                        <?php else: ?>
                            <?php foreach ($relatedThreads as $relatedThread): ?>
                                <div class="bg-gray-900/50 border border-gray-800 rounded-lg p-3 hover:border-cyan-600 transition-all duration-300 transform hover:translate-x-1 hover:shadow-glow-cyan">
                                    <a href="/thread/show/<?php echo $relatedThread['id']; ?>" class="block">
                                        <h4 class="text-sm font-medium text-white hover:text-cyan-400 transition-colors mb-2 line-clamp-2">
                                            <?php echo htmlspecialchars($relatedThread['title']); ?>
                                        </h4>
                                        <div class="flex items-center justify-between text-xs text-gray-500">
                                            <span><i class="fas fa-comment mr-1"></i><?php echo !empty($relatedThread['reply_count']) ? $relatedThread['reply_count'] : '0'; ?></span>
                                            <span><?php echo !empty($relatedThread['created_at']) ? format_relative_time($relatedThread['created_at']) : '未知时间'; ?></span>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- 活跃用户 -->
                <div class="thread-card bg-black bg-opacity-70 border border-cyan-800 rounded-lg p-6 shadow-glow-cyan neon-border" style="transition: all 0.3s ease;">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4" style="text-shadow: 0 0 5px rgba(0, 255, 255, 0.7);">活跃用户</h3>
                    <div class="space-y-4">
                        <?php if (empty($activeUsers)): ?>
                            <div class="text-center py-4 text-gray-500">
                                暂无活跃用户
                            </div>
                        <?php else: ?>
                            <?php foreach ($activeUsers as $user): ?>
                                <div class="flex items-center gap-3 hover:bg-gray-900/30 p-2 -mx-2 rounded-lg transition-colors">
                                    <img src="https://picsum.photos/id/<?php echo !empty($user['id']) ? $user['id'] : '1'; ?>/50/50" 
                                         alt="<?php echo !empty($user['username']) ? htmlspecialchars($user['username']) : '未知用户'; ?>" 
                                         class="user-avatar w-10 h-10 rounded-full object-cover border border-gray-700">
                                    <div class="flex-1">
                                        <a href="#" class="text-white font-medium hover:text-cyan-400 transition-colors">
                                            <?php echo !empty($user['username']) ? htmlspecialchars($user['username']) : '未知用户'; ?>
                                        </a>
                                        <div class="text-xs text-gray-500">
                                            <i class="far fa-comment mr-1"></i>
                                            回复了 <span class="counter text-cyan-400" data-target="<?php echo !empty($user['reply_count']) ? $user['reply_count'] : '0'; ?>">
                                                <?php echo !empty($user['reply_count']) ? $user['reply_count'] : '0'; ?>
                                            </span> 次
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 滚动进度条
        const progressBar = document.getElementById('progressBar');
        window.addEventListener('scroll', function() {
            const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrolled = (winScroll / height) * 100;
            progressBar.style.width = scrolled + "%";
        });

        // 滚动渐入效果 - 延迟动画
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry, index) => {
                if (entry.isIntersecting) {
                    setTimeout(() => {
                        entry.target.classList.add('opacity-100', 'translate-y-0');
                        entry.target.classList.remove('opacity-0', 'translate-y-10');
                    }, index * 100); // 为每个元素添加延迟，创建交错效果
                }
            });
        }, { threshold: 0.1 });
        
        // 为所有卡片添加动画类
        document.querySelectorAll('.thread-card, .animate-fade-in').forEach((element, index) => {
            element.classList.add('opacity-0', 'translate-y-10', 'transition-all', 'duration-700', 'ease-out');
            observer.observe(element);
        });

        // 回复框字数统计
        const replyContent = document.getElementById('reply-content');
        const charCount = document.getElementById('char-count');
        
        if (replyContent && charCount) {
            replyContent.addEventListener('input', function() {
                const count = this.value.length;
                charCount.textContent = count + ' 字符';
                
                // 添加字数超出警告
                if (count > 1000) {
                    charCount.classList.add('text-red-500');
                } else {
                    charCount.classList.remove('text-red-500');
                }
            });
        }

        // 数字滚动动画
        const counters = document.querySelectorAll('.counter');
        counters.forEach(counter => {
            const target = +counter.getAttribute('data-target');
            const count = +counter.innerText.replace(/,/g, '');
            const increment = target / 100;
            
            if (count < target) {
                counter.innerText = Math.ceil(count + increment).toLocaleString();
                setTimeout(() => {
                    const observer = new IntersectionObserver((entries) => {
                        entries.forEach(entry => {
                            if (entry.isIntersecting) {
                                animateCounter(counter, target, increment);
                                observer.unobserve(counter);
                            }
                        });
                    }, { threshold: 0.5 });
                    observer.observe(counter);
                }, 500);
            }
        });
        
        function animateCounter(counter, target, increment) {
            let currentCount = +counter.innerText.replace(/,/g, '');
            if (currentCount < target) {
                counter.innerText = Math.ceil(currentCount + increment).toLocaleString();
                setTimeout(() => animateCounter(counter, target, increment), 20);
            } else {
                counter.innerText = target.toLocaleString();
            }
        }

        // 为按钮添加点击波纹效果
        const buttons = document.querySelectorAll('.btn-hover-effect');
        buttons.forEach(button => {
            button.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.width = ripple.style.height = size + 'px';
                ripple.style.left = x + 'px';
                ripple.style.top = y + 'px';
                ripple.classList.add('ripple');
                
                this.appendChild(ripple);
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
        });

        // 添加打字机效果到标题
        const glitchTitle = document.querySelector('.glitch');
        if (glitchTitle) {
            // 添加故障动画效果
            glitchTitle.classList.add('relative');
            
            // 定期触发故障效果
            setInterval(() => {
                glitchTitle.style.textShadow = 
                    `0.05em 0 0 rgba(255, 0, 0, 0.75),
                     -0.025em -0.05em 0 rgba(0, 255, 0, 0.75),
                     0.025em 0.05em 0 rgba(0, 0, 255, 0.75)`;
                glitchTitle.style.transform = 'translate(-2px, 1px)';
                
                setTimeout(() => {
                    glitchTitle.style.textShadow = '0 0 5px rgba(0, 255, 255, 0.7)';
                    glitchTitle.style.transform = 'translate(0, 0)';
                }, 150);
            }, 5000);
        }

        // 添加高亮文本动画
        const highlightTexts = document.querySelectorAll('.highlight-text');
        highlightTexts.forEach(text => {
            setInterval(() => {
                text.style.background = 'linear-gradient(transparent 70%, rgba(0, 255, 255, 0.5) 0)';
                setTimeout(() => {
                    text.style.background = 'linear-gradient(transparent 70%, rgba(0, 255, 255, 0.3) 0)';
                }, 500);
            }, 3000);
        });
    });
</script>

<?php include ROOT_PATH . '/app/views/layouts/footer.php'; ?>