<?php include ROOT_PATH . '/app/views/layouts/header.php'; ?>

<!-- 背景效果 -->
<div class="fixed inset-0 bg-black z-[-1]">
    <!-- 网格背景 -->
    <div class="absolute inset-0 bg-[radial-gradient(rgba(0,200,255,0.1)_1px,transparent_1px)] bg-[size:30px_30px] opacity-40" id="grid-bg"></div>
    
    <!-- 扫描线效果 -->
    <div class="absolute inset-0 pointer-events-none scanline"></div>
    
    <!-- 动态光效 -->
    <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 via-blue-500 to-cyan-500 opacity-30 animate-scan"></div>
    <div class="absolute top-0 right-0 h-full w-1 bg-gradient-to-b from-cyan-500 via-blue-500 to-cyan-500 opacity-30 animate-scan-vertical"></div>
</div>

<!-- 英雄区 -->
<section class="py-10 relative overflow-hidden cyberpunk-fade-in" style="animation-delay: 0.1s;">
    <div class="absolute inset-0 bg-gradient-to-b from-cyan-900/20 to-blue-900/20 z-0"></div>
    <div class="grid-grid absolute inset-0 opacity-20 z-0">
        <div class="grid-line-h"></div>
        <div class="grid-line-h"></div>
        <div class="grid-line-h"></div>
        <div class="grid-line-v"></div>
        <div class="grid-line-v"></div>
        <div class="grid-line-v"></div>
    </div>
    
    <div class="container mx-auto px-4 relative z-10">
        <div class="text-center mb-8">
            <div class="relative inline-block">
                <h1 class="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600 mb-4 shadow-glow-cyan animate-pulse-slow cyberpunk-text">
                    NEXUS论坛
                </h1>
                <span class="absolute -top-3 -right-12 text-xs text-cyan-500 bg-black/70 border border-cyan-800 px-2 py-1 rounded-full shadow-glow-cyan-sm">
                    v1.0.0
                </span>
            </div>
            <p class="text-xl text-cyan-300 max-w-2xl mx-auto cyberpunk-subtitle" id="typing-text">连接未来，探索无限可能</p>
        </div>
        
        <!-- 搜索框 -->
        <div class="max-w-2xl mx-auto mb-8">
            <form action="/search" method="get" class="relative cyberpunk-form">
                <input type="text" name="q" placeholder="搜索话题、回复或用户..." 
                       class="w-full bg-gray-900/80 border border-cyan-700 rounded-full px-6 py-4 text-gray-300 placeholder-gray-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 shadow-glow-cyan-sm transition-all duration-300 input-focus-effect">
                <button type="submit" class="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-bold rounded-full w-10 h-10 flex items-center justify-center shadow-glow-cyan hover:shadow-glow-cyan-lg transition-all duration-300">
                    <i class="fas fa-search"></i>
                </button>
            </form>
        </div>
        
        <!-- 统计数据 -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div class="bg-black/60 border border-cyan-900 rounded-lg p-4 text-center hover:border-cyan-700 transition-all duration-300 cyberpunk-card stat-card" data-value="<?php echo $stats['total_users']; ?>">
                <p class="text-3xl font-bold text-cyan-400 mb-1 counter"><?php echo number_format($stats['total_users']); ?></p>
                <p class="text-gray-400 text-sm">注册用户</p>
                <p class="text-green-500 text-xs mt-1"><i class="fas fa-arrow-up mr-1"></i><?php echo $stats['today_users']; ?> 今日新增</p>
            </div>
            <div class="bg-black/60 border border-cyan-900 rounded-lg p-4 text-center hover:border-cyan-700 transition-all duration-300 cyberpunk-card stat-card" data-value="<?php echo $stats['total_threads']; ?>">
                <p class="text-3xl font-bold text-cyan-400 mb-1 counter"><?php echo number_format($stats['total_threads']); ?></p>
                <p class="text-gray-400 text-sm">话题总数</p>
                <p class="text-green-500 text-xs mt-1"><i class="fas fa-arrow-up mr-1"></i><?php echo $stats['today_threads']; ?> 今日新增</p>
            </div>
            <div class="bg-black/60 border border-cyan-900 rounded-lg p-4 text-center hover:border-cyan-700 transition-all duration-300 cyberpunk-card stat-card" data-value="<?php echo $stats['total_replies']; ?>">
                <p class="text-3xl font-bold text-cyan-400 mb-1 counter"><?php echo number_format($stats['total_replies']); ?></p>
                <p class="text-gray-400 text-sm">回复总数</p>
                <p class="text-green-500 text-xs mt-1"><i class="fas fa-arrow-up mr-1"></i><?php echo $stats['today_replies']; ?> 今日新增</p>
            </div>
            <div class="bg-black/60 border border-cyan-900 rounded-lg p-4 text-center hover:border-cyan-700 transition-all duration-300 cyberpunk-card stat-card" data-value="<?php echo $stats['online_users']; ?>">
                <p class="text-3xl font-bold text-cyan-400 mb-1 counter"><?php echo number_format($stats['online_users']); ?></p>
                <p class="text-gray-400 text-sm">在线用户</p>
                <div class="flex justify-center mt-1">
                    <div class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 主内容区 -->
<section class="py-8">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <!-- 主要内容 -->
            <div class="lg:col-span-8">
                <!-- 版块列表 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 mb-8 shadow-glow-cyan cyberpunk-fade-in" style="animation-delay: 0.3s;">
                    <h2 class="text-2xl font-bold text-cyan-400 mb-6 flex items-center cyberpunk-heading">
                        <i class="fas fa-th-large text-cyan-500 mr-2"></i>
                        版块列表
                    </h2>
                    
                    <div class="space-y-4">
                        <?php if (!empty($forums)): ?>
                            <?php $forumDelay = 0.4; foreach ($forums as $forum): $forumDelay += 0.1; ?>
                                <a href="/forum/show/<?php echo $forum['id']; ?>" class="block bg-gray-900 border border-gray-800 rounded-lg p-4 hover:border-cyan-600 transition-all duration-300 forum-card cyberpunk-fade-in" style="animation-delay: <?php echo $forumDelay; ?>s;">
                                    <div class="flex items-start">
                                        <div class="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-500 to-blue-700 flex items-center justify-center mr-4 flex-shrink-0 shadow-glow-cyan">
                                            <i class="fas fa-comments text-black text-xl"></i>
                                        </div>
                                        <div class="flex-1">
                                            <div class="flex justify-between items-start mb-2">
                                                <h3 class="text-lg font-bold text-white hover:text-cyan-400 transition-colors forum-title">
                                                    <?php echo htmlspecialchars($forum['name']); ?>
                                                </h3>
                                                <div class="text-right">
                                                    <p class="text-gray-400 text-sm font-mono"><?php echo $forum['thread_count']; ?> 话题</p>
                                                    <p class="text-gray-400 text-sm font-mono"><?php echo $forum['reply_count']; ?> 回复</p>
                                                </div>
                                            </div>
                                            <p class="text-gray-400 text-sm mb-3">
                                                <?php echo htmlspecialchars($forum['description']); ?>
                                            </p>
                                            <?php if (!empty($forum['latest_thread'])): ?>
                                                <div class="flex items-center text-xs text-gray-500">
                                                    <span class="text-cyan-500 hover:text-cyan-400 mr-2 truncate max-w-[200px]">
                                                        <i class="fas fa-file-alt mr-1"></i>
                                                        <a href="/thread/show/<?php echo $forum['latest_thread']['id']; ?>" class="hover:underline">
                                                            <?php echo htmlspecialchars($forum['latest_thread']['title']); ?>
                                                        </a>
                                                    </span>
                                                    <span>•</span>
                                                    <span class="ml-2">
                                                        <a href="/user/profile/<?php echo $forum['latest_thread']['user_id']; ?>" class="text-cyan-500 hover:text-cyan-400 hover:underline">
                                                            <?php echo htmlspecialchars($forum['latest_thread']['author_username']); ?>
                                                        </a>
                                                    </span>
                                                    <span class="ml-2"><?php echo time_ago($forum['latest_thread']['created_at']); ?></span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-12">
                                <p class="text-gray-400">暂无版块</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- 最新回复 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 shadow-glow-cyan cyberpunk-fade-in" style="animation-delay: 0.5s;">
                    <h2 class="text-2xl font-bold text-cyan-400 mb-6 flex items-center cyberpunk-heading">
                        <i class="fas fa-comment-dots text-cyan-500 mr-2"></i>
                        最新回复
                    </h2>
                    
                    <div class="space-y-4">
                        <?php if (!empty($latestReplies)): ?>
                            <?php $replyDelay = 0.6; foreach ($latestReplies as $reply): $replyDelay += 0.1; ?>
                                <div class="bg-gray-900 border border-gray-800 rounded-lg p-4 hover:border-cyan-600 transition-all duration-300 reply-card cyberpunk-fade-in" style="animation-delay: <?php echo $replyDelay; ?>s;">
                                    <div class="flex items-center mb-3">
                                        <img src="<?php echo !empty($reply['author_avatar']) ? $reply['author_avatar'] : '/images/default_avatar.png'; ?>" alt="<?php echo htmlspecialchars($reply['author_username']); ?>" class="w-8 h-8 rounded-full border border-cyan-600 mr-3 hover:border-cyan-400 transition-colors">
                                        <div>
                                            <p class="text-cyan-400 font-medium text-sm"><?php echo htmlspecialchars($reply['author_username']); ?></p>
                                            <p class="text-gray-500 text-xs">回复于 <?php echo time_ago($reply['created_at']); ?></p>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <p class="text-gray-300 text-sm mb-2 cyberpunk-text">
                                            <?php 
                                            // 截断过长的回复内容
                                            $content = strip_tags($reply['content']);
                                            if (strlen($content) > 150) {
                                                $content = substr($content, 0, 150) . '...';
                                            }
                                            echo htmlspecialchars($content);
                                            ?>
                                        </p>
                                        <a href="/thread/show/<?php echo $reply['thread_id']; ?>#reply-<?php echo $reply['id']; ?>" class="text-cyan-500 hover:text-cyan-400 text-sm inline-flex items-center px-3 py-1 rounded bg-cyan-900/30 hover:bg-cyan-900/50 transition-all duration-300">
                                            <i class="fas fa-external-link-alt mr-1"></i> 查看话题
                                        </a>
                                    </div>
                                    <div class="text-xs text-gray-500">
                                        <a href="/thread/show/<?php echo $reply['thread_id']; ?>" class="text-gray-400 hover:text-cyan-400">
                                            回复了: "<?php echo htmlspecialchars($reply['thread_title']); ?>"
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-12">
                                <p class="text-gray-400">暂无回复</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- 侧边栏 -->
            <div class="lg:col-span-4">
                <!-- 热门话题 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 mb-8 shadow-glow-cyan cyberpunk-fade-in" style="animation-delay: 0.7s;">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4 flex items-center cyberpunk-heading">
                        <i class="fas fa-fire text-red-500 mr-2"></i> 热门话题
                    </h3>
                    <div class="space-y-4">
                        <?php if (!empty($hotThreads)): ?>
                            <?php $hotDelay = 0.8; foreach ($hotThreads as $index => $thread): $hotDelay += 0.1; ?>
                                <a href="/thread/show/<?php echo $thread['id']; ?>" class="block bg-gray-900 border border-gray-800 rounded-lg p-3 hover:border-cyan-600 transition-all duration-300 hot-thread-card cyberpunk-fade-in" style="animation-delay: <?php echo $hotDelay; ?>s;">
                                    <span class="absolute top-0 left-0 w-6 h-6 flex items-center justify-center bg-cyan-900 text-cyan-300 font-bold text-xs rounded-bl-lg rounded-tr-lg">
                                        <?php echo $index + 1; ?>
                                    </span>
                                    <div class="pl-6">
                                        <p class="text-gray-300 text-sm font-medium mb-1 line-clamp-2 hover:text-cyan-400 transition-colors thread-title">
                                            <?php echo htmlspecialchars($thread['title']); ?>
                                        </p>
                                        <div class="flex justify-between items-center text-xs text-gray-500">
                                            <span><i class="fas fa-eye mr-1"></i><?php echo $thread['view_count']; ?></span>
                                            <span><i class="fas fa-comment mr-1"></i><?php echo $thread['reply_count']; ?></span>
                                            <span class="text-yellow-500"><i class="fas fa-star mr-1"></i><?php echo $thread['likes_count']; ?></span>
                                        </div>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-gray-500 text-sm text-center py-4">暂无热门话题</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- 最新话题 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 mb-8 shadow-glow-cyan cyberpunk-fade-in" style="animation-delay: 0.9s;">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4 flex items-center cyberpunk-heading">
                        <i class="fas fa-clock text-blue-500 mr-2"></i> 最新话题
                    </h3>
                    <div class="space-y-3">
                        <?php if (!empty($latestThreads)): ?>
                            <?php $latestDelay = 1.0; foreach ($latestThreads as $thread): $latestDelay += 0.1; ?>
                                <a href="/thread/show/<?php echo $thread['id']; ?>" class="block p-2 hover:bg-gray-900 rounded-lg transition-colors latest-thread-item cyberpunk-fade-in" style="animation-delay: <?php echo $latestDelay; ?>s;">
                                    <p class="text-gray-300 text-sm mb-1 line-clamp-1 hover:text-cyan-400 transition-colors thread-title">
                                        <?php echo htmlspecialchars($thread['title']); ?>
                                    </p>
                                    <div class="flex justify-between items-center">
                                        <span class="text-gray-500 text-xs">
                                            <a href="/user/profile/<?php echo $thread['user_id']; ?>" class="hover:text-cyan-400">
                                                <?php echo htmlspecialchars($thread['author_username']); ?>
                                            </a>
                                        </span>
                                        <span class="text-gray-500 text-xs"><?php echo time_ago($thread['created_at']); ?></span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-gray-500 text-sm text-center py-4">暂无最新话题</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- 论坛统计 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 shadow-glow-cyan cyberpunk-fade-in" style="animation-delay: 1.1s;">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4 flex items-center cyberpunk-heading">
                        <i class="fas fa-chart-line text-cyan-500 mr-2"></i> 论坛统计
                    </h3>
                    <div class="space-y-4">
                        <div class="flex justify-between items-center stat-item">
                            <span class="text-gray-400">总用户数</span>
                            <span class="text-cyan-400 font-mono counter" data-value="<?php echo $stats['total_users']; ?>"><?php echo number_format($stats['total_users']); ?></span>
                        </div>
                        <div class="flex justify-between items-center stat-item">
                            <span class="text-gray-400">总话题数</span>
                            <span class="text-cyan-400 font-mono counter" data-value="<?php echo $stats['total_threads']; ?>"><?php echo number_format($stats['total_threads']); ?></span>
                        </div>
                        <div class="flex justify-between items-center stat-item">
                            <span class="text-gray-400">总回复数</span>
                            <span class="text-cyan-400 font-mono counter" data-value="<?php echo $stats['total_replies']; ?>"><?php echo number_format($stats['total_replies']); ?></span>
                        </div>
                        <div class="flex justify-between items-center stat-item">
                            <span class="text-gray-400">在线用户</span>
                            <span class="text-green-500 font-mono counter" data-value="<?php echo $stats['online_users']; ?>"><?php echo number_format($stats['online_users']); ?></span>
                        </div>
                        <div class="pt-4 border-t border-gray-800">
                            <p class="text-gray-400 text-sm mb-2">今日新增</p>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-500 text-xs">用户: +<?php echo $stats['today_users']; ?></span>
                                <span class="text-gray-500 text-xs">话题: +<?php echo $stats['today_threads']; ?></span>
                                <span class="text-gray-500 text-xs">回复: +<?php echo $stats['today_replies']; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 页面加载动画
        const body = document.body;
        body.classList.add('loaded');
        
        // 打字机效果
        const typingText = document.getElementById('typing-text');
        if (typingText) {
            const text = typingText.textContent;
            typingText.textContent = '';
            let index = 0;
            
            function type() {
                if (index < text.length) {
                    typingText.textContent += text.charAt(index);
                    index++;
                    setTimeout(type, Math.random() * 50 + 30);
                }
            }
            
            setTimeout(type, 1000);
        }
        
        // 数字滚动动画
        const counters = document.querySelectorAll('.counter');
        counters.forEach(counter => {
            const target = parseInt(counter.getAttribute('data-value'));
            const duration = 2000; // 2秒
            const step = target / (duration / 16); // 60fps
            let current = 0;
            
            const updateCounter = () => {
                current += step;
                if (current < target) {
                    counter.textContent = Math.floor(current).toLocaleString();
                    requestAnimationFrame(updateCounter);
                } else {
                    counter.textContent = target.toLocaleString();
                }
            };
            
            // 当元素进入视口时开始动画
            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        updateCounter();
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1 });
            
            observer.observe(counter);
        });
        
        // 版块卡片悬停效果增强
        const forumCards = document.querySelectorAll('.forum-card');
        forumCards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.classList.add('transform', 'translate-y-[-5px]', 'transition-transform', 'duration-300');
                this.classList.add('border-cyan-600');
                // 增加发光效果
                this.style.boxShadow = '0 0 15px rgba(6, 182, 212, 0.5)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.classList.remove('transform', 'translate-y-[-5px]', 'transition-transform', 'duration-300');
                this.classList.remove('border-cyan-600');
                this.style.boxShadow = '';
            });
        });
        
        // 回复卡片悬停效果
        const replyCards = document.querySelectorAll('.reply-card');
        replyCards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.classList.add('border-cyan-600');
                this.style.boxShadow = '0 0 10px rgba(6, 182, 212, 0.3)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.classList.remove('border-cyan-600');
                this.style.boxShadow = '';
            });
        });
        
        // 热门话题卡片悬停效果
        const hotThreadCards = document.querySelectorAll('.hot-thread-card');
        hotThreadCards.forEach(card => {
            card.style.position = 'relative'; // 确保绝对定位的排名标记正常工作
            
            card.addEventListener('mouseenter', function() {
                this.classList.add('border-cyan-600');
                this.style.boxShadow = '0 0 8px rgba(6, 182, 212, 0.4)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.classList.remove('border-cyan-600');
                this.style.boxShadow = '';
            });
        });
        
        // 最新话题项目悬停效果
        const latestThreadItems = document.querySelectorAll('.latest-thread-item');
        latestThreadItems.forEach(item => {
            item.addEventListener('mouseenter', function() {
                this.style.backgroundColor = 'rgba(17, 24, 39, 0.8)';
                this.style.borderLeft = '3px solid #06b6d4';
            });
            
            item.addEventListener('mouseleave', function() {
                this.style.backgroundColor = '';
                this.style.borderLeft = '';
            });
        });
        
        // 表单输入效果
        const formInputs = document.querySelectorAll('input, textarea');
        formInputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.classList.add('border-cyan-400');
                this.style.boxShadow = '0 0 10px rgba(6, 182, 212, 0.5)';
            });
            
            input.addEventListener('blur', function() {
                this.classList.remove('border-cyan-400');
                this.style.boxShadow = '';
            });
        });
        
        // 平滑滚动
        document.querySelectorAll('a[href^="/"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                
                // 对于包含锚点的链接，使用平滑滚动
                if (href.includes('#') && href.indexOf('#') > 0) {
                    const [path, hash] = href.split('#');
                    
                    // 首先检查是否是同一页面
                    if (window.location.pathname === path) {
                        e.preventDefault();
                        const target = document.getElementById(hash);
                        if (target) {
                            target.scrollIntoView({ behavior: 'smooth' });
                        }
                    }
                }
                // 对于普通链接，不阻止默认行为
            });
        });
        
        // 动态背景网格动画
        const gridBg = document.getElementById('grid-bg');
        if (gridBg) {
            let position = 0;
            setInterval(() => {
                position += 0.5;
                gridBg.style.backgroundPosition = `${position}px ${position}px`;
            }, 50);
        }
        
        // 为统计项添加悬停效果
        const statItems = document.querySelectorAll('.stat-item');
        statItems.forEach(item => {
            item.addEventListener('mouseenter', function() {
                this.querySelectorAll('span')[1].classList.add('text-cyan-300');
                this.style.backgroundColor = 'rgba(8, 47, 57, 0.3)';
            });
            
            item.addEventListener('mouseleave', function() {
                this.querySelectorAll('span')[1].classList.remove('text-cyan-300');
                this.style.backgroundColor = '';
            });
        });
    });
</script>

<?php include ROOT_PATH . '/app/views/layouts/footer.php'; ?>