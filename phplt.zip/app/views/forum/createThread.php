<?php
/**
 * 创建话题视图
 */
?>
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="cyber-card">
                <div class="cyber-card-header">
                    <h2 class="cyber-title">发布新话题</h2>
                    <p class="cyber-text-light">在版块 <span class="cyber-text-glow"><?= $forum['name'] ?></span> 中发布新话题</p>
                </div>
                <div class="cyber-card-body">
                    <form action="/forum/doCreateThread/<?= $forum['id'] ?>" method="post" class="cyber-form">
                        <div class="form-group">
                            <label for="title" class="cyber-label">话题标题</label>
                            <input type="text" id="title" name="title" class="cyber-input" placeholder="请输入话题标题" required>
                            <small class="cyber-text-light">标题长度应在3-50个字符之间</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="content" class="cyber-label">话题内容</label>
                            <textarea id="content" name="content" class="cyber-textarea" rows="10" placeholder="请详细描述您的话题内容" required></textarea>
                            <small class="cyber-text-light">内容不能少于10个字符</small>
                        </div>
                        
                        <div class="form-group">
                            <label class="cyber-label">话题标签</label>
                            <input type="text" id="tags" name="tags" class="cyber-input" placeholder="请输入标签，用逗号分隔（可选）">
                            <small class="cyber-text-light">添加相关标签可以让更多用户找到您的话题</small>
                        </div>
                        
                        <div class="form-group">
                            <div class="form-check cyber-checkbox">
                                <input type="checkbox" id="anonymous" name="anonymous" class="cyber-checkbox-input">
                                <label for="anonymous" class="cyber-checkbox-label">匿名发布</label>
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="cyber-button cyber-button-primary">
                                <i class="fas fa-paper-plane"></i> 发布话题
                            </button>
                            <a href="/forum/show/<?= $forum['id'] ?>" class="cyber-button cyber-button-secondary">
                                <i class="fas fa-arrow-left"></i> 返回版块
                            </a>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- 发布须知 -->
            <div class="cyber-card mt-4">
                <div class="cyber-card-header">
                    <h3 class="cyber-subtitle">发布须知</h3>
                </div>
                <div class="cyber-card-body">
                    <ul class="cyber-list cyber-text-light">
                        <li><i class="fas fa-info-circle"></i> 请遵守社区规则，发布符合版块主题的内容</li>
                        <li><i class="fas fa-info-circle"></i> 禁止发布广告、垃圾信息及违规内容</li>
                        <li><i class="fas fa-info-circle"></i> 尊重他人，文明发言</li>
                        <li><i class="fas fa-info-circle"></i> 发布原创内容，尊重知识产权</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>