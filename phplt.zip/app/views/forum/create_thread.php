<?php include ROOT_PATH . '/app/views/layouts/header.php'; ?>

<section class="py-8">
    <div class="container mx-auto px-4">
        <div class="max-w-3xl mx-auto">
            <!-- 页面标题 -->
            <div class="bg-black bg-opacity-60 border border-cyan-500 rounded-lg p-6 mb-8 shadow-glow-cyan">
                <h1 class="text-3xl font-bold text-cyan-400 mb-2">发布话题</h1>
                <p class="text-gray-300">在版块 <span class="text-cyan-400"><?php echo htmlspecialchars($forum['name']); ?></span> 中发布新话题</p>
            </div>

            <!-- 错误/成功消息 -->
            <?php if (isset($_SESSION['error'])): ?>
                <div class="bg-black bg-opacity-60 border border-red-500 rounded-lg p-4 mb-6 text-red-400">
                    <i class="fas fa-exclamation-circle mr-2"></i><?php echo $_SESSION['error']; ?>
                    <?php unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="bg-black bg-opacity-60 border border-green-500 rounded-lg p-4 mb-6 text-green-400">
                    <i class="fas fa-check-circle mr-2"></i><?php echo $_SESSION['success']; ?>
                    <?php unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>

            <!-- 发布话题表单 -->
            <form action="/forum/doCreateThread" method="post" class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 forum-form">
                <input type="hidden" name="forum_id" value="<?php echo $forum['id']; ?>">
                
                <!-- 标题输入 -->
                <div class="mb-6">
                    <label for="title" class="block text-gray-300 font-bold mb-2 text-cyan-400">话题标题</label>
                    <input type="text" id="title" name="title" placeholder="请输入话题标题（5-100个字符）" 
                           class="w-full bg-gray-900 border border-cyan-700 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all duration-300"
                           maxlength="100">
                    <p class="text-gray-500 text-xs mt-1">标题长度应在5-100个字符之间</p>
                </div>

                <!-- 内容输入 -->
                <div class="mb-6">
                    <label for="content" class="block text-gray-300 font-bold mb-2 text-cyan-400">话题内容</label>
                    <textarea id="content" name="content" rows="12" placeholder="请输入话题内容（至少10个字符）" 
                              class="w-full bg-gray-900 border border-cyan-700 rounded-lg px-4 py-3 text-gray-300 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all duration-300 resize-none"></textarea>
                    <p class="text-gray-500 text-xs mt-1">内容长度至少为10个字符</p>
                </div>

                <!-- 操作按钮 -->
                <div class="flex justify-between items-center">
                    <a href="/forum/show/<?php echo $forum['id']; ?>" class="px-6 py-3 bg-gray-800 border border-gray-700 rounded-lg text-gray-300 hover:bg-gray-700 transition-colors duration-300">
                        <i class="fas fa-arrow-left mr-2"></i> 返回版块
                    </a>
                    <button type="submit" class="px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-bold rounded-lg hover:from-cyan-400 hover:to-blue-500 transition-all duration-300 transform hover:-translate-y-1 shadow-glow-cyan submit-btn">
                        <i class="fas fa-paper-plane mr-2"></i> 发布话题
                    </button>
                </div>
            </form>
        </div>
    </div>
</section>

<script>
    // 表单提交动画
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.querySelector('.forum-form');
        const submitBtn = document.querySelector('.submit-btn');
        
        form.addEventListener('submit', function(e) {
            // 简单的表单验证
            const title = document.getElementById('title').value.trim();
            const content = document.getElementById('content').value.trim();
            
            if (!title || !content) {
                return; // 让PHP端处理错误提示
            }
            
            // 添加提交动画
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> 发布中...';
        });
    });
</script>

<?php include ROOT_PATH . '/app/views/layouts/footer.php'; ?>