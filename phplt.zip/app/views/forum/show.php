<?php include ROOT_PATH . '/app/views/layouts/header.php'; ?>

<!-- 动态网格背景 -->
<div class="fixed inset-0 bg-grid-cyan opacity-10 z-[-2]"></div>
<div class="fixed inset-0 bg-black z-[-3]"></div>
<div class="scanlines absolute inset-0 z-[-1] pointer-events-none"></div>

<!-- 版块详情页 -->
<section class="py-8">
    <div class="container mx-auto px-4">
        <!-- 版块面包屑和标题 -->
        <div class="mb-6 cyberpunk-card animate-fade-in" style="animation-delay: 0.1s">
            <nav class="flex text-sm" aria-label="Breadcrumb">
                <ol class="inline-flex items-center space-x-1 md:space-x-3">
                    <li class="inline-flex items-center">
                        <a href="/" class="text-gray-400 hover:text-cyan-400 transition-colors">
                            <i class="fas fa-home mr-2"></i>首页
                        </a>
                    </li>
                    <li>
                        <div class="flex items-center">
                            <i class="fas fa-chevron-right text-gray-600 mx-2 text-xs"></i>
                            <span class="text-cyan-400 font-medium cyberpunk-text"><?php echo htmlspecialchars($forum['name']); ?></span>
                        </div>
                    </li>
                </ol>
            </nav>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <!-- 主要内容区 -->
            <div class="lg:col-span-8">
                <!-- 版块信息卡片 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 mb-6 shadow-glow-cyan cyberpunk-card animate-fade-in neon-border" style="animation-delay: 0.2s">
                    <div class="flex items-start mb-6">
                        <div class="w-16 h-16 rounded-lg bg-gradient-to-br from-cyan-900 to-blue-900 flex items-center justify-center mr-6 flex-shrink-0 cyberpunk-icon">
                            <i class="fas fa-hashtag text-3xl text-cyan-400"></i>
                        </div>
                        <div>
                            <h1 class="text-3xl font-bold text-white mb-2 cyberpunk-title">
                                <?php echo htmlspecialchars($forum['name']); ?>
                                <?php if (!empty($forum['is_private']) && $forum['is_private']): ?>
                                    <span class="text-sm text-purple-400 bg-purple-900/30 px-2 py-1 rounded-full ml-2 border border-purple-700">
                                        <i class="fas fa-lock mr-1"></i>私有版块
                                    </span>
                                <?php endif; ?>
                            </h1>
                            <p class="text-gray-400 mb-3"><?php echo htmlspecialchars($forum['description']); ?></p>
                            <div class="flex flex-wrap gap-4 text-sm">
                                <div class="flex items-center text-cyan-400">
                                    <i class="fas fa-file-alt mr-1"></i> 
                                    <span class="stats-counter"><?php echo isset($forum['thread_count']) ? $forum['thread_count'] : '0'; ?></span> 话题
                                </div>
                                <div class="flex items-center text-blue-400">
                                    <i class="fas fa-comment mr-1"></i>
                                    <span class="stats-counter"><?php echo isset($forum['reply_count']) ? $forum['reply_count'] : '0'; ?></span> 回复
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 操作按钮 -->
                    <div class="flex flex-wrap gap-3">
                        <a href="/forum/createThread/<?php echo $forum['id']; ?>" 
                           class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 text-black font-bold rounded-lg shadow-glow-cyan hover:from-cyan-500 hover:to-blue-500 transition-colors cyber-button">
                            <i class="fas fa-plus-circle mr-2"></i>发布新话题
                        </a>
                        
                        <!-- 排序和筛选 -->
                        <div class="ml-auto flex items-center gap-4">
                            <div class="relative">
                                <select class="bg-gray-900 border border-cyan-800 text-gray-300 rounded-lg pl-4 pr-10 py-2 appearance-none focus:outline-none focus:ring-1 focus:ring-cyan-400 focus:border-cyan-400 cyber-input" 
                                        onchange="location.href = '/forum/show/<?php echo $forum['id']; ?>?sort=' + this.value;">
                                    <option value="latest" <?php echo $sortBy == 'latest' ? 'selected' : ''; ?>>最新发布</option>
                                    <option value="hottest" <?php echo $sortBy == 'hottest' ? 'selected' : ''; ?>>最热话题</option>
                                    <option value="popular" <?php echo $sortBy == 'popular' ? 'selected' : ''; ?>>最受欢迎</option>
                                </select>
                                <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                                    <i class="fas fa-chevron-down text-gray-500 text-xs"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 话题列表 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg overflow-hidden shadow-glow-cyan cyberpunk-card animate-fade-in neon-border" style="animation-delay: 0.3s">
                    <!-- 列表头部 -->
                    <div class="hidden md:flex items-center px-6 py-3 border-b border-cyan-800 bg-gray-900/50 text-sm">
                        <div class="w-1/2 font-medium text-cyan-400">话题</div>
                        <div class="w-1/6 font-medium text-cyan-400 text-center">作者</div>
                        <div class="w-1/6 font-medium text-cyan-400 text-center">回复</div>
                        <div class="w-1/6 font-medium text-cyan-400 text-right">最后回复</div>
                    </div>

                    <!-- 话题列表项 -->
                    <div class="divide-y divide-gray-800">
                        <?php if (empty($threads['data'])): ?>
                            <!-- 空状态 -->
                            <div class="px-6 py-12 text-center">
                                <i class="fas fa-folder-open text-gray-700 text-5xl mb-4"></i>
                                <h3 class="text-xl font-semibold text-gray-400 mb-2">暂无话题</h3>
                                <p class="text-gray-500 mb-6">成为第一个在该版块发布话题的用户！</p>
                                <a href="/forum/createThread/<?php echo $forum['id']; ?>" 
                                   class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 text-black font-bold rounded-lg shadow-glow-cyan hover:from-cyan-500 hover:to-blue-500 transition-colors cyber-button">
                                    <i class="fas fa-plus-circle mr-2"></i>发布第一个话题
                                </a>
                            </div>
                        <?php else: ?>
                            <?php foreach ($threads['data'] as $index => $thread): ?>
                                <div class="hover:bg-gray-900/30 transition-colors thread-item" data-index="<?php echo $index; ?>">
                                    <a href="/thread/show/<?php echo $thread['id']; ?>" class="block px-6 py-4">
                                        <div class="md:hidden flex items-start gap-4 mb-2">
                                            <div class="flex-1">
                                                <h3 class="font-semibold text-white hover:text-cyan-400 transition-colors line-clamp-1">
                                                    <?php if (!empty($thread['is_pinned']) && $thread['is_pinned']): ?>
                                                        <i class="fas fa-thumbtack text-yellow-500 mr-1"></i>
                                                    <?php endif; ?>
                                                    <?php if (!empty($thread['is_locked']) && $thread['is_locked']): ?>
                                                        <i class="fas fa-lock text-gray-500 mr-1"></i>
                                                    <?php endif; ?>
                                                    <?php echo htmlspecialchars($thread['title']); ?>
                                                </h3>
                                                <div class="flex items-center mt-2 text-xs text-gray-500">
                                                    <span class="mr-3">作者: <span class="text-cyan-400"><?php echo !empty($thread['author']) ? htmlspecialchars($thread['author']) : '未知用户'; ?></span></span>
                                                    <span class="mr-3"><i class="fas fa-comment mr-1"></i><?php echo !empty($thread['reply_count']) ? $thread['reply_count'] : '0'; ?></span>
                                                    <span><?php echo !empty($thread['created_at']) ? format_relative_time($thread['created_at']) : '未知时间'; ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="hidden md:flex items-center justify-between">
                                            <div class="w-1/2">
                                                <h3 class="font-semibold text-white hover:text-cyan-400 transition-colors">
                                                    <?php if (!empty($thread['is_pinned']) && $thread['is_pinned']): ?>
                                                        <i class="fas fa-thumbtack text-yellow-500 mr-1"></i>
                                                    <?php endif; ?>
                                                    <?php if (!empty($thread['is_locked']) && $thread['is_locked']): ?>
                                                        <i class="fas fa-lock text-gray-500 mr-1"></i>
                                                    <?php endif; ?>
                                                    <?php echo htmlspecialchars($thread['title']); ?>
                                                </h3>
                                                <p class="text-xs text-gray-500 mt-1 line-clamp-1">
                                                    <?php echo !empty($thread['content']) ? htmlspecialchars(mb_substr(strip_tags($thread['content']), 0, 100, 'UTF-8')) . '...' : ''; ?>
                                                </p>
                                            </div>
                                            <div class="w-1/6 text-center">
                                                <a href="#" class="text-cyan-400 hover:underline hover:shadow-glow-cyan-sm transition-all duration-300">
                                                    <?php echo !empty($thread['author']) ? htmlspecialchars($thread['author']) : '未知用户'; ?>
                                                </a>
                                            </div>
                                            <div class="w-1/6 text-center">
                                                <span class="text-gray-400">
                                                    <i class="fas fa-comment mr-1"></i><?php echo !empty($thread['reply_count']) ? $thread['reply_count'] : '0'; ?>
                                                </span>
                                            </div>
                                            <div class="w-1/6 text-right">
                                                <div class="text-xs text-gray-500">
                                                    <?php echo !empty($thread['last_reply_at']) ? format_relative_time($thread['last_reply_at']) : '未知时间'; ?>
                                                </div>
                                                <div class="text-xs text-cyan-400 mt-1">
                                                    <?php echo !empty($thread['last_reply_author']) ? htmlspecialchars($thread['last_reply_author']) : '暂无回复'; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <!-- 分页 -->
                    <?php if (!empty($threads['pages']) && $threads['pages'] > 1): ?>
                    <div class="px-6 py-4 border-t border-cyan-800 bg-gray-900/30">
                        <div class="flex items-center justify-between">
                            <div class="text-sm text-gray-400">
                                显示 <span class="text-cyan-400"><?php echo isset($threads['start_item']) ? $threads['start_item'] : '1'; ?>-<?php echo isset($threads['end_item']) ? $threads['end_item'] : $threads['pages']; ?></span> 条，共 <span class="text-cyan-400"><?php echo isset($threads['total_items']) ? $threads['total_items'] : ($threads['pages'] * 20); ?></span> 条
                            </div>
                            <div class="flex items-center space-x-1">
                                <a href="/forum/show/<?php echo $forum['id']; ?>?sort=<?php echo $sortBy; ?>&page=<?php echo $page - 1; ?>" 
                                   class="px-3 py-1 rounded-md text-sm transition-colors duration-200
                                          <?php if ($page == 1): ?>
                                          text-gray-700 cursor-not-allowed
                                          <?php else: ?>
                                          text-gray-400 hover:text-white hover:bg-gray-800 hover:border hover:border-cyan-800
                                          <?php endif; ?>">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                                
                                <?php for ($i = 1; $i <= $threads['pages']; $i++): ?>
                                    <a href="/forum/show/<?php echo $forum['id']; ?>?sort=<?php echo $sortBy; ?>&page=<?php echo $i; ?>" 
                                       class="px-3 py-1 rounded-md text-sm transition-all duration-300
                                              <?php if ($i == $page): ?>
                                              bg-cyan-800 text-cyan-400 font-medium shadow-glow-cyan-sm
                                              <?php else: ?>
                                              text-gray-400 hover:text-white hover:bg-gray-800 hover:border hover:border-cyan-800
                                              <?php endif; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                <?php endfor; ?>
                                
                                <a href="/forum/show/<?php echo $forum['id']; ?>?sort=<?php echo $sortBy; ?>&page=<?php echo $page + 1; ?>" 
                                   class="px-3 py-1 rounded-md text-sm transition-colors duration-200
                                          <?php if ($page == $threads['pages']): ?>
                                          text-gray-700 cursor-not-allowed
                                          <?php else: ?>
                                          text-gray-400 hover:text-white hover:bg-gray-800 hover:border hover:border-cyan-800
                                          <?php endif; ?>">
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- 侧边栏 -->
            <div class="lg:col-span-4">
                <!-- 版块统计 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 mb-6 shadow-glow-cyan cyberpunk-card animate-fade-in neon-border" style="animation-delay: 0.4s">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4 cyberpunk-title">版块统计</h3>
                    <div class="space-y-4">
                        <div class="flex items-center justify-between pb-3 border-b border-gray-800">
                            <span class="text-gray-400">创建时间</span>
                            <span class="text-white font-medium">
                                <?php echo !empty($forum['created_at']) ? date('Y-m-d', strtotime($forum['created_at'])) : '未知'; ?>
                            </span>
                        </div>
                        <div class="flex items-center justify-between pb-3 border-b border-gray-800">
                            <span class="text-gray-400">今日新帖</span>
                            <span class="text-cyan-400 font-medium stats-counter">
                                <?php echo isset($forum['today_threads']) ? $forum['today_threads'] : '0'; ?>
                            </span>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-gray-400">今日回复</span>
                            <span class="text-cyan-400 font-medium stats-counter">
                                <?php echo isset($forum['today_replies']) ? $forum['today_replies'] : '0'; ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- 最新话题 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 mb-6 shadow-glow-cyan cyberpunk-card animate-fade-in neon-border" style="animation-delay: 0.5s">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4 cyberpunk-title">最新话题</h3>
                    <div class="space-y-4">
                        <?php if (empty($latestThreads)): ?>
                            <div class="text-center py-4 text-gray-500">
                                暂无话题
                            </div>
                        <?php else: ?>
                            <?php foreach ($latestThreads as $index => $thread): ?>
                                <div class="bg-gray-900/50 border border-gray-800 rounded-lg p-3 hover:border-cyan-600 transition-all duration-300 hover:shadow-glow-cyan-sm hover:-translate-y-1 side-thread" style="animation-delay: <?php echo 0.6 + ($index * 0.1); ?>s">
                                    <a href="/thread/show/<?php echo $thread['id']; ?>" class="block">
                                        <h4 class="text-sm font-medium text-white hover:text-cyan-400 transition-colors mb-2 line-clamp-2">
                                            <?php if (!empty($thread['is_pinned']) && $thread['is_pinned']): ?>
                                                <i class="fas fa-thumbtack text-yellow-500 mr-1"></i>
                                            <?php endif; ?>
                                            <?php echo htmlspecialchars($thread['title']); ?>
                                        </h4>
                                        <div class="flex items-center justify-between text-xs text-gray-500">
                                            <span><i class="fas fa-comment mr-1"></i><?php echo !empty($thread['reply_count']) ? $thread['reply_count'] : '0'; ?></span>
                                            <span><?php echo !empty($thread['created_at']) ? format_relative_time($thread['created_at']) : '未知时间'; ?></span>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- 热门话题 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 shadow-glow-cyan cyberpunk-card animate-fade-in neon-border" style="animation-delay: 0.6s">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4 cyberpunk-title">热门话题</h3>
                    <div class="space-y-4">
                        <?php if (empty($hotThreads)): ?>
                            <div class="text-center py-4 text-gray-500">
                                暂无热门话题
                            </div>
                        <?php else: ?>
                            <?php foreach ($hotThreads as $index => $thread): ?>
                                <div class="bg-gray-900/50 border border-gray-800 rounded-lg p-3 hover:border-cyan-600 transition-all duration-300 hover:shadow-glow-cyan-sm hover:-translate-y-1 hot-thread" style="animation-delay: <?php echo 0.7 + ($index * 0.1); ?>s">
                                    <a href="/thread/show/<?php echo $thread['id']; ?>" class="block">
                                        <h4 class="text-sm font-medium text-white hover:text-cyan-400 transition-colors mb-2 line-clamp-2">
                                            <?php echo htmlspecialchars($thread['title']); ?>
                                        </h4>
                                        <div class="flex items-center justify-between text-xs text-gray-500">
                                            <span class="text-yellow-500 shadow-glow-yellow-sm"><i class="fas fa-fire mr-1"></i>热门</span>
                                            <span><?php echo !empty($thread['created_at']) ? format_relative_time($thread['created_at']) : '未知时间'; ?></span>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 装饰性元素 -->
<div class="cyberpunk-element fixed bottom-0 left-0 w-full h-32 pointer-events-none z-[-1]">
    <div class="scanline"></div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 动态背景网格动画
        const createGrid = () => {
            const grid = document.createElement('div');
            grid.className = 'bg-grid-cyan';
            let html = '';
            for (let i = 0; i < 50; i++) {
                html += '<div class="absolute h-[1px] bg-cyan-500/20" style="top:' + (i * 2) + 'vh; left:0; right:0;"></div>';
            }
            for (let i = 0; i < 50; i++) {
                html += '<div class="absolute w-[1px] bg-cyan-500/20" style="left:' + (i * 2) + 'vw; top:0; bottom:0;"></div>';
            }
            grid.innerHTML = html;
            document.querySelector('.fixed.inset-0.bg-grid-cyan').appendChild(grid);
        };
        createGrid();
        
        // 扫描线效果
        const createScanlines = () => {
            const scanlines = document.querySelector('.scanlines');
            let html = '';
            for (let i = 0; i < 50; i++) {
                html += '<div class="absolute h-[1px] bg-cyan-500/10" style="top:' + (i * 2) + 'vh; left:0; right:0; animation: scanline 6s linear infinite;"></div>';
            }
            scanlines.innerHTML = html;
        };
        createScanlines();
        
        // 添加扫描线动画样式
        const style = document.createElement('style');
        style.innerHTML = `
            @keyframes scanline {
                0% { opacity: 0.1; }
                50% { opacity: 0.2; }
                100% { opacity: 0.1; }
            }
            @keyframes glitch {
                0% { transform: translate(0); }
                20% { transform: translate(-2px, 2px); }
                40% { transform: translate(-2px, -2px); }
                60% { transform: translate(2px, 2px); }
                80% { transform: translate(2px, -2px); }
                100% { transform: translate(0); }
            }
            @keyframes fadeInUp {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }
            .animate-fade-in {
                animation: fadeInUp 0.8s ease forwards;
                opacity: 0;
            }
            .ripple {
                position: absolute;
                border-radius: 50%;
                background-color: rgba(255, 255, 255, 0.3);
                transform: scale(0);
                animation: ripple 0.6s linear;
                pointer-events: none;
            }
            @keyframes ripple {
                to { transform: scale(4); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
        
        // 话题卡片悬停动画
        const threadItems = document.querySelectorAll('.thread-item');
        threadItems.forEach((item, index) => {
            item.style.animationDelay = `${0.3 + (index * 0.05)}s`;
            item.classList.add('animate-fade-in');
            
            item.addEventListener('mouseenter', function() {
                this.style.transform = 'translateX(4px)';
                this.style.transition = 'transform 0.2s ease, border-color 0.3s ease';
                this.style.borderLeft = '3px solid #06b6d4';
            });
            
            item.addEventListener('mouseleave', function() {
                this.style.transform = 'translateX(0)';
                this.style.borderLeft = '3px solid transparent';
            });
        });

        // 侧边栏话题动画
        document.querySelectorAll('.side-thread, .hot-thread').forEach(item => {
            item.classList.add('animate-fade-in');
        });

        // 数字滚动动画
        const animateCounters = () => {
            const counters = document.querySelectorAll('.stats-counter');
            counters.forEach(counter => {
                const target = parseInt(counter.innerText.replace(/,/g, ''));
                let count = 0;
                const duration = 1500; // 1.5秒
                const step = target / (duration / 16);
                
                const updateCount = () => {
                    count += step;
                    if (count < target) {
                        counter.innerText = Math.floor(count).toLocaleString();
                        requestAnimationFrame(updateCount);
                    } else {
                        counter.innerText = target.toLocaleString();
                    }
                };
                
                updateCount();
            });
        };
        
        // 按钮点击波纹效果
        const addRippleEffect = () => {
            const buttons = document.querySelectorAll('.cyber-button');
            buttons.forEach(button => {
                button.addEventListener('click', function(e) {
                    const ripple = document.createElement('span');
                    const rect = this.getBoundingClientRect();
                    const size = Math.max(rect.width, rect.height);
                    const x = e.clientX - rect.left - size / 2;
                    const y = e.clientY - rect.top - size / 2;
                    
                    ripple.style.width = ripple.style.height = size + 'px';
                    ripple.style.left = x + 'px';
                    ripple.style.top = y + 'px';
                    ripple.classList.add('ripple');
                    
                    this.appendChild(ripple);
                    setTimeout(() => {
                        ripple.remove();
                    }, 600);
                });
            });
        };
        
        // 标题故障效果
        const glitchEffect = () => {
            const titles = document.querySelectorAll('.cyberpunk-title');
            titles.forEach(title => {
                setInterval(() => {
                    title.style.textShadow = '2px 0 0 rgba(255,0,255,0.7), -2px 0 0 rgba(0,255,255,0.7)';
                    setTimeout(() => {
                        title.style.textShadow = 'none';
                    }, 150);
                }, Math.random() * 5000 + 3000);
            });
        };
        
        // 滚动时的渐入效果
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('opacity-100', 'translate-y-0');
                    entry.target.classList.remove('opacity-0', 'translate-y-10');
                }
            });
        }, { threshold: 0.1 });
        
        document.querySelectorAll('.cyberpunk-card').forEach(element => {
            element.classList.add('opacity-0', 'translate-y-10', 'transition-all', 'duration-700');
            observer.observe(element);
        });
        
        // 执行动画
        setTimeout(() => {
            animateCounters();
            addRippleEffect();
            glitchEffect();
        }, 300);
        
        // 图标脉动效果
        const pulseIcon = () => {
            const icon = document.querySelector('.cyberpunk-icon i');
            setInterval(() => {
                icon.style.transform = 'scale(1.1)';
                setTimeout(() => {
                    icon.style.transform = 'scale(1)';
                }, 500);
            }, 2000);
        };
        pulseIcon();
        
        // 页面载入效果
        document.body.classList.add('loaded');
    });
</script>

<?php include ROOT_PATH . '/app/views/layouts/footer.php'; ?>