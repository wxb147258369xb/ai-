<?php include ROOT_PATH . '/app/views/layouts/header.php'; ?>

<!-- 动态网格背景 -->
<div class="fixed inset-0 bg-grid-cyan opacity-10 z-[-2]"></div>
<div class="fixed inset-0 bg-black z-[-3]"></div>

<!-- 英雄区 -->
<section class="hero relative overflow-hidden py-16">
    <div class="absolute inset-0 bg-gradient-to-br from-cyan-900/40 to-blue-900/40 z-0"></div>
    <div class="grid-grid absolute inset-0 opacity-20 z-0"></div>
    
    <!-- 扫描线效果 -->
    <div class="scanlines absolute inset-0 z-10 pointer-events-none"></div>
    
    <div class="container mx-auto px-4 relative z-10">
        <div class="max-w-3xl mx-auto text-center">
            <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600 mb-6 shadow-glow-cyan cyberpunk-title">
                赛博朋克论坛 <span class="text-sm md:text-base inline-block ml-2 bg-cyan-900/80 text-cyan-300 px-3 py-1 rounded-full border border-cyan-500">V2.077</span>
            </h1>
            <p class="text-xl text-cyan-300 mb-8 cyberpunk-text">
                探索未来世界的边缘，分享你的赛博朋克故事与想法
            </p>
            
            <!-- 搜索框 -->
            <div class="max-w-xl mx-auto mb-8">
                <form action="/search" method="get" class="relative">
                    <input type="text" name="q" placeholder="搜索话题、回复或用户..." 
                           class="w-full bg-gray-900/80 border border-cyan-700 rounded-full px-6 py-4 text-gray-300 placeholder-gray-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 shadow-glow-cyan-sm transition-all duration-300 cyber-input">
                    <button type="submit" class="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-bold rounded-full w-12 h-12 flex items-center justify-center shadow-glow-cyan hover:shadow-glow-cyan-sm transition-all duration-300 cyber-button">
                        <i class="fas fa-search"></i>
                    </button>
                </form>
            </div>
            
            <!-- 统计卡片 -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div class="bg-black/60 border border-cyan-800 rounded-lg p-4 backdrop-blur-sm neon-border hover:border-cyan-500 transition-all duration-300">
                    <div class="text-3xl font-bold text-cyan-400 mb-1 shadow-glow-cyan stats-counter">
                        <?php echo $stats['total_threads']; ?>
                    </div>
                    <div class="text-gray-400">话题总数</div>
                </div>
                <div class="bg-black/60 border border-cyan-800 rounded-lg p-4 backdrop-blur-sm neon-border hover:border-cyan-500 transition-all duration-300">
                    <div class="text-3xl font-bold text-cyan-400 mb-1 shadow-glow-cyan stats-counter">
                        <?php echo $stats['total_replies']; ?>
                    </div>
                    <div class="text-gray-400">回复总数</div>
                </div>
                <div class="bg-black/60 border border-cyan-800 rounded-lg p-4 backdrop-blur-sm neon-border hover:border-cyan-500 transition-all duration-300">
                    <div class="text-3xl font-bold text-cyan-400 mb-1 shadow-glow-cyan stats-counter">
                        <?php echo $stats['total_users']; ?>
                    </div>
                    <div class="text-gray-400">用户总数</div>
                </div>
                <div class="bg-black/60 border border-yellow-800 rounded-lg p-4 backdrop-blur-sm neon-border hover:border-yellow-500 transition-all duration-300">
                    <div class="text-3xl font-bold text-yellow-500 mb-1 shadow-glow-yellow stats-counter">
                        <?php echo $stats['online_users']; ?>
                    </div>
                    <div class="text-gray-400">在线用户</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 版块列表 -->
<section class="py-12">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <!-- 主要内容 - 版块列表 -->
            <div class="lg:col-span-8">
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 shadow-glow-cyan cyberpunk-card animate-fade-in" style="animation-delay: 0.2s">
                    <h2 class="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600 mb-6 shadow-glow-cyan">版块列表</h2>
                    
                    <div class="space-y-4">
                        <?php foreach ($forums as $index => $forum): ?>
                            <a href="/forum/show/<?php echo $forum['id']; ?>" class="block group">
                                <div class="bg-gray-900/70 border border-gray-800 rounded-lg p-5 transition-all duration-300 group-hover:border-cyan-600 group-hover:shadow-glow-cyan-sm transform hover:-translate-y-1 cyberpunk-card animate-fade-in" style="animation-delay: <?php echo 0.3 + ($index * 0.1); ?>s">
                                    <div class="flex items-start">
                                        <!-- 版块图标 -->
                                        <div class="w-14 h-14 rounded-lg bg-gradient-to-br from-cyan-900 to-blue-900 flex items-center justify-center mr-4 flex-shrink-0 group-hover:from-cyan-800 group-hover:to-blue-800 transition-all duration-300">
                                            <i class="fas fa-hashtag text-2xl text-cyan-400 group-hover:scale-110 transition-transform duration-300"></i>
                                        </div>
                                        
                                        <!-- 版块信息 -->
                                        <div class="flex-1">
                                            <div class="flex flex-wrap justify-between items-start mb-2">
                                                <h3 class="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors mr-3">
                                                    <?php echo htmlspecialchars($forum['name']); ?>
                                                </h3>
                                                <?php if ($forum['is_private']): ?>
                                                    <span class="text-xs text-purple-400 bg-purple-900/30 px-2 py-1 rounded-full border border-purple-700">
                                                        <i class="fas fa-lock mr-1"></i>私有版块
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <p class="text-gray-400 mb-4 text-sm">
                                                <?php echo htmlspecialchars($forum['description']); ?>
                                            </p>
                                            
                                            <!-- 版块统计 -->
                                            <div class="flex items-center justify-between">
                                                <div class="flex items-center space-x-6">
                                                    <span class="text-sm text-cyan-400">
                                                        <i class="fas fa-file-alt mr-1"></i><?php echo number_format($forum['thread_count']); ?> 话题
                                                    </span>
                                                    <span class="text-sm text-blue-400">
                                                        <i class="fas fa-comment mr-1"></i>
                                                        <?php echo $forum['thread_count'] > 0 ? '有回复' : '暂无回复'; ?>
                                                    </span>
                                                </div>
                                                
                                                <div class="text-xs text-gray-500">
                                                    <?php if (!empty($forum['latest_threads'])): ?>
                                                        <span>最新: 
                                                            <a href="/thread/show/<?php echo $forum['latest_threads'][0]['id']; ?>" class="text-cyan-500 hover:underline truncate max-w-[150px] inline-block">
                                                                <?php echo htmlspecialchars($forum['latest_threads'][0]['title']); ?>
                                                            </a>
                                                        </span>
                                                    <?php else: ?>
                                                        <span>暂无话题</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
            <!-- 侧边栏 -->
            <div class="lg:col-span-4">
                <!-- 发布话题 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 mb-8 shadow-glow-cyan cyberpunk-card animate-fade-in" style="animation-delay: 0.4s">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4">快速发布</h3>
                    <a href="/thread/create" class="block w-full py-3 px-4 bg-gradient-to-r from-cyan-600 to-blue-600 text-black font-bold rounded-lg shadow-glow-cyan text-center hover:from-cyan-500 hover:to-blue-500 transition-colors cyber-button">
                        <i class="fas fa-plus-circle mr-2"></i>发布新话题
                    </a>
                </div>
                
                <!-- 热门话题 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 mb-8 shadow-glow-cyan cyberpunk-card animate-fade-in" style="animation-delay: 0.6s">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4">热门话题</h3>
                    <div class="space-y-4">
                        <?php 
                        // 获取热门话题（这里使用模拟数据，如果有实际数据请替换）
                        $hotTopics = [
                            ['id' => 1, 'title' => '2077年的夜之城：未来已来', 'views' => 1245, 'replies' => 89],
                            ['id' => 2, 'title' => '赛博朋克时尚：霓虹时代的穿搭指南', 'views' => 987, 'replies' => 64],
                            ['id' => 3, 'title' => '人工智能伦理：我们是否应该担忧？', 'views' => 1567, 'replies' => 132]
                        ];
                        foreach ($hotTopics as $topic): ?>
                            <div class="bg-gray-900/50 border border-gray-800 rounded-lg p-3 hover:border-cyan-600 transition-all duration-300 hover:shadow-glow-cyan-sm hover:-translate-y-1">
                                <a href="/thread/show/<?php echo $topic['id']; ?>" class="block">
                                    <h4 class="text-sm font-medium text-white hover:text-cyan-400 transition-colors mb-2 line-clamp-2">
                                        <?php echo htmlspecialchars($topic['title']); ?>
                                    </h4>
                                    <div class="flex items-center justify-between text-xs text-gray-500">
                                        <span><i class="fas fa-eye mr-1"></i><?php echo number_format($topic['views']); ?></span>
                                        <span><i class="fas fa-comment mr-1"></i><?php echo number_format($topic['replies']); ?></span>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- 最新回复 -->
                <div class="bg-black bg-opacity-60 border border-cyan-800 rounded-lg p-6 shadow-glow-cyan cyberpunk-card animate-fade-in" style="animation-delay: 0.8s">
                    <h3 class="text-xl font-bold text-cyan-400 mb-4">最新回复</h3>
                    <div class="space-y-4">
                        <?php 
                        // 获取最新回复（这里使用模拟数据，如果有实际数据请替换）
                        $latestReplies = [
                            ['id' => 1, 'content' => '我觉得这个观点很有见地，确实值得深思...', 'username' => 'cyberpunk2077', 'thread_id' => 1, 'thread_title' => '赛博朋克的哲学思考'],
                            ['id' => 2, 'content' => '已经尝试了这个方法，效果非常好！', 'username' => 'hacker_42', 'thread_id' => 2, 'thread_title' => 'DIY电子义体教程'],
                            ['id' => 3, 'content' => '谢谢分享，这对我帮助很大。', 'username' => 'neon_rider', 'thread_id' => 3, 'thread_title' => '夜之城生存指南']
                        ];
                        foreach ($latestReplies as $reply): ?>
                            <div class="bg-gray-900/50 border border-gray-800 rounded-lg p-3 hover:border-cyan-600 transition-all duration-300 hover:shadow-glow-cyan-sm hover:-translate-y-1">
                                <div class="text-xs text-cyan-400 mb-1">
                                    <a href="/user/profile/<?php echo strtolower($reply['username']); ?>" class="hover:underline">
                                        <?php echo htmlspecialchars($reply['username']); ?>
                                    </a> 回复了
                                </div>
                                <p class="text-sm text-gray-300 mb-2 line-clamp-2">
                                    <?php echo htmlspecialchars($reply['content']); ?>
                                </p>
                                <a href="/thread/show/<?php echo $reply['thread_id']; ?>" class="text-xs text-gray-500 hover:text-cyan-400 transition-colors">
                                    话题: "<?php echo htmlspecialchars($reply['thread_title']); ?>"
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 装饰性元素 -->
<div class="cyberpunk-element fixed bottom-0 left-0 w-full h-32 pointer-events-none z-[-1]">
    <div class="scanline"></div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 动态背景网格动画
        const createGrid = () => {
            const grid = document.querySelector('.bg-grid-cyan');
            let html = '';
            for (let i = 0; i < 50; i++) {
                html += '<div class="absolute h-[1px] bg-cyan-500/20" style="top:' + (i * 2) + 'vh; left:0; right:0;"></div>';
            }
            for (let i = 0; i < 50; i++) {
                html += '<div class="absolute w-[1px] bg-cyan-500/20" style="left:' + (i * 2) + 'vw; top:0; bottom:0;"></div>';
            }
            grid.innerHTML = html;
        };
        createGrid();
        
        // 扫描线效果
        const createScanlines = () => {
            const scanlines = document.querySelector('.scanlines');
            let html = '';
            for (let i = 0; i < 50; i++) {
                html += '<div class="absolute h-[1px] bg-cyan-500/10" style="top:' + (i * 2) + 'vh; left:0; right:0; animation: scanline 6s linear infinite;"></div>';
            }
            scanlines.innerHTML = html;
        };
        createScanlines();
        
        // 添加扫描线动画样式
        const style = document.createElement('style');
        style.innerHTML = `
            @keyframes scanline {
                0% { opacity: 0.1; }
                50% { opacity: 0.2; }
                100% { opacity: 0.1; }
            }
            @keyframes glitch {
                0% { transform: translate(0); }
                20% { transform: translate(-2px, 2px); }
                40% { transform: translate(-2px, -2px); }
                60% { transform: translate(2px, 2px); }
                80% { transform: translate(2px, -2px); }
                100% { transform: translate(0); }
            }
            @keyframes fadeInUp {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }
            .animate-fade-in {
                animation: fadeInUp 0.8s ease forwards;
                opacity: 0;
            }
        `;
        document.head.appendChild(style);
        
        // 版块卡片悬停动画增强
        const forumCards = document.querySelectorAll('.group');
        forumCards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                const border = this.querySelector('.bg-gray-900');
                border.classList.add('transform', '-translate-y-1', 'transition-transform', 'duration-300');
                
                // 添加霓虹边框效果
                border.classList.add('shadow-glow-cyan-sm');
            });
            
            card.addEventListener('mouseleave', function() {
                const border = this.querySelector('.bg-gray-900');
                border.classList.remove('transform', '-translate-y-1', 'transition-transform', 'duration-300');
                border.classList.remove('shadow-glow-cyan-sm');
            });
        });
        
        // 数字滚动动画
        const animateCounters = () => {
            const counters = document.querySelectorAll('.stats-counter');
            counters.forEach(counter => {
                const target = parseInt(counter.innerText.replace(/,/g, ''));
                let count = 0;
                const duration = 2000; // 2秒
                const step = target / (duration / 16);
                
                const updateCount = () => {
                    count += step;
                    if (count < target) {
                        counter.innerText = Math.floor(count).toLocaleString();
                        requestAnimationFrame(updateCount);
                    } else {
                        counter.innerText = target.toLocaleString();
                    }
                };
                
                updateCount();
            });
        };
        
        // 标题打字机效果
        const typewriterEffect = () => {
            const title = document.querySelector('.cyberpunk-title');
            const originalText = title.innerText;
            title.innerText = '';
            let index = 0;
            
            const type = () => {
                if (index < originalText.length) {
                    title.innerText += originalText.charAt(index);
                    index++;
                    setTimeout(type, Math.random() * 50 + 20);
                }
            };
            
            setTimeout(type, 500);
        };
        
        // 按钮点击波纹效果
        const addRippleEffect = () => {
            const buttons = document.querySelectorAll('.cyber-button');
            buttons.forEach(button => {
                button.addEventListener('click', function(e) {
                    const ripple = document.createElement('span');
                    const rect = this.getBoundingClientRect();
                    const size = Math.max(rect.width, rect.height);
                    const x = e.clientX - rect.left - size / 2;
                    const y = e.clientY - rect.top - size / 2;
                    
                    ripple.style.width = ripple.style.height = size + 'px';
                    ripple.style.left = x + 'px';
                    ripple.style.top = y + 'px';
                    ripple.classList.add('ripple');
                    
                    this.appendChild(ripple);
                    setTimeout(() => {
                        ripple.remove();
                    }, 600);
                });
            });
        };
        
        // 滚动时的渐入效果
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('opacity-100', 'translate-y-0');
                    entry.target.classList.remove('opacity-0', 'translate-y-10');
                }
            });
        }, { threshold: 0.1 });
        
        document.querySelectorAll('.cyberpunk-card').forEach(element => {
            element.classList.add('opacity-0', 'translate-y-10', 'transition-all', 'duration-700');
            observer.observe(element);
        });
        
        // 执行动画
        setTimeout(() => {
            animateCounters();
            typewriterEffect();
            addRippleEffect();
        }, 300);
        
        // 页面载入效果
        document.body.classList.add('loaded');
    });
</script>

<?php include ROOT_PATH . '/app/views/layouts/footer.php'; ?>