<?php
/**
 * 首页视图 - 赛博朋克风格增强版
 */
$title = '首页';
?>

<!-- 扫描线和网格背景效果 -->
<div class="fixed inset-0 z-0">
    <div class="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGZpbGw9IiMxMjEyMTIiIGQ9Ik0zNiAxOGMzLjMxNCAwIDYtMi42ODYgNi02cy0yLjY4Ni02LTYtNi02IDIuNjg2LTYgNiAyLjY4NiA2IDYgNnptMC0xOGMzLjMxNCAwIDYtMi42ODYgNi02cy0yLjY4Ni02LTYtNi02IDIuNjg2LTYgNiAyLjY4NiA2IDYgNnptLTE4IDE4YzMuMzE0IDAgNi0yLjY4NiA2LTZzLTIuNjg2LTYtNi02LTYgMi42ODYtNiA2IDIuNjg2IDYgNiA2em0wLTE4YzMuMzE0IDAgNi0yLjY4NiA2LTZzLTIuNjg2LTYtNi02LTYgMi42ODYtNiA2IDIuNjg2IDYgNiA2em0xOCAzNmMzLjMxNCAwIDYtMi42ODYgNi02cy0yLjY4Ni02LTYtNi02IDIuNjg2LTYgNiAyLjY4NiA2IDYgNnptMC0xOGMzLjMxNCAwIDYtMi42ODYgNi02cy0yLjY4Ni02LTYtNi02IDIuNjg2LTYgNiAyLjY4NiA2IDYgNnoiLz48L2c+PC9zdmc+')] opacity-10"></div>
    <div class="scanline absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black opacity-5 pointer-events-none"></div>
</div>

<!-- 英雄区 -->
<section class="relative overflow-hidden bg-gradient-to-b from-dark to-darker py-16 md:py-24">
    <div class="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-neon-blue/10 via-transparent to-transparent"></div>
    
    <!-- 动态网格背景 -->
    <div class="absolute inset-0 bg-grid-pattern opacity-10"></div>
    
    <!-- 霓虹灯效果 -->
    <div class="absolute top-1/4 left-1/4 w-96 h-96 bg-neon-blue rounded-full filter blur-[150px] opacity-20 animate-pulse"></div>
    <div class="absolute bottom-1/3 right-1/4 w-64 h-64 bg-neon-pink rounded-full filter blur-[120px] opacity-20 animate-pulse delay-700"></div>
    
    <div class="container mx-auto px-4 relative z-10">
        <div class="max-w-3xl mx-auto text-center">
            <h1 class="text-4xl md:text-6xl font-cyber font-bold mb-6 text-white">
                <span class="bg-clip-text text-transparent bg-gradient-to-r from-neon-blue via-neon-pink to-neon-green animate-glow">NEXUS</span>
                <span class="text-neon-blue/80 font-mono ml-2">V2.0</span>
            </h1>
            <p class="text-xl md:text-2xl text-gray-300 mb-8">连接未来，探索赛博朋克世界</p>
            <p class="text-gray-400 mb-10 max-w-2xl mx-auto">
                Nexus 是一个充满未来感的社区平台，这里聚集着热爱技术、游戏、艺术和创新的人们。
                加入我们，一起探索赛博朋克世界的无限可能。
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="/register" class="px-8 py-3 bg-neon-blue text-dark font-bold rounded-md hover:bg-neon-blue/80 transition-all transform hover:-translate-y-1 shadow-lg shadow-neon-blue/20 hover:shadow-neon-blue/40">
                    立即注册
                </a>
                <a href="/forum" class="px-8 py-3 border border-neon-pink text-neon-pink rounded-md hover:bg-neon-pink/10 transition-all transform hover:-translate-y-1">
                    浏览版块
                </a>
            </div>
            
            <!-- 统计信息 -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 stats-grid">
                <div class="text-center">
                    <div class="text-3xl font-cyber font-bold text-neon-blue mb-2 counter" data-target="5248">0</div>
                    <div class="text-gray-400 text-sm">注册用户</div>
                </div>
                <div class="text-center">
                    <div class="text-3xl font-cyber font-bold text-neon-pink mb-2 counter" data-target="12765">0</div>
                    <div class="text-gray-400 text-sm">话题总数</div>
                </div>
                <div class="text-center">
                    <div class="text-3xl font-cyber font-bold text-neon-green mb-2 counter" data-target="124537">0</div>
                    <div class="text-gray-400 text-sm">回复总数</div>
                </div>
                <div class="text-center">
                    <div class="text-3xl font-cyber font-bold text-neon-purple mb-2 counter" data-target="328">0</div>
                    <div class="text-gray-400 text-sm">在线用户</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 主要内容区 -->
<main class="container mx-auto px-4 py-12 relative z-10">
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- 左侧内容 -->
        <div class="lg:col-span-2 space-y-8">
            <!-- 版块列表 -->
            <section class="animate-fade-in">
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-2xl font-cyber font-bold text-white flex items-center">
                        <i class="fa fa-th-large text-neon-blue mr-2"></i>
                        版块浏览
                    </h2>
                    <a href="/forum" class="text-neon-blue hover:text-white transition-colors flex items-center gap-1 group">
                        查看全部 
                        <i class="fa fa-angle-right group-hover:translate-x-1 transition-transform"></i>
                    </a>
                </div>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <?php foreach ($forums as $forum): ?>
                        <div class="cyberpunk-card rounded-lg overflow-hidden transition-all duration-300 hover:transform hover:scale-[1.02] border border-gray-800">
                            <a href="/forum/<?php echo $forum['id']; ?>" class="block p-5">
                                <div class="flex items-start gap-4">
                                    <div class="flex-shrink-0 h-14 w-14 rounded-full" style="background-color: rgba(<?php echo hexdec(substr($forum['color'], 1, 2)); ?>, <?php echo hexdec(substr($forum['color'], 3, 2)); ?>, <?php echo hexdec(substr($forum['color'], 5, 2)); ?>, 0.2);">
                                        <i class="fa fa-<?php echo $forum['icon']; ?> h-full w-full flex items-center justify-center text-2xl" style="color: <?php echo $forum['color']; ?>;"></i>
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <h3 class="font-bold text-white mb-1 truncate" style="text-shadow: 0 0 5px <?php echo $forum['color']; ?>;">
                                            <?php echo $forum['name']; ?>
                                        </h3>
                                        <p class="text-gray-400 text-sm mb-3 line-clamp-2"><?php echo $forum['description']; ?></p>
                                        <div class="flex justify-between items-center text-xs text-gray-500">
                                            <div><?php echo $forum['thread_count']; ?> 个话题</div>
                                            <div><?php echo $forum['reply_count']; ?> 条回复</div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
            
            <!-- 热门话题 -->
            <section class="animate-fade-in delay-100">
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-2xl font-cyber font-bold text-white flex items-center">
                        <i class="fa fa-fire text-neon-pink mr-2"></i>
                        热门话题
                    </h2>
                    <a href="/hot" class="text-neon-blue hover:text-white transition-colors flex items-center gap-1 group">
                        更多热门 
                        <i class="fa fa-angle-right group-hover:translate-x-1 transition-transform"></i>
                    </a>
                </div>
                
                <div class="space-y-4">
                    <?php foreach ($hotThreads as $thread): ?>
                        <div class="cyberpunk-card rounded-lg p-5 hover:neon-border transition-all duration-300 border border-gray-800">
                            <a href="/thread/<?php echo $thread['id']; ?>" class="block">
                                <h3 class="font-bold text-white mb-2 hover:text-neon-blue transition-colors">
                                    <?php echo $thread['title']; ?>
                                </h3>
                                <div class="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-gray-400">
                                    <span class="flex items-center gap-1">
                                        <i class="fa fa-folder text-neon-pink"></i> <?php echo $thread['forum']; ?>
                                    </span>
                                    <span class="flex items-center gap-1">
                                        <i class="fa fa-user text-neon-blue"></i> <?php echo $thread['user']; ?>
                                    </span>
                                    <span class="flex items-center gap-1">
                                        <i class="fa fa-eye text-gray-500"></i> <?php echo $thread['view_count']; ?>
                                    </span>
                                    <span class="flex items-center gap-1">
                                        <i class="fa fa-comment text-neon-green"></i> <?php echo $thread['reply_count']; ?>
                                    </span>
                                    <span class="flex items-center gap-1">
                                        <i class="fa fa-clock-o text-gray-500"></i> <?php echo $thread['time']; ?>
                                    </span>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
            
            <!-- 最新话题 -->
            <section class="animate-fade-in delay-200">
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-2xl font-cyber font-bold text-white flex items-center">
                        <i class="fa fa-bolt text-neon-green mr-2"></i>
                        最新话题
                    </h2>
                    <a href="/latest" class="text-neon-blue hover:text-white transition-colors flex items-center gap-1 group">
                        更多最新 
                        <i class="fa fa-angle-right group-hover:translate-x-1 transition-transform"></i>
                    </a>
                </div>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <?php foreach ($latestThreads as $thread): ?>
                        <div class="cyberpunk-card rounded-lg p-4 hover:neon-border transition-all duration-300 border border-gray-800">
                            <a href="/thread/<?php echo $thread['id']; ?>" class="block">
                                <h3 class="font-bold text-white mb-2 line-clamp-2 hover:text-neon-blue transition-colors">
                                    <?php echo $thread['title']; ?>
                                </h3>
                                <div class="flex justify-between items-center text-xs text-gray-400">
                                    <span><?php echo $thread['forum']; ?></span>
                                    <span><?php echo $thread['user']; ?></span>
                                    <span><?php echo $thread['time']; ?></span>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        </div>
        
        <!-- 右侧边栏 -->
        <div class="space-y-8">
            <!-- 登录/注册卡片 -->
            <?php if (!isset($_SESSION['user'])): ?>
                <div class="cyberpunk-card rounded-lg p-6 border border-gray-800 animate-fade-in">
                    <h3 class="text-xl font-cyber font-bold text-white mb-4">欢迎来到 Nexus</h3>
                    <p class="text-gray-400 mb-6">登录或注册以加入我们的社区</p>
                    <div class="space-y-3">
                        <a href="/login" class="block w-full text-center px-4 py-3 bg-neon-blue text-dark font-bold rounded-md hover:bg-neon-blue/80 transition-colors transform hover:-translate-y-0.5 hover:shadow-lg hover:shadow-neon-blue/30">
                            登录
                        </a>
                        <a href="/register" class="block w-full text-center px-4 py-3 border border-neon-pink text-neon-pink rounded-md hover:bg-neon-pink/10 transition-colors transform hover:-translate-y-0.5">
                            注册
                        </a>
                    </div>
                    <div class="mt-4 text-center">
                        <p class="text-xs text-gray-500">还没有账号？<a href="/register" class="text-neon-blue hover:underline">立即创建</a></p>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- 排行榜 -->
            <div class="cyberpunk-card rounded-lg p-6 border border-gray-800 animate-fade-in delay-100">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-xl font-cyber font-bold text-white">荣耀殿堂</h3>
                    <a href="/ranking" class="text-xs text-neon-blue hover:underline">查看全部</a>
                </div>
                
                <h4 class="text-neon-green text-sm font-medium mb-3 flex items-center">
                    <i class="fa fa-trophy mr-2"></i>
                    积分排行榜
                </h4>
                <div class="space-y-3 mb-6">
                    <?php foreach ($rankings['users'] as $user): ?>
                        <div class="flex items-center gap-3 hover:bg-gray-800/50 p-2 rounded-md transition-colors">
                            <div class="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold">
                                <?php if ($user['rank'] == 1): ?>
                                    <span class="bg-yellow-500 text-dark">1</span>
                                <?php elseif ($user['rank'] == 2): ?>
                                    <span class="bg-gray-300 text-dark">2</span>
                                <?php elseif ($user['rank'] == 3): ?>
                                    <span class="bg-yellow-700 text-white">3</span>
                                <?php else: ?>
                                    <span class="bg-gray-700 text-gray-300"><?php echo $user['rank']; ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="flex-1 min-w-0">
                                <div class="font-medium text-white truncate"><?php echo $user['username']; ?></div>
                                <div class="text-xs text-gray-400">积分: <?php echo $user['points']; ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <h4 class="text-neon-pink text-sm font-medium mb-3 flex items-center">
                    <i class="fa fa-star mr-2"></i>
                    热门话题
                </h4>
                <div class="space-y-3">
                    <?php foreach ($rankings['threads'] as $thread): ?>
                        <div class="flex items-center gap-3 hover:bg-gray-800/50 p-2 rounded-md transition-colors">
                            <div class="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold bg-gray-700 text-gray-300">
                                <?php echo $thread['rank']; ?>
                            </div>
                            <div class="flex-1 min-w-0">
                                <a href="/thread/<?php echo $thread['id']; ?>" class="text-sm text-white hover:text-neon-pink transition-colors line-clamp-1">
                                    <?php echo $thread['title']; ?>
                                </a>
                                <div class="text-xs text-gray-400">浏览: <?php echo $thread['views']; ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- 积分商城推荐 -->
            <div class="cyberpunk-card rounded-lg p-6 border border-gray-800 animate-fade-in delay-200">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-xl font-cyber font-bold text-white">价值交易所</h3>
                    <a href="/shop" class="text-xs text-neon-blue hover:underline">进入商城</a>
                </div>
                
                <div class="space-y-4">
                    <div class="bg-gray-800/50 rounded-lg p-3 hover:bg-gray-800 transition-colors transform hover:-translate-y-0.5">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-neon-green/20 flex items-center justify-center">
                                <i class="fa fa-crown text-neon-green"></i>
                            </div>
                            <div>
                                <div class="text-sm font-medium text-white">霓虹猎手</div>
                                <div class="text-xs text-neon-green">500 积分</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-gray-800/50 rounded-lg p-3 hover:bg-gray-800 transition-colors transform hover:-translate-y-0.5">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-neon-pink/20 flex items-center justify-center">
                                <i class="fa fa-diamond text-neon-pink"></i>
                            </div>
                            <div>
                                <div class="text-sm font-medium text-white">科技先驱</div>
                                <div class="text-xs text-neon-pink">600 积分</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-gray-800/50 rounded-lg p-3 hover:bg-gray-800 transition-colors transform hover:-translate-y-0.5">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-neon-blue/20 flex items-center justify-center">
                                <i class="fa fa-star text-neon-blue"></i>
                            </div>
                            <div>
                                <div class="text-sm font-medium text-white">VIP会员激活码</div>
                                <div class="text-xs text-neon-blue">1000 积分</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 社区公告 -->
            <div class="cyberpunk-card rounded-lg p-6 border border-gray-800 animate-fade-in delay-300">
                <h3 class="text-xl font-cyber font-bold text-white mb-4">社区公告</h3>
                <div class="space-y-4">
                    <div class="border-l-2 border-neon-pink pl-3 hover:bg-gray-800/50 p-2 -ml-3 rounded-r-md transition-colors">
                        <h4 class="text-sm font-medium text-white mb-1">论坛新功能预告</h4>
                        <p class="text-xs text-gray-400 mb-2">我们即将推出积分商城系统，用户可以使用积分兑换虚拟商品。</p>
                        <div class="text-xs text-gray-500">1周前</div>
                    </div>
                    <div class="border-l-2 border-neon-blue pl-3 hover:bg-gray-800/50 p-2 -ml-3 rounded-r-md transition-colors">
                        <h4 class="text-sm font-medium text-white mb-1">系统维护通知</h4>
                        <p class="text-xs text-gray-400 mb-2">本周末（周六晚22:00-周日凌晨2:00）系统将进行例行维护。</p>
                        <div class="text-xs text-gray-500">2天前</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- JavaScript交互 -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 新增：动态背景网格效果
        const createGridPattern = () => {
            const gridContainer = document.createElement('div');
            gridContainer.className = 'absolute inset-0 pointer-events-none';
            gridContainer.style.backgroundImage = `linear-gradient(to right, rgba(0, 191, 255, 0.1) 1px, transparent 1px), 
                                                  linear-gradient(to bottom, rgba(0, 191, 255, 0.1) 1px, transparent 1px)`;
            gridContainer.style.backgroundSize = '40px 40px';
            gridContainer.style.animation = 'gridMove 20s linear infinite';
            document.querySelector('.relative.overflow-hidden').appendChild(gridContainer);
        };
        
        // 扫描线动画
        const scanlineEffect = () => {
            const scanline = document.querySelector('.scanline');
            if (scanline) {
                scanline.style.animation = 'scanlineMove 8s linear infinite';
            }
        };
        
        // 版块卡片悬停效果增强
        const forumCards = document.querySelectorAll('.cyberpunk-card');
        forumCards.forEach((card, index) => {
            // 添加延迟效果
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            setTimeout(() => {
                card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 100 + (index % 6) * 100);
            
            // 增强的悬停效果
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px)';
                this.style.boxShadow = '0 10px 25px -5px rgba(0, 191, 255, 0.2)';
                this.style.borderColor = 'rgba(0, 191, 255, 0.5)';
            });
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = 'none';
                this.style.borderColor = 'rgba(75, 85, 99, 1)';
            });
        });
        
        // 英雄区动态效果增强
        const heroSection = document.querySelector('section.relative');
        if (heroSection) {
            const createParticle = () => {
                const particle = document.createElement('div');
                const size = Math.random() * 3 + 1;
                const colors = ['#00ff00', '#00bfff', '#ff00ff', '#9900ff'];
                const color = colors[Math.floor(Math.random() * colors.length)];
                
                particle.style.position = 'absolute';
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                particle.style.backgroundColor = color;
                particle.style.borderRadius = '50%';
                particle.style.top = `${Math.random() * 100}%`;
                particle.style.left = `${Math.random() * 100}%`;
                particle.style.opacity = '0';
                particle.style.transition = `opacity 2s, transform 10s linear`;
                particle.style.pointerEvents = 'none';
                particle.style.boxShadow = `0 0 ${Math.random() * 10 + 5}px ${color}`;
                
                heroSection.appendChild(particle);
                
                setTimeout(() => {
                    particle.style.opacity = '0.8';
                    particle.style.transform = `translateY(-${Math.random() * 300 + 100}px) translateX(${Math.random() * 100 - 50}px)`;
                }, 100);
                
                setTimeout(() => {
                    heroSection.removeChild(particle);
                }, 10000);
            };
            
            setInterval(createParticle, 150);
        }
        
        // 数字滚动效果增强版
        const animateCounters = () => {
            const counters = document.querySelectorAll('.counter');
            counters.forEach(counter => {
                const target = parseInt(counter.getAttribute('data-target'));
                let current = 0;
                const duration = 2000;
                const increment = target / (duration / 16);
                
                const updateCounter = () => {
                    current += increment;
                    if (current < target) {
                        counter.textContent = Math.floor(current).toLocaleString();
                        requestAnimationFrame(updateCounter);
                    } else {
                        counter.textContent = target.toLocaleString();
                    }
                };
                
                updateCounter();
            });
        };
        
        // 为标题添加打字机效果
        const typewriterEffect = () => {
            const title = document.querySelector('h1 span');
            if (title) {
                const originalText = title.textContent;
                title.textContent = '';
                let index = 0;
                
                const type = () => {
                    if (index < originalText.length) {
                        title.textContent += originalText.charAt(index);
                        index++;
                        setTimeout(type, 50);
                    }
                };
                
                setTimeout(type, 500);
            }
        };
        
        // 监听滚动，当统计区域进入视口时开始动画
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounters();
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        const statsSection = document.querySelector('.stats-grid');
        if (statsSection) {
            observer.observe(statsSection);
        }
        
        // 添加页面载入效果
        const pageLoadEffect = () => {
            document.body.style.opacity = '0';
            setTimeout(() => {
                document.body.style.transition = 'opacity 1s ease';
                document.body.style.opacity = '1';
            }, 100);
        };
        
        // 执行所有效果
        pageLoadEffect();
        createGridPattern();
        scanlineEffect();
        typewriterEffect();
        
        // 添加页面滚动动画
        const scrollAnimation = () => {
            const sections = document.querySelectorAll('section');
            
            const scrollObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('opacity-100', 'translate-y-0');
                        entry.target.classList.remove('opacity-0', 'translate-y-10');
                    }
                });
            }, { threshold: 0.1 });
            
            sections.forEach(section => {
                section.classList.add('transition-all', 'duration-1000');
                scrollObserver.observe(section);
            });
        };
        
        scrollAnimation();
    });
</script>