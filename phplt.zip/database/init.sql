-- Nexus论坛系统数据库初始化脚本

-- 创建数据库
CREATE DATABASE IF NOT EXISTS php_forum DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 使用数据库
USE php_forum;

-- 用户表
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    avatar VARCHAR(255) DEFAULT 'default_avatar.png',
    signature TEXT,
    custom_title VARCHAR(100) DEFAULT NULL,
    status TINYINT DEFAULT 1 COMMENT '0=禁用,1=启用',
    role ENUM('user', 'moderator', 'admin') DEFAULT 'user',
    points INT DEFAULT 0,
    post_count INT DEFAULT 0,
    thread_count INT DEFAULT 0,
    last_login DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 社交账户关联表
CREATE TABLE IF NOT EXISTS social_accounts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    provider VARCHAR(20) NOT NULL COMMENT '微信,QQ,微博等',
    provider_user_id VARCHAR(100) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 版块表
CREATE TABLE IF NOT EXISTS forums (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50) DEFAULT 'default.png',
    color VARCHAR(20) DEFAULT '#00bfff',
    parent_id INT DEFAULT NULL,
    order_num INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES forums(id) ON DELETE SET NULL
);

-- 帖子表
CREATE TABLE IF NOT EXISTS threads (
    id INT PRIMARY KEY AUTO_INCREMENT,
    forum_id INT NOT NULL,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    content LONGTEXT NOT NULL,
    view_count INT DEFAULT 0,
    reply_count INT DEFAULT 0,
    last_reply_at DATETIME,
    is_sticky TINYINT DEFAULT 0,
    is_locked TINYINT DEFAULT 0,
    is_hot TINYINT DEFAULT 0,
    status ENUM('normal', 'reviewing', 'deleted') DEFAULT 'normal',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (forum_id) REFERENCES forums(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 回复表
CREATE TABLE IF NOT EXISTS replies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    thread_id INT NOT NULL,
    user_id INT NOT NULL,
    content LONGTEXT NOT NULL,
    status ENUM('normal', 'reviewing', 'deleted') DEFAULT 'normal',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (thread_id) REFERENCES threads(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 虚拟商品表
CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price INT NOT NULL,
    type ENUM('custom_title', 'avatar_frame', 'activation_code') NOT NULL,
    inventory INT DEFAULT 9999,
    image VARCHAR(255) DEFAULT 'default.png',
    is_active TINYINT DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 订单表
CREATE TABLE IF NOT EXISTS orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    order_no VARCHAR(50) UNIQUE NOT NULL,
    amount INT NOT NULL,
    status ENUM('pending', 'completed', 'cancelled') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- 激活码表
CREATE TABLE IF NOT EXISTS activation_codes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    order_id INT NOT NULL,
    code VARCHAR(100) NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    is_used TINYINT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- 举报表
CREATE TABLE IF NOT EXISTS reports (
    id INT PRIMARY KEY AUTO_INCREMENT,
    reporter_id INT NOT NULL,
    reported_type ENUM('thread', 'reply', 'user') NOT NULL,
    reported_id INT NOT NULL,
    reason TEXT NOT NULL,
    status ENUM('pending', 'processing', 'resolved', 'rejected') DEFAULT 'pending',
    processed_by INT DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (processed_by) REFERENCES users(id) ON DELETE SET NULL
);

-- 日志表
CREATE TABLE IF NOT EXISTS logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT DEFAULT NULL,
    action VARCHAR(50) NOT NULL,
    module VARCHAR(50) NOT NULL,
    details TEXT,
    ip VARCHAR(50),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- 管理员分配表
CREATE TABLE IF NOT EXISTS moderators (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    forum_id INT NOT NULL,
    permissions VARCHAR(255) NOT NULL DEFAULT 'all',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (forum_id) REFERENCES forums(id) ON DELETE CASCADE
);

-- 创建默认版块
INSERT INTO forums (name, description, icon, color, order_num) VALUES
('技术讨论', '分享技术心得，解决编程问题', 'code', '#00ff00', 1),
('游戏世界', '游戏攻略、心得交流', 'game', '#ff00ff', 2),
('创意设计', '设计灵感、作品展示', 'design', '#00bfff', 3),
('生活闲聊', '日常生活、兴趣爱好', 'life', '#ff6600', 4),
('站务公告', '论坛规则、系统公告', 'notice', '#ff0000', 5);

-- 创建默认管理员账户
INSERT INTO users (username, email, password, role) VALUES
('admin', 'admin@nexus.com', '$2y$12$K4zqEaKfD4yO6t8YgXm4Ne9Z1X5uO7k3i8j2l9p4o5a7s6d1c3v0', 'admin');

-- 创建一些测试用户
INSERT INTO users (username, email, password, points, post_count, thread_count) VALUES
('user1', 'user1@nexus.com', '$2y$12$K4zqEaKfD4yO6t8YgXm4Ne9Z1X5uO7k3i8j2l9p4o5a7s6d1c3v0', 100, 5, 2),
('user2', 'user2@nexus.com', '$2y$12$K4zqEaKfD4yO6t8YgXm4Ne9Z1X5uO7k3i8j2l9p4o5a7s6d1c3v0', 200, 10, 3),
('user3', 'user3@nexus.com', '$2y$12$K4zqEaKfD4yO6t8YgXm4Ne9Z1X5uO7k3i8j2l9p4o5a7s6d1c3v0', 150, 8, 1);

-- 创建一些测试帖子
INSERT INTO threads (forum_id, user_id, title, content, is_hot) VALUES
(1, 2, 'PHP 8.0 新特性详解', 'PHP 8.0带来了许多令人兴奋的新特性，包括JIT编译器、联合类型、命名参数等。让我们一起来探讨这些新功能如何提升开发效率。', 1),
(2, 3, '赛博朋克2077最新更新内容', 'CDPR最近发布了赛博朋克2077的重要更新，修复了大量bug并优化了游戏体验。分享一下你的游戏体验。', 1),
(3, 2, '如何创建赛博朋克风格的UI设计', '赛博朋克风格的设计要点包括霓虹色彩、故障艺术效果、科技感元素等。本文分享一些实用的设计技巧。', 0),
(4, 1, '程序员的周末生活', '作为一名程序员，你的周末通常是如何度过的？是继续编程、学习新技术，还是彻底放松？', 0),
(5, 1, '论坛新功能预告', '我们即将推出积分商城系统，用户可以使用积分兑换虚拟商品。敬请期待！', 1);

-- 创建一些测试回复
INSERT INTO replies (thread_id, user_id, content) VALUES
(1, 3, 'JIT编译器的性能提升确实很明显，特别是在计算密集型应用中。'),
(1, 1, '命名参数功能让函数调用更加清晰，非常喜欢这个改进！'),
(2, 2, '更新后游戏稳定性好了很多，但还是偶尔会出现崩溃。'),
(3, 1, '故障艺术效果在CSS中可以通过clip-path和animation实现，效果很棒。'),
(4, 3, '我通常会学习一些新技术，同时也会玩会儿游戏放松一下。');

-- 创建虚拟商品
INSERT INTO products (name, description, price, type, image) VALUES
('霓虹猎手', '赛博朋克风格自定义头衔', 500, 'custom_title', 'neon_hunter.png'),
('像素皇冠', '复古像素风格头像框', 300, 'avatar_frame', 'pixel_crown.png'),
('VIP会员激活码', '30天VIP会员特权', 1000, 'activation_code', 'vip_code.png'),
('科技先驱', '未来科技风格自定义头衔', 600, 'custom_title', 'tech_pioneer.png'),
('数字幽灵', '透明效果头像框', 400, 'avatar_frame', 'digital_ghost.png');

-- 更新帖子统计信息
UPDATE threads SET reply_count = (SELECT COUNT(*) FROM replies WHERE replies.thread_id = threads.id);
UPDATE threads SET last_reply_at = (SELECT MAX(created_at) FROM replies WHERE replies.thread_id = threads.id);

-- 更新用户统计信息
UPDATE users SET post_count = (SELECT COUNT(*) FROM replies WHERE replies.user_id = users.id);
UPDATE users SET thread_count = (SELECT COUNT(*) FROM threads WHERE threads.user_id = users.id);

-- 创建索引优化性能
CREATE INDEX idx_threads_forum_id ON threads(forum_id);
CREATE INDEX idx_threads_user_id ON threads(user_id);
CREATE INDEX idx_replies_thread_id ON replies(thread_id);
CREATE INDEX idx_replies_user_id ON replies(user_id);
CREATE INDEX idx_orders_user_id ON orders(user_id);
CREATE INDEX idx_orders_product_id ON orders(product_id);

-- 插入一些系统日志
INSERT INTO logs (user_id, action, module, details, ip) VALUES
(1, 'login', 'auth', '管理员登录成功', '127.0.0.1'),
(2, 'create_thread', 'forum', '创建新帖子: PHP 8.0 新特性详解', '127.0.0.1'),
(3, 'create_reply', 'forum', '回复帖子: PHP 8.0 新特性详解', '127.0.0.1');